
  # Build FieldWork Landing Page

  This is a code bundle for Build FieldWork Landing Page. The original project is available at https://www.figma.com/design/zid8ncTkXRRQ9nNN8EZwQb/Build-FieldWork-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  