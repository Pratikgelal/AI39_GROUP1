import { useState } from 'react';
import { DarkNavbar } from './components/DarkNavbar';
import { DarkHeroCarousel } from './components/DarkHeroCarousel';
import { TeamSection } from './components/TeamSection';
import { CategoryCards } from './components/CategoryCards';
import { Footer } from './components/Footer';
import { ChatbotButton } from './components/ChatbotButton';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { PrivacyPolicyPage } from './components/PrivacyPolicyPage';
import { LearnMorePage } from './components/LearnMorePage';
import { DarkOnboardingModal } from './components/DarkOnboardingModal';
import { HealthDashboard } from './components/HealthDashboard';
import { FitnessPage } from './components/FitnessPage';
import { AboutPage } from './components/AboutPage';
import { ContactPage } from './components/ContactPage';

type Page = 'home' | 'login' | 'register' | 'privacy' | 'learn-more' | 'health-dashboard' | 'fitness' | 'about' | 'contact';

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  if (page === 'login') {
    return (
      <LoginPage
        onBack={() => setPage('home')}
        onRegister={() => setPage('register')}
      />
    );
  }

  if (page === 'register') {
    return (
      <RegisterPage
        onBack={() => setPage('home')}
        onSignIn={() => setPage('login')}
      />
    );
  }

  if (page === 'privacy') {
    return (
      <PrivacyPolicyPage
        onLoginClick={() => setPage('login')}
        onRegisterClick={() => setPage('register')}
        onBackHome={() => setPage('home')}
      />
    );
  }

  if (page === 'learn-more') {
    return (
      <>
        <LearnMorePage
          onLoginClick={() => setPage('login')}
          onRegisterClick={() => setPage('register')}
          onGetStarted={() => setIsOnboardingOpen(true)}
          onPrivacyClick={() => setPage('privacy')}
          onHomeClick={() => setPage('home')}
        />
        <DarkOnboardingModal
          isOpen={isOnboardingOpen}
          onClose={() => setIsOnboardingOpen(false)}
        />
      </>
    );
  }

  if (page === 'health-dashboard') {
    return <HealthDashboard onBack={() => setPage('home')} />;
  }

  if (page === 'fitness') {
    return <FitnessPage onBack={() => setPage('home')} />;
  }

  if (page === 'about') {
    return <AboutPage onBack={() => setPage('home')} />;
  }

  if (page === 'contact') {
    return <ContactPage onBack={() => setPage('home')} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0D0D0D] via-[#121212] to-black">
      <DarkNavbar
        onLoginClick={() => setPage('login')}
        onRegisterClick={() => setPage('register')}
        onHomeClick={() => setPage('home')}
        onAboutClick={() => setPage('about')}
        onContactClick={() => setPage('contact')}
      />
      <DarkHeroCarousel
        onGetStarted={() => setIsOnboardingOpen(true)}
        onLearnMore={() => setPage('learn-more')}
      />
      <CategoryCards
        onHealthClick={() => setPage('health-dashboard')}
        onFitnessClick={() => setPage('fitness')}
      />
      <TeamSection />
      <Footer onPrivacyClick={() => setPage('privacy')} />
      <ChatbotButton />
      <DarkOnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
      />
    </div>
  );
}