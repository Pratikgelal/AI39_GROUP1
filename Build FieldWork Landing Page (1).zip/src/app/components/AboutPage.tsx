import { motion } from 'motion/react';
import { X, Target, TrendingUp, Heart, Dumbbell } from 'lucide-react';

interface AboutPageProps {
  onBack: () => void;
}

export function AboutPage({ onBack }: AboutPageProps) {
  const features = [
    {
      icon: Target,
      title: 'BMI Tracking',
      description: 'Calculate and monitor your Body Mass Index with personalized recommendations',
      color: '#FFD600'
    },
    {
      icon: TrendingUp,
      title: 'Calorie System',
      description: 'Smart calorie tracking based on your goals and activity level',
      color: '#00C897'
    },
    {
      icon: Heart,
      title: 'Meal Tracking',
      description: 'Log your daily nutrition and hit your macro targets consistently',
      color: '#EF4444'
    },
    {
      icon: Dumbbell,
      title: 'Workout Plans',
      description: '7-day structured workout routines tailored to your fitness level',
      color: '#3B82F6'
    }
  ];

  return (
    <div className="min-h-screen" style={{ background: '#0B0B0B' }}>
      {/* Close Button */}
      <div className="fixed top-8 left-8 z-50">
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={onBack}
          className="w-12 h-12 rounded-full flex items-center justify-center"
          style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,214,0,0.3)' }}
        >
          <X className="w-6 h-6 text-white" />
        </motion.button>
      </div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-white mb-6" style={{ fontSize: '64px', fontWeight: 800, letterSpacing: '-2px' }}>
              About VitaPulse
            </h1>
            <p className="text-white/70" style={{ fontSize: '20px', lineHeight: 1.7 }}>
              Empowering your fitness journey through smart tracking and personalised insights
            </p>
          </motion.div>
        </div>
      </section>

      {/* About Content Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left - Text */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-white mb-6" style={{ fontSize: '42px', fontWeight: 700 }}>
                What We Do
              </h2>
              <div className="space-y-4 text-white/70" style={{ fontSize: '16px', lineHeight: 1.8 }}>
                <p>
                  VitaPulse is a comprehensive fitness and health tracking platform designed to help you achieve your wellness goals through intelligent tools and personalized insights.
                </p>
                <p>
                  Our platform combines cutting-edge technology with proven fitness science to deliver smart recommendations based on your unique body metrics, goals, and activity levels.
                </p>
                <p>
                  Whether you're tracking your BMI, monitoring calorie intake, planning your macros, or following structured workout routines, VitaPulse provides the tools you need to stay consistent and see real results.
                </p>
              </div>
            </motion.div>

            {/* Right - Image */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="rounded-3xl overflow-hidden"
              style={{ border: '2px solid rgba(255,214,0,0.2)' }}
            >
              <img
                src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                alt="Fitness Lifestyle"
                className="w-full h-[400px] object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 px-6" style={{ background: '#0D0D0D' }}>
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-white mb-6" style={{ fontSize: '48px', fontWeight: 700 }}>
              Our Mission
            </h2>
            <p className="text-white/70" style={{ fontSize: '18px', lineHeight: 1.8 }}>
              To help individuals build a healthier lifestyle through intelligent fitness tools and consistent tracking. We believe that with the right guidance and data-driven insights, anyone can transform their health and achieve their fitness goals.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Highlight */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-white mb-4"
              style={{ fontSize: '48px', fontWeight: 700 }}
            >
              Features That Make a Difference
            </motion.h2>
            <p className="text-white/60" style={{ fontSize: '16px' }}>
              Everything you need to track, monitor, and improve your fitness journey
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.6 }}
                  whileHover={{ y: -8, boxShadow: `0 20px 40px ${feature.color}30` }}
                  className="p-6 rounded-2xl"
                  style={{
                    background: '#1A1A1A',
                    border: `2px solid ${feature.color}30`
                  }}
                >
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center mb-4"
                    style={{ background: `${feature.color}15` }}
                  >
                    <Icon className="w-7 h-7" style={{ color: feature.color }} />
                  </div>
                  <h3 className="text-white mb-2" style={{ fontSize: '20px', fontWeight: 600 }}>
                    {feature.title}
                  </h3>
                  <p className="text-white/60" style={{ fontSize: '14px', lineHeight: 1.6 }}>
                    {feature.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Team/Creator Section */}
      <section className="py-20 px-6" style={{ background: '#0D0D0D' }}>
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-white mb-6" style={{ fontSize: '48px', fontWeight: 700 }}>
              Built by Passionate Developers
            </h2>
            <p className="text-white/70 mb-8" style={{ fontSize: '18px', lineHeight: 1.8 }}>
              VitaPulse is crafted with dedication by a team of developers who believe in the power of technology to transform health and fitness. We're committed to building tools that make tracking your wellness journey simple, effective, and motivating.
            </p>
            <div className="inline-block px-6 py-3 rounded-full" style={{ background: 'rgba(255,214,0,0.1)', border: '1px solid rgba(255,214,0,0.3)' }}>
              <p className="text-[#FFD600]" style={{ fontSize: '14px', fontWeight: 600 }}>
                Contact us: vitaapulsee@gmail.com
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
