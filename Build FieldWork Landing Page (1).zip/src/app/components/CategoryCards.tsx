import { motion } from 'motion/react';
import { Dumbbell, Heart } from 'lucide-react';

interface CategoryCardsProps {
  onHealthClick?: () => void;
  onFitnessClick?: () => void;
}

export function CategoryCards({ onHealthClick, onFitnessClick }: CategoryCardsProps) {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-black via-[#0D0D0D] to-black">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Fitness Card */}
          <motion.button
            onClick={onFitnessClick}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            whileHover={{ y: -12, scale: 1.03 }}
            className="group relative overflow-hidden rounded-3xl aspect-square cursor-pointer border-2 border-white/10 hover:border-[#FFD600]/60 transition-all duration-300 text-left"
            style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.4)' }}
          >
            <div className="absolute inset-0">
              <img
                src="https://images.unsplash.com/photo-1750521279808-f66baaed923d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                alt="Fitness"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-yellow-900/40 to-black/60" />
            </div>

            {/* Neon Glow Effect on Hover */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-[inset_0_0_40px_rgba(255,214,0,0.4),0_0_60px_rgba(255,214,0,0.3)]" />

            {/* "Open Page" badge */}
            <div className="absolute top-6 right-6 px-3 py-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0" style={{ background: 'rgba(255,214,0,0.2)', border: '1px solid rgba(255,214,0,0.6)', backdropFilter: 'blur(12px)' }}>
              <span className="text-white text-xs font-semibold">Open Page →</span>
            </div>

            <div className="relative h-full flex flex-col justify-end p-12">
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="mb-6"
              >
                <Dumbbell className="w-16 h-16 text-white" strokeWidth={1.5} />
              </motion.div>
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
                Fitness
              </h2>
              <p className="text-xl text-white/90 mb-6">
                Build strength, endurance, and transform your body with expert guidance
              </p>
              <div className="inline-flex items-center text-white font-semibold group-hover:translate-x-2 transition-transform">
                <span>Explore Fitness</span>
                <svg
                  className="w-6 h-6 ml-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 8l4 4m0 0l-4 4m4-4H3"
                  />
                </svg>
              </div>
            </div>
          </motion.button>

          {/* Health Card */}
          <motion.button
            onClick={onHealthClick}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            whileHover={{ y: -12, scale: 1.03 }}
            className="group relative overflow-hidden rounded-3xl aspect-square cursor-pointer border-2 border-white/10 hover:border-[#FF7A00]/60 transition-all duration-300 text-left"
            style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.4)' }}
          >
            <div className="absolute inset-0">
              <img
                src="https://images.unsplash.com/photo-1767611125032-20b291ec1c5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                alt="Health & Wellness"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-orange-900/40 to-black/60" />
            </div>

            {/* Neon Glow Effect on Hover */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-[inset_0_0_40px_rgba(255,122,0,0.4),0_0_60px_rgba(255,122,0,0.3)]" />

            {/* "Open Dashboard" badge */}
            <div className="absolute top-6 right-6 px-3 py-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0" style={{ background: 'rgba(255,122,0,0.2)', border: '1px solid rgba(255,122,0,0.6)', backdropFilter: 'blur(12px)' }}>
              <span className="text-white text-xs font-semibold">Open Dashboard →</span>
            </div>

            <div className="relative h-full flex flex-col justify-end p-12">
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="mb-6"
              >
                <Heart className="w-16 h-16 text-white" strokeWidth={1.5} />
              </motion.div>
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
                Health
              </h2>
              <p className="text-xl text-white/90 mb-6">
                Nurture your wellbeing through holistic health and mindful practices
              </p>
              <div className="inline-flex items-center text-white font-semibold group-hover:translate-x-2 transition-transform">
                <span>Explore Health</span>
                <svg
                  className="w-6 h-6 ml-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 8l4 4m0 0l-4 4m4-4H3"
                  />
                </svg>
              </div>
            </div>
          </motion.button>
        </div>
      </div>
    </section>
  );
}