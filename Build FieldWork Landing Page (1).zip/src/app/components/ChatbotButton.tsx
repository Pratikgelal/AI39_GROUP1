import { MessageCircle, X } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export function ChatbotButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Floating Button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 z-50 w-16 h-16 rounded-full bg-gradient-to-r from-[#00C897] to-teal-500 text-white shadow-[0_0_40px_rgba(0,200,151,0.5)] hover:shadow-[0_0_60px_rgba(0,200,151,0.7)] transition-all"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        animate={{
          boxShadow: [
            '0 0 40px rgba(0,200,151,0.5)',
            '0 0 60px rgba(0,200,151,0.7)',
            '0 0 40px rgba(0,200,151,0.5)',
          ],
        }}
        transition={{
          boxShadow: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
        }}
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              className="flex items-center justify-center"
            >
              <X className="w-6 h-6" />
            </motion.div>
          ) : (
            <motion.div
              key="open"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              className="flex items-center justify-center"
            >
              <MessageCircle className="w-6 h-6" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-28 right-8 z-40 w-96 h-[500px] bg-black/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_0_50px_rgba(0,200,151,0.3)] overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-[#00C897] to-teal-500 text-white p-4">
              <h3 className="text-lg font-semibold">AI Health Assistant</h3>
              <p className="text-sm text-white/80">How can I help you today?</p>
            </div>

            {/* Chat Area */}
            <div className="h-[calc(100%-140px)] p-4 overflow-y-auto bg-gradient-to-b from-[#0D0D0D] to-black">
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#00C897] to-teal-500 flex items-center justify-center flex-shrink-0 shadow-[0_0_15px_rgba(0,200,151,0.4)]">
                    <MessageCircle className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl rounded-tl-none p-3 max-w-[80%]">
                    <p className="text-sm text-gray-200">
                      Hi! I'm your AI wellness assistant. Ask me about fitness routines, nutrition advice, or health tips!
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Input Area */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/95 backdrop-blur-xl border-t border-white/10">
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-2 rounded-full bg-white/5 border border-white/10 outline-none focus:ring-2 focus:ring-[#00C897] text-sm text-white placeholder:text-gray-500"
                />
                <button className="w-10 h-10 rounded-full bg-gradient-to-r from-[#00C897] to-teal-500 text-white flex items-center justify-center hover:shadow-[0_0_20px_rgba(0,200,151,0.5)] transition-all">
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
