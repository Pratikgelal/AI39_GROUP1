import { ContactSection } from './ContactSection';
import { X } from 'lucide-react';
import { motion } from 'motion/react';

interface ContactPageProps {
  onBack: () => void;
}

export function ContactPage({ onBack }: ContactPageProps) {
  return (
    <div className="min-h-screen" style={{ background: '#0B0B0B' }}>
      {/* Close Button */}
      <div className="fixed top-8 left-8 z-50">
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={onBack}
          className="w-12 h-12 rounded-full flex items-center justify-center"
          style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,214,0,0.3)' }}
        >
          <X className="w-6 h-6 text-white" />
        </motion.button>
      </div>

      {/* Hero Header */}
      <div className="pt-32 pb-12 px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-white mb-4" style={{ fontSize: '64px', fontWeight: 800, letterSpacing: '-2px' }}>
            Contact Us
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto" style={{ fontSize: '18px', lineHeight: 1.6 }}>
            Have a question or feedback? We'd love to hear from you.
          </p>
        </motion.div>
      </div>

      <ContactSection />
    </div>
  );
}
