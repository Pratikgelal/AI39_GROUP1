import { motion } from 'motion/react';
import { Mail, MapPin, Send } from 'lucide-react';
import { useState } from 'react';

interface ContactSectionProps {
  compact?: boolean;
}

export function ContactSection({ compact = false }: ContactSectionProps) {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSent(true);
    setTimeout(() => {
      setIsSent(false);
      setFormData({ name: '', email: '', message: '' });
    }, 3000);
  };

  return (
    <section className="py-20 px-6" style={{ background: '#0B0B0B' }}>
      <div className={`${compact ? 'max-w-6xl' : 'max-w-7xl'} mx-auto`}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="grid md:grid-cols-2 gap-0 rounded-3xl overflow-hidden"
          style={{ border: '2px solid rgba(255,214,0,0.2)', boxShadow: '0 20px 60px rgba(0,0,0,0.5)' }}
        >
          {/* LEFT SIDE - Image */}
          <div className={`relative ${compact ? 'h-[500px]' : 'h-[600px]'} overflow-hidden`}>
            <img
              src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
              alt="Fitness Contact"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(0,0,0,0.7), rgba(0,0,0,0.85))' }} />

            {/* Overlay Content */}
            <div className="absolute inset-0 flex flex-col justify-end p-12">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
              >
                <h3 className="text-white mb-6" style={{ fontSize: '42px', fontWeight: 800, lineHeight: 1.2 }}>
                  Get In Touch
                </h3>
                <p className="text-white/80 mb-8" style={{ fontSize: '16px', lineHeight: 1.6 }}>
                  Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
                </p>

                {/* Contact Info */}
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: 'rgba(255,214,0,0.15)' }}>
                      <Mail className="w-5 h-5 text-[#FFD600]" />
                    </div>
                    <div>
                      <p className="text-white/50" style={{ fontSize: '12px' }}>Email</p>
                      <p className="text-white" style={{ fontSize: '15px', fontWeight: 600 }}>vitaapulsee@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: 'rgba(255,214,0,0.15)' }}>
                      <MapPin className="w-5 h-5 text-[#FFD600]" />
                    </div>
                    <div>
                      <p className="text-white/50" style={{ fontSize: '12px' }}>Location</p>
                      <p className="text-white" style={{ fontSize: '15px', fontWeight: 600 }}>Bhaktapur, Nepal</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* RIGHT SIDE - Form */}
          <div className="p-12" style={{ background: '#1A1A1A' }}>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
            >
              <h2 className="text-white mb-3" style={{ fontSize: '36px', fontWeight: 700 }}>Contact Us</h2>
              <p className="text-white/60 mb-8" style={{ fontSize: '15px' }}>Fill out the form below and we'll get back to you soon.</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Full Name */}
                <div>
                  <label className="block text-white/70 mb-2" style={{ fontSize: '13px', fontWeight: 600 }}>Full Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your full name"
                    className="w-full px-5 py-4 rounded-xl bg-black/40 text-white outline-none transition-all"
                    style={{
                      border: '2px solid rgba(255,214,0,0.2)',
                      fontSize: '15px'
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = '#FFD600';
                      e.target.style.boxShadow = '0 0 20px rgba(255,214,0,0.3)';
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = 'rgba(255,214,0,0.2)';
                      e.target.style.boxShadow = 'none';
                    }}
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block text-white/70 mb-2" style={{ fontSize: '13px', fontWeight: 600 }}>Email</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="your.email@example.com"
                    className="w-full px-5 py-4 rounded-xl bg-black/40 text-white outline-none transition-all"
                    style={{
                      border: '2px solid rgba(255,214,0,0.2)',
                      fontSize: '15px'
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = '#FFD600';
                      e.target.style.boxShadow = '0 0 20px rgba(255,214,0,0.3)';
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = 'rgba(255,214,0,0.2)';
                      e.target.style.boxShadow = 'none';
                    }}
                  />
                </div>

                {/* Message */}
                <div>
                  <label className="block text-white/70 mb-2" style={{ fontSize: '13px', fontWeight: 600 }}>Message</label>
                  <textarea
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us what's on your mind..."
                    rows={5}
                    className="w-full px-5 py-4 rounded-xl bg-black/40 text-white outline-none resize-none transition-all"
                    style={{
                      border: '2px solid rgba(255,214,0,0.2)',
                      fontSize: '15px',
                      lineHeight: 1.6
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = '#FFD600';
                      e.target.style.boxShadow = '0 0 20px rgba(255,214,0,0.3)';
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = 'rgba(255,214,0,0.2)';
                      e.target.style.boxShadow = 'none';
                    }}
                  />
                </div>

                {/* Submit Button */}
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 rounded-xl flex items-center justify-center gap-2 transition-all duration-300"
                  style={{
                    background: isSent ? '#10B981' : '#0B0B0B',
                    border: `2px solid ${isSent ? '#10B981' : '#FFD600'}`,
                    color: isSent ? '#fff' : '#FFD600',
                    fontSize: '16px',
                    fontWeight: 700
                  }}
                  onMouseEnter={(e) => {
                    if (!isSent) {
                      e.currentTarget.style.background = '#FFD600';
                      e.currentTarget.style.color = '#0B0B0B';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isSent) {
                      e.currentTarget.style.background = '#0B0B0B';
                      e.currentTarget.style.color = '#FFD600';
                    }
                  }}
                >
                  {isSent ? (
                    <>
                      <span>✓ Message Sent!</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      <span>Send Message</span>
                    </>
                  )}
                </motion.button>
              </form>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
