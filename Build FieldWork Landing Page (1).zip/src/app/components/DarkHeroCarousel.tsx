import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import useEmblaCarousel from 'embla-carousel-react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

interface DarkHeroCarouselProps {
  onGetStarted: () => void;
  onLearnMore: () => void;
}

const carouselCards = [
  {
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&h=800&fit=crop',
    title: 'Develop Healthy Habits',
    gradient: 'from-emerald-500/60 via-teal-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=1200&h=800&fit=crop',
    title: 'Track Your Fitness',
    gradient: 'from-cyan-500/60 via-teal-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=1200&h=800&fit=crop',
    title: 'Eat Clean, Live Strong',
    gradient: 'from-orange-500/60 via-amber-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=1200&h=800&fit=crop',
    title: 'Consult Health Experts',
    gradient: 'from-teal-500/60 via-emerald-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&h=800&fit=crop',
    title: 'Transform Your Body',
    gradient: 'from-purple-500/60 via-pink-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=1200&h=800&fit=crop',
    title: 'Stay Mentally Fit',
    gradient: 'from-indigo-500/60 via-purple-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=1200&h=800&fit=crop',
    title: 'Build Strength & Power',
    gradient: 'from-red-500/60 via-orange-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1599058917212-d750089bc07e?w=1200&h=800&fit=crop',
    title: 'Find Your Balance',
    gradient: 'from-green-500/60 via-teal-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1200&h=800&fit=crop',
    title: 'Achieve Peak Performance',
    gradient: 'from-blue-500/60 via-cyan-600/60 to-black/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1200&h=800&fit=crop',
    title: 'Unlock Your Potential',
    gradient: 'from-emerald-500/60 via-green-600/60 to-black/80',
  },
];

export function DarkHeroCarousel({ onGetStarted, onLearnMore }: DarkHeroCarouselProps) {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    loop: true,
    align: 'center',
    skipSnaps: false,
    dragFree: false,
  });
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);

    // Auto-play
    const autoplay = setInterval(() => {
      emblaApi.scrollNext();
    }, 4000);

    return () => {
      clearInterval(autoplay);
      emblaApi.off('select', onSelect);
      emblaApi.off('reInit', onSelect);
    };
  }, [emblaApi, onSelect]);

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-[#0D0D0D] via-[#121212] to-black overflow-hidden" id="home">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-96 h-96 bg-[#FFD600]/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-[500px] h-[500px] bg-[#FF7A00]/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/3 w-80 h-80 bg-[#FFD600]/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black,transparent)]" />

      {/* Content Container */}
      <div className="relative pt-32 pb-20 px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-6xl lg:text-7xl mb-4 text-white leading-tight" style={{ textShadow: '0 0 40px rgba(0,0,0,0.8)' }}>
            Your Journey to <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD600] to-[#FF7A00]" style={{ filter: 'drop-shadow(0 0 20px rgba(255,214,0,0.5))' }}>Wellness</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto">
            Transform your health with AI-powered insights and personalized care
          </p>
        </motion.div>

        {/* Carousel Container */}
        <div className="relative max-w-7xl mx-auto">
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex gap-6 py-12">
              {carouselCards.map((card, index) => {
                const isCenter = index === selectedIndex;
                const distance = Math.abs(index - selectedIndex);

                return (
                  <motion.div
                    key={index}
                    className="flex-shrink-0 w-[85%] sm:w-[70%] md:w-[60%] lg:w-[50%] xl:w-[45%]"
                    animate={{
                      scale: isCenter ? 1 : 0.85,
                      opacity: isCenter ? 1 : 0.5,
                      rotateY: isCenter ? 0 : distance > 0 ? -15 : 15,
                      filter: isCenter ? 'blur(0px)' : 'blur(3px)',
                    }}
                    transition={{ duration: 0.5, ease: 'easeOut' }}
                    whileHover={{
                      scale: isCenter ? 1.03 : 0.87,
                      y: -10,
                      filter: isCenter ? 'blur(0px)' : 'blur(2px)',
                    }}
                    style={{
                      transformStyle: 'preserve-3d',
                      perspective: '1000px',
                    }}
                  >
                    <div className="relative h-[400px] md:h-[520px] rounded-3xl overflow-hidden group cursor-pointer">
                      {/* Image */}
                      <img
                        src={card.image}
                        alt={card.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />

                      {/* Dark Gradient Overlay */}
                      <div className={`absolute inset-0 bg-gradient-to-br ${card.gradient}`} />

                      {/* Glassmorphism Text Panel */}
                      <div className="absolute inset-0 flex items-end p-8">
                        <div className="w-full bg-white/5 backdrop-blur-2xl border border-white/10 rounded-2xl p-6 transform transition-all duration-300 group-hover:bg-white/10 group-hover:border-[#FFD600]/50">
                          <h3 className="text-3xl md:text-4xl text-white mb-2" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.9), 0 0 30px rgba(255,214,0,0.3)' }}>
                            {card.title}
                          </h3>
                          <div className="h-1 w-20 bg-gradient-to-r from-[#FFD600] to-[#FF7A00] rounded-full shadow-[0_0_15px_rgba(255,214,0,0.6)]" />
                        </div>
                      </div>

                      {/* Neon Glow Effect for Center Card */}
                      {isCenter && (
                        <div className="absolute inset-0 rounded-3xl shadow-[0_0_80px_rgba(255,214,0,0.5)] pointer-events-none" />
                      )}

                      {/* Border Glow */}
                      <div className={`absolute inset-0 rounded-3xl transition-all duration-300 ${
                        isCenter
                          ? 'shadow-[inset_0_0_20px_rgba(255,214,0,0.3),0_0_40px_rgba(255,214,0,0.4)]'
                          : 'shadow-[inset_0_0_10px_rgba(255,255,255,0.05)]'
                      }`} />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={scrollPrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full shadow-xl flex items-center justify-center text-white hover:bg-white/10 hover:border-[#FFD600]/50 hover:scale-110 transition-all z-10 hover:shadow-[0_0_30px_rgba(255,214,0,0.4)]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={scrollNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full shadow-xl flex items-center justify-center text-white hover:bg-white/10 hover:border-[#FFD600]/50 hover:scale-110 transition-all z-10 hover:shadow-[0_0_30px_rgba(255,214,0,0.4)]"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* CTA Buttons Below Center Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-6 justify-center items-center mt-16"
        >
          {/* Get Started Button - Neon Glow */}
          <motion.button
            onClick={onGetStarted}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-10 py-5 bg-gradient-to-r from-[#FFD600] to-[#FF7A00] text-black rounded-full shadow-[0_0_30px_rgba(255,214,0,0.4)] flex items-center gap-3 overflow-hidden"
            animate={{
              y: [0, -8, 0],
              boxShadow: [
                '0 0 30px rgba(255,214,0,0.4)',
                '0 0 50px rgba(255,214,0,0.6)',
                '0 0 30px rgba(255,214,0,0.4)',
              ],
            }}
            transition={{
              y: { duration: 3, repeat: Infinity, ease: 'easeInOut' },
              boxShadow: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
            }}
          >
            {/* Pulse Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#FFD600] to-[#FF7A00] opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-300" />

            {/* Ripple Effect */}
            <div className="absolute inset-0 rounded-full bg-white/20 scale-0 group-hover:scale-150 opacity-0 group-hover:opacity-100 transition-all duration-700" />

            <span className="relative text-lg z-10 font-bold">Get Started</span>
            <ArrowRight className="relative w-5 h-5 z-10 group-hover:translate-x-2 transition-transform duration-300" />
          </motion.button>

          {/* Learn More Button - Glass Border */}
          <motion.button
            onClick={onLearnMore}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-10 py-5 bg-transparent backdrop-blur-xl text-white rounded-full border-2 border-white/20 shadow-lg overflow-hidden"
            animate={{
              y: [0, -8, 0],
              borderColor: [
                'rgba(255,255,255,0.2)',
                'rgba(255,214,0,0.4)',
                'rgba(255,255,255,0.2)',
              ],
            }}
            transition={{
              y: { duration: 3, repeat: Infinity, ease: 'easeInOut', delay: 0.5 },
              borderColor: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
            }}
          >
            {/* Animated Border Glow */}
            <div className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-[inset_0_0_20px_rgba(255,214,0,0.3)]" />

            {/* Background Blur Increase on Hover */}
            <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 backdrop-blur-2xl rounded-full transition-all duration-300" />

            <span className="relative text-lg z-10 font-semibold">Learn More</span>
          </motion.button>
        </motion.div>

        {/* Carousel Indicators */}
        <div className="flex justify-center gap-2 mt-12">
          {carouselCards.map((_, index) => (
            <button
              key={index}
              onClick={() => emblaApi?.scrollTo(index)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                index === selectedIndex
                  ? 'w-12 bg-gradient-to-r from-[#FFD600] to-[#FF7A00] shadow-[0_0_10px_rgba(255,214,0,0.6)]'
                  : 'w-1.5 bg-white/20 hover:bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
