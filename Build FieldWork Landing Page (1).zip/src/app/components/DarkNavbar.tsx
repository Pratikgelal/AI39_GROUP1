import { Search, User, Menu, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import logoImage from '../../imports/Vita_pulse.png';
import { ProfilePanel } from './ProfilePanel';

interface DarkNavbarProps {
  onLoginClick?: () => void;
  onRegisterClick?: () => void;
  onHomeClick?: () => void;
  onAboutClick?: () => void;
  onContactClick?: () => void;
}

export function DarkNavbar({ onLoginClick, onRegisterClick, onHomeClick, onAboutClick, onContactClick }: DarkNavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Home', href: '#home', onClick: onHomeClick },
    { label: 'BMI Calculator', href: '#bmi' },
    { label: 'Wellness', href: '#wellness' },
    { label: 'About', href: '#about', onClick: onAboutClick },
    { label: 'Contact', href: '#contact', onClick: onContactClick },
  ];

  return (
    <nav
      className={`fixed top-6 left-6 right-6 z-50 transition-all duration-500 ${
        isScrolled ? 'top-4' : 'top-6'
      }`}
    >
      <div
        className="max-w-7xl mx-auto rounded-2xl transition-all duration-500"
        style={{
          backdropFilter: 'blur(20px)',
          border: '2px solid transparent',
          backgroundImage: isScrolled
            ? 'linear-gradient(145deg, rgba(13,13,13,0.85), rgba(18,18,18,0.85)), linear-gradient(135deg, rgba(255,214,0,0.4), rgba(255,122,0,0.3))'
            : 'linear-gradient(145deg, rgba(13,13,13,0.6), rgba(18,18,18,0.6)), linear-gradient(135deg, rgba(255,214,0,0.2), rgba(255,122,0,0.15))',
          backgroundOrigin: 'border-box',
          backgroundClip: 'padding-box, border-box',
          boxShadow: isScrolled
            ? '0 8px 32px rgba(0,0,0,0.6), 0 0 60px rgba(255,214,0,0.1)'
            : '0 4px 24px rgba(0,0,0,0.4)'
        }}
      >
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
          {/* Logo */}
          <button onClick={onHomeClick} className="flex items-center space-x-3 group cursor-pointer">
            <img
              src={logoImage}
              alt="VitaPulse Logo"
              className="w-10 h-10 object-contain group-hover:scale-110 transition-transform duration-300 drop-shadow-[0_0_10px_rgba(0,200,151,0.5)]"
            />
            <span className="text-2xl font-bold text-white drop-shadow-[0_0_8px_rgba(0,200,151,0.3)] group-hover:drop-shadow-[0_0_12px_rgba(0,200,151,0.5)] transition-all duration-300">
              VITAPULSE
            </span>
          </button>

          {/* Center Navigation - Desktop */}
          <div className="hidden lg:flex items-center space-x-1">
            {menuItems.map((item) => (
              <motion.button
                key={item.label}
                onClick={item.onClick || (() => {})}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="relative px-5 py-2.5 rounded-xl text-gray-300 hover:text-white transition-all duration-300 group"
              >
                <span className="relative z-10 font-medium">{item.label}</span>

                {/* Hover underline glow animation */}
                <span className="absolute bottom-1 left-1/2 w-0 h-0.5 bg-gradient-to-r from-[#FFD600] to-[#FF7A00] group-hover:w-3/4 group-hover:left-[12.5%] transition-all duration-300 rounded-full shadow-[0_0_16px_rgba(255,214,0,0.8)]" />

                {/* Hover glow effect */}
                <span className="absolute inset-0 opacity-0 group-hover:opacity-100 rounded-xl transition-all duration-300" style={{ background: 'rgba(255,214,0,0.08)', boxShadow: '0 0 20px rgba(255,214,0,0.2)' }} />
              </motion.button>
            ))}
          </div>

          {/* Right Side - Search & Auth */}
          <div className="flex items-center space-x-3">
            {/* Search Box - Desktop */}
            <div className="hidden md:flex items-center space-x-2 px-4 py-2.5 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 hover:border-[#00C897]/50 transition-all">
              <Search className="w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search..."
                className="bg-transparent outline-none w-32 xl:w-40 placeholder:text-sm text-white placeholder:text-gray-500"
              />
            </div>

            {/* Login Button - Gradient Outline */}
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(255,214,0,0.3)' }}
              whileTap={{ scale: 0.95 }}
              onClick={onLoginClick}
              className="hidden sm:flex items-center space-x-2 px-6 py-2.5 rounded-full transition-all duration-300"
              style={{
                border: '2px solid transparent',
                backgroundImage: 'linear-gradient(#0D0D0D, #0D0D0D), linear-gradient(135deg, #FFD600, #FF7A00)',
                backgroundOrigin: 'border-box',
                backgroundClip: 'padding-box, border-box',
                color: '#FFD600'
              }}
            >
              <User className="w-4 h-4" />
              <span className="font-semibold">Login</span>
            </motion.button>

            {/* Register Button - Gradient Fill */}
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(255,214,0,0.5)' }}
              whileTap={{ scale: 0.95 }}
              onClick={onRegisterClick}
              className="hidden sm:flex items-center space-x-2 px-6 py-2.5 rounded-full text-black font-bold transition-all duration-300"
              style={{ background: 'linear-gradient(135deg, #FFD600, #FF7A00)' }}
            >
              <span>Register</span>
            </motion.button>

            {/* Profile Button - Avatar */}
            <motion.button
              whileHover={{ scale: 1.1, boxShadow: '0 0 30px rgba(255,214,0,0.5)' }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsProfileOpen(true)}
              className="hidden sm:flex w-11 h-11 rounded-full items-center justify-center backdrop-blur-xl transition-all duration-300"
              style={{
                border: '2px solid transparent',
                backgroundImage: 'linear-gradient(135deg, rgba(13,13,13,0.8), rgba(18,18,18,0.8)), linear-gradient(135deg, #FFD600, #FF7A00)',
                backgroundOrigin: 'border-box',
                backgroundClip: 'padding-box, border-box',
                boxShadow: '0 0 20px rgba(255,214,0,0.2)'
              }}
            >
              <User className="w-5 h-5 text-[#FFD600]" />
            </motion.button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden w-10 h-10 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:border-[#00C897]/50 transition-all"
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 text-white" />
              ) : (
                <Menu className="w-5 h-5 text-white" />
              )}
            </button>
          </div>
        </div>
      </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="lg:hidden mt-4 mx-6 rounded-2xl overflow-hidden"
            style={{
              backdropFilter: 'blur(20px)',
              border: '2px solid transparent',
              backgroundImage: 'linear-gradient(145deg, rgba(13,13,13,0.95), rgba(18,18,18,0.95)), linear-gradient(135deg, rgba(255,214,0,0.3), rgba(255,122,0,0.2))',
              backgroundOrigin: 'border-box',
              backgroundClip: 'padding-box, border-box',
              boxShadow: '0 8px 32px rgba(0,0,0,0.6)'
            }}
          >
            <div className="px-6 py-4 space-y-2">
              {menuItems.map((item) => (
                <motion.button
                  key={item.label}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    if (item.onClick) item.onClick();
                    setIsMobileMenuOpen(false);
                  }}
                  className="block w-full text-left px-5 py-3 rounded-xl text-gray-300 hover:text-white transition-all duration-300"
                  style={{
                    background: 'transparent'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255,214,0,0.08)';
                    e.currentTarget.style.borderLeft = '3px solid #FFD600';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                    e.currentTarget.style.borderLeft = '3px solid transparent';
                  }}
                >
                  {item.label}
                </motion.button>
              ))}
              <div className="pt-4 space-y-3" style={{ borderTop: '1px solid rgba(255,214,0,0.15)' }}>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={onLoginClick}
                  className="w-full px-5 py-3 rounded-xl transition-all flex items-center justify-center gap-2 font-semibold"
                  style={{
                    border: '2px solid transparent',
                    backgroundImage: 'linear-gradient(#1A1A1A, #1A1A1A), linear-gradient(135deg, #FFD600, #FF7A00)',
                    backgroundOrigin: 'border-box',
                    backgroundClip: 'padding-box, border-box',
                    color: '#FFD600'
                  }}
                >
                  <User className="w-4 h-4" />
                  Login
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={onRegisterClick}
                  className="w-full px-5 py-3 rounded-xl text-black font-bold transition-all"
                  style={{ background: 'linear-gradient(135deg, #FFD600, #FF7A00)', boxShadow: '0 4px 20px rgba(255,214,0,0.3)' }}
                >
                  Register
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setIsProfileOpen(true);
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full px-5 py-3 rounded-xl transition-all flex items-center justify-center gap-2 font-semibold"
                  style={{
                    border: '2px solid transparent',
                    backgroundImage: 'linear-gradient(#1A1A1A, #1A1A1A), linear-gradient(135deg, #FFD600, #FF7A00)',
                    backgroundOrigin: 'border-box',
                    backgroundClip: 'padding-box, border-box',
                    color: '#FFD600'
                  }}
                >
                  <User className="w-4 h-4" />
                  My Profile
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Profile Panel */}
      <ProfilePanel isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} />
    </nav>
  );
}
