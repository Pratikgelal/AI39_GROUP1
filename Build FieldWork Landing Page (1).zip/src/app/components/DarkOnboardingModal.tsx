import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, Target, Dumbbell, Heart, ChevronRight, ChevronLeft, Sparkles } from 'lucide-react';

interface DarkOnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Goal = 'lose-weight' | 'gain-muscle' | 'stay-healthy';

export function DarkOnboardingModal({ isOpen, onClose }: DarkOnboardingModalProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 7;

  // Form state
  const [formData, setFormData] = useState({
    age: '',
    gender: 'male',
    height: '',
    weight: '',
    goal: 'stay-healthy' as Goal,
    activityLevel: 'moderate',
    sleepHours: 7,
    sleepQuality: 'good',
    dietType: 'non-veg',
    healthConditions: [] as string[],
    email: '',
    password: '',
  });

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleHealthCondition = (condition: string) => {
    setFormData(prev => ({
      ...prev,
      healthConditions: prev.healthConditions.includes(condition)
        ? prev.healthConditions.filter(c => c !== condition)
        : [...prev.healthConditions, condition]
    }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    console.log('Form submitted:', formData);
    setCurrentStep(totalSteps + 1); // Show success screen
  };

  const goalOptions = [
    { id: 'lose-weight', label: 'Lose Weight', icon: Target },
    { id: 'gain-muscle', label: 'Gain Muscle', icon: Dumbbell },
    { id: 'stay-healthy', label: 'Stay Healthy', icon: Heart },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-50 flex items-center justify-center px-4"
        >
          {/* Background with same homepage style */}
          <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-black to-gray-800">
            {/* Fitness model image on the right */}
            <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-20">
              <img
                src="https://images.unsplash.com/photo-1750698544894-1f012e37e5e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920"
                alt="Fitness"
                className="w-full h-full object-cover blur-sm"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-transparent via-black/50 to-black" />
            </div>
            {/* Green glow effect */}
            <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl" />
            <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-green-500/10 rounded-full blur-3xl" />
          </div>

          {/* Modal Card */}
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="relative w-full max-w-2xl bg-black/40 backdrop-blur-2xl border border-emerald-500/20 rounded-2xl shadow-[0_0_50px_rgba(34,197,94,0.15)] overflow-hidden"
          >
            {/* Glow border effect */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-emerald-500/10 via-transparent to-green-500/10 pointer-events-none" />

            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-6 right-6 z-10 text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Content */}
            <div className="relative p-8 md:p-12">
              {currentStep <= totalSteps ? (
                <>
                  {/* Progress Bar */}
                  <div className="mb-8">
                    <div className="flex justify-between mb-4">
                      {Array.from({ length: totalSteps }, (_, i) => (
                        <div key={i} className="flex items-center flex-1">
                          <div
                            className={`h-2 w-full rounded-full transition-all duration-500 ${
                              i + 1 <= currentStep
                                ? 'bg-gradient-to-r from-emerald-500 to-green-400 shadow-[0_0_10px_rgba(34,197,94,0.5)]'
                                : 'bg-gray-700'
                            }`}
                          />
                          {i < totalSteps - 1 && <div className="w-2" />}
                        </div>
                      ))}
                    </div>
                    <div className="text-center text-sm text-gray-400">
                      Step {currentStep} of {totalSteps}
                    </div>
                  </div>

                  {/* Form Content */}
                  <div className="min-h-[400px]">
                    {/* Step 1: Basic Info */}
                    {currentStep === 1 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-6"
                      >
                        <h2 className="text-3xl text-white mb-6">Basic Information</h2>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-gray-300 mb-2">Age</label>
                            <select
                              value={formData.age}
                              onChange={(e) => updateField('age', e.target.value)}
                              className="w-full px-4 py-3 bg-white/5 border border-emerald-500/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent backdrop-blur-sm"
                            >
                              <option value="">Select age</option>
                              {Array.from({ length: 63 }, (_, i) => i + 18).map(age => (
                                <option key={age} value={age} className="bg-gray-900">{age}</option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="block text-gray-300 mb-2">Gender</label>
                            <div className="flex gap-3 pt-3">
                              {['male', 'female'].map((gender) => (
                                <label key={gender} className="flex items-center gap-2 cursor-pointer">
                                  <input
                                    type="radio"
                                    name="gender"
                                    value={gender}
                                    checked={formData.gender === gender}
                                    onChange={(e) => updateField('gender', e.target.value)}
                                    className="w-4 h-4 text-emerald-500 focus:ring-emerald-500 bg-white/5 border-emerald-500/30"
                                  />
                                  <span className="text-gray-300 capitalize">{gender}</span>
                                </label>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-gray-300 mb-2">Height (cm)</label>
                            <input
                              type="number"
                              value={formData.height}
                              onChange={(e) => updateField('height', e.target.value)}
                              className="w-full px-4 py-3 bg-white/5 border border-emerald-500/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent backdrop-blur-sm"
                              placeholder="170"
                            />
                          </div>

                          <div>
                            <label className="block text-gray-300 mb-2">Weight (kg)</label>
                            <input
                              type="number"
                              value={formData.weight}
                              onChange={(e) => updateField('weight', e.target.value)}
                              className="w-full px-4 py-3 bg-white/5 border border-emerald-500/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent backdrop-blur-sm"
                              placeholder="70"
                            />
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 2: Goals */}
                    {currentStep === 2 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-6"
                      >
                        <h2 className="text-3xl text-white mb-6">What's Your Goal?</h2>

                        <div className="grid grid-cols-1 gap-4">
                          {goalOptions.map(({ id, label, icon: Icon }) => (
                            <button
                              key={id}
                              type="button"
                              onClick={() => updateField('goal', id)}
                              className={`p-6 rounded-xl border-2 transition-all flex items-center gap-4 ${
                                formData.goal === id
                                  ? 'border-emerald-500 bg-emerald-500/10 shadow-[0_0_20px_rgba(34,197,94,0.3)]'
                                  : 'border-gray-700 bg-white/5 hover:border-emerald-500/50'
                              }`}
                            >
                              <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                                formData.goal === id ? 'bg-emerald-500/20' : 'bg-white/5'
                              }`}>
                                <Icon className={`w-7 h-7 ${
                                  formData.goal === id ? 'text-emerald-400' : 'text-gray-400'
                                }`} />
                              </div>
                              <span className={`text-xl ${
                                formData.goal === id ? 'text-emerald-400' : 'text-gray-300'
                              }`}>
                                {label}
                              </span>
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {/* Step 3: Activity Level */}
                    {currentStep === 3 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-6"
                      >
                        <h2 className="text-3xl text-white mb-6">Activity Level</h2>

                        <div className="space-y-3">
                          {[
                            { value: 'sedentary', label: 'Sedentary', desc: 'Little to no exercise' },
                            { value: 'light', label: 'Light', desc: '1-2 days/week' },
                            { value: 'moderate', label: 'Moderate', desc: '3-5 days/week' },
                            { value: 'active', label: 'Active', desc: '6-7 days/week' },
                          ].map(({ value, label, desc }) => (
                            <label
                              key={value}
                              className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                formData.activityLevel === value
                                  ? 'border-emerald-500 bg-emerald-500/10'
                                  : 'border-gray-700 bg-white/5 hover:border-emerald-500/50'
                              }`}
                            >
                              <input
                                type="radio"
                                name="activityLevel"
                                value={value}
                                checked={formData.activityLevel === value}
                                onChange={(e) => updateField('activityLevel', e.target.value)}
                                className="w-5 h-5 text-emerald-500 focus:ring-emerald-500 bg-white/5 border-emerald-500/30"
                              />
                              <div>
                                <div className={`${
                                  formData.activityLevel === value ? 'text-emerald-400' : 'text-gray-300'
                                }`}>
                                  {label}
                                </div>
                                <div className="text-sm text-gray-500">{desc}</div>
                              </div>
                            </label>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {/* Step 4: Sleep */}
                    {currentStep === 4 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-6"
                      >
                        <h2 className="text-3xl text-white mb-6">Sleep Habits</h2>

                        <div>
                          <label className="block text-gray-300 mb-4">
                            Sleep Hours: <span className="text-emerald-400">{formData.sleepHours} hours</span>
                          </label>
                          <input
                            type="range"
                            min="4"
                            max="12"
                            value={formData.sleepHours}
                            onChange={(e) => updateField('sleepHours', parseInt(e.target.value))}
                            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                          />
                          <div className="flex justify-between text-xs text-gray-500 mt-1">
                            <span>4h</span>
                            <span>12h</span>
                          </div>
                        </div>

                        <div>
                          <label className="block text-gray-300 mb-2">Sleep Quality</label>
                          <select
                            value={formData.sleepQuality}
                            onChange={(e) => updateField('sleepQuality', e.target.value)}
                            className="w-full px-4 py-3 bg-white/5 border border-emerald-500/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent backdrop-blur-sm"
                          >
                            <option value="poor" className="bg-gray-900">Poor</option>
                            <option value="fair" className="bg-gray-900">Fair</option>
                            <option value="good" className="bg-gray-900">Good</option>
                            <option value="excellent" className="bg-gray-900">Excellent</option>
                          </select>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 5: Diet */}
                    {currentStep === 5 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-6"
                      >
                        <h2 className="text-3xl text-white mb-6">Diet Preference</h2>

                        <div className="grid grid-cols-2 gap-4">
                          {[
                            { value: 'veg', label: 'Vegetarian' },
                            { value: 'non-veg', label: 'Non-Vegetarian' },
                            { value: 'vegan', label: 'Vegan' },
                            { value: 'keto', label: 'Keto' },
                          ].map(({ value, label }) => (
                            <button
                              key={value}
                              type="button"
                              onClick={() => updateField('dietType', value)}
                              className={`p-5 rounded-xl border-2 transition-all ${
                                formData.dietType === value
                                  ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                                  : 'border-gray-700 bg-white/5 text-gray-300 hover:border-emerald-500/50'
                              }`}
                            >
                              {label}
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {/* Step 6: Health Conditions */}
                    {currentStep === 6 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-6"
                      >
                        <h2 className="text-3xl text-white mb-6">Health Conditions</h2>

                        <div className="grid grid-cols-2 gap-3">
                          {['Diabetes', 'Hypertension', 'Heart Disease', 'Asthma', 'Arthritis', 'None'].map((condition) => (
                            <label
                              key={condition}
                              className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                formData.healthConditions.includes(condition)
                                  ? 'border-emerald-500 bg-emerald-500/10'
                                  : 'border-gray-700 bg-white/5 hover:border-emerald-500/50'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={formData.healthConditions.includes(condition)}
                                onChange={() => toggleHealthCondition(condition)}
                                className="w-5 h-5 text-emerald-500 rounded focus:ring-emerald-500 bg-white/5 border-emerald-500/30"
                              />
                              <span className={`${
                                formData.healthConditions.includes(condition) ? 'text-emerald-400' : 'text-gray-300'
                              }`}>
                                {condition}
                              </span>
                            </label>
                          ))}
                        </div>

                        <div className="mt-6 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                          <p className="text-sm text-emerald-400 flex items-center gap-2">
                            <Check className="w-4 h-4" />
                            Your data is secure and encrypted
                          </p>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 7: Account Setup */}
                    {currentStep === 7 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-6"
                      >
                        <h2 className="text-3xl text-white mb-6">Create Your Account</h2>

                        <div>
                          <label className="block text-gray-300 mb-2">Email</label>
                          <input
                            type="email"
                            value={formData.email}
                            onChange={(e) => updateField('email', e.target.value)}
                            className="w-full px-4 py-3 bg-white/5 border border-emerald-500/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent backdrop-blur-sm"
                            placeholder="your@email.com"
                          />
                        </div>

                        <div>
                          <label className="block text-gray-300 mb-2">Password</label>
                          <input
                            type="password"
                            value={formData.password}
                            onChange={(e) => updateField('password', e.target.value)}
                            className="w-full px-4 py-3 bg-white/5 border border-emerald-500/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent backdrop-blur-sm"
                            placeholder="••••••••"
                          />
                        </div>
                      </motion.div>
                    )}
                  </div>

                  {/* Navigation Buttons */}
                  <div className="flex gap-4 mt-8">
                    {currentStep > 1 && (
                      <button
                        type="button"
                        onClick={prevStep}
                        className="flex items-center gap-2 px-6 py-3 border border-gray-600 text-gray-300 rounded-xl hover:bg-white/5 transition-all"
                      >
                        <ChevronLeft className="w-5 h-5" />
                        Back
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={currentStep < totalSteps ? nextStep : handleSubmit}
                      className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-green-500 text-white rounded-xl hover:from-emerald-600 hover:to-green-600 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)] hover:shadow-[0_0_30px_rgba(34,197,94,0.5)]"
                    >
                      <span>{currentStep < totalSteps ? 'Next Step' : 'Create My Account'}</span>
                      <ChevronRight className="w-5 h-5" />
                    </button>

                    {currentStep < totalSteps && (
                      <button
                        type="button"
                        onClick={nextStep}
                        className="px-6 py-3 text-gray-400 hover:text-gray-300 transition-colors"
                      >
                        Skip
                      </button>
                    )}
                  </div>
                </>
              ) : (
                // Success Screen
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <div className="inline-flex items-center justify-center w-24 h-24 bg-emerald-500/20 rounded-full mb-6">
                    <Sparkles className="w-12 h-12 text-emerald-400" />
                  </div>
                  <h2 className="text-4xl text-white mb-4">All Set!</h2>
                  <p className="text-gray-400 mb-8">Your personalized fitness journey starts now</p>
                  <button
                    onClick={onClose}
                    className="px-10 py-4 bg-gradient-to-r from-emerald-500 to-green-500 text-white rounded-xl hover:from-emerald-600 hover:to-green-600 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)]"
                  >
                    Let's Begin!
                  </button>
                </motion.div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
