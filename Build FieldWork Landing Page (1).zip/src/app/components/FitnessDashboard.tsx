import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Activity,
  TrendingUp,
  Zap,
  Flame,
  Apple,
  Dumbbell,
  Target,
  Calendar,
  Scale,
  Heart,
  Coffee,
  Utensils,
  Sun,
  Moon,
  Clock,
  Award,
  Bell,
  User,
  Search,
  Plus,
  ChevronRight,
  Smile,
  Frown,
  Meh,
  Battery,
} from 'lucide-react';

interface FitnessDashboardProps {
  onBack?: () => void;
}

export function FitnessDashboard({ onBack }: FitnessDashboardProps) {
  const [caloriesConsumed, setCaloriesConsumed] = useState(1450);
  const [caloriesGoal] = useState(2200);
  const [protein, setProtein] = useState(85);
  const [carbs, setCarbs] = useState(180);
  const [fat, setFat] = useState(45);
  const [steps, setSteps] = useState(8234);
  const [weight, setWeight] = useState(75);
  const [selectedMood, setSelectedMood] = useState<string>('');

  // BMR Calculator state
  const [bmrAge, setBmrAge] = useState(25);
  const [bmrWeight, setBmrWeight] = useState(75);
  const [bmrHeight, setBmrHeight] = useState(175);
  const [activityLevel, setActivityLevel] = useState(1.55);
  const [bmr, setBmr] = useState(0);
  const [tdee, setTdee] = useState(0);

  // Calculate BMR & TDEE
  useEffect(() => {
    // Mifflin-St Jeor Equation (for males)
    const calculatedBmr = 10 * bmrWeight + 6.25 * bmrHeight - 5 * bmrAge + 5;
    const calculatedTdee = calculatedBmr * activityLevel;
    setBmr(Math.round(calculatedBmr));
    setTdee(Math.round(calculatedTdee));
  }, [bmrAge, bmrWeight, bmrHeight, activityLevel]);

  const CircularProgress = ({ value, max, size = 120, strokeWidth = 12, color = '#FFD600' }: any) => {
    const percentage = (value / max) * 100;
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (percentage / 100) * circumference;

    return (
      <div className="relative" style={{ width: size, height: size }}>
        <svg className="transform -rotate-90" width={size} height={size}>
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#2A2A2A"
            strokeWidth={strokeWidth}
            fill="none"
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color}
            strokeWidth={strokeWidth}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1, ease: 'easeInOut' }}
            style={{
              filter: `drop-shadow(0 0 8px ${color})`,
            }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            className="text-2xl text-white"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {value}
          </motion.span>
          <span className="text-xs text-gray-400">/ {max}</span>
        </div>
      </div>
    );
  };

  const moods = [
    { icon: Smile, label: 'Happy', color: '#FFD600' },
    { icon: Battery, label: 'Energetic', color: '#4CAF50' },
    { icon: Meh, label: 'Tired', color: '#FF9800' },
    { icon: Frown, label: 'Stressed', color: '#F44336' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0B0B0B] via-[#121212] to-black">
      {/* Background Texture */}
      <div className="fixed inset-0 opacity-5 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0iI0ZGRiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjwvZz48L3N2Zz4=')]" />

      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-2xl border-b border-yellow-500/20">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-12">
              <button onClick={onBack} className="flex items-center gap-3 group">
                <Dumbbell className="w-8 h-8 text-[#FFD600] drop-shadow-[0_0_10px_#FFD600]" />
                <span className="text-2xl font-bold text-white drop-shadow-[0_0_15px_#FFD600]">
                  VITAPULSE
                </span>
              </button>
              <div className="hidden md:flex items-center gap-6">
                {['Dashboard', 'Fitness', 'Health', 'Profile'].map((item) => (
                  <a
                    key={item}
                    href={`#${item.toLowerCase()}`}
                    className="text-gray-300 hover:text-[#FFD600] transition-colors relative group"
                  >
                    {item}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#FFD600] group-hover:w-full transition-all shadow-[0_0_8px_#FFD600]" />
                  </a>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button className="w-10 h-10 rounded-full bg-white/5 border border-yellow-500/20 flex items-center justify-center hover:bg-yellow-500/10 hover:border-yellow-500/50 transition-all">
                <Bell className="w-5 h-5 text-gray-400 hover:text-[#FFD600]" />
              </button>
              <button className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-500 to-yellow-600 flex items-center justify-center shadow-[0_0_20px_rgba(255,214,0,0.5)]">
                <User className="w-5 h-5 text-black" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Motivational Quote */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-yellow-500/10 to-yellow-600/5 border border-yellow-500/20 p-6"
        >
          <Flame className="absolute top-4 right-4 w-24 h-24 text-yellow-500/10" />
          <div className="relative z-10">
            <p className="text-2xl md:text-3xl text-white mb-2">
              "No Pain, <span className="text-[#FFD600] drop-shadow-[0_0_10px_#FFD600]">No Gain</span>"
            </p>
            <p className="text-gray-400">Push harder today for a stronger tomorrow</p>
          </div>
        </motion.div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Calories Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ y: -8, boxShadow: '0 0 40px rgba(255, 214, 0, 0.3)' }}
            className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-6 border border-yellow-500/10 hover:border-yellow-500/30 transition-all"
          >
            <div className="flex items-center justify-between mb-4">
              <Flame className="w-8 h-8 text-[#FFD600]" />
              <span className="text-xs text-gray-400">Today</span>
            </div>
            <h3 className="text-sm text-gray-400 mb-2">Daily Calories</h3>
            <div className="flex items-center justify-center mb-4">
              <CircularProgress value={caloriesConsumed} max={caloriesGoal} />
            </div>
            <p className="text-center text-xs text-gray-400">
              {caloriesGoal - caloriesConsumed} cal remaining
            </p>
          </motion.div>

          {/* Protein Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            whileHover={{ y: -8, boxShadow: '0 0 40px rgba(255, 214, 0, 0.3)' }}
            className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-6 border border-yellow-500/10 hover:border-yellow-500/30 transition-all"
          >
            <div className="flex items-center justify-between mb-4">
              <Zap className="w-8 h-8 text-[#FFD600]" />
              <span className="text-xs text-gray-400">Protein</span>
            </div>
            <h3 className="text-sm text-gray-400 mb-2">Macros</h3>
            <div className="flex items-center justify-center mb-4">
              <CircularProgress value={protein} max={150} size={120} color="#FFD600" />
            </div>
            <p className="text-center text-xs text-gray-400">
              {150 - protein}g remaining
            </p>
          </motion.div>

          {/* Steps Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            whileHover={{ y: -8, boxShadow: '0 0 40px rgba(255, 214, 0, 0.3)' }}
            className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-6 border border-yellow-500/10 hover:border-yellow-500/30 transition-all"
          >
            <div className="flex items-center justify-between mb-4">
              <Activity className="w-8 h-8 text-[#FFD600]" />
              <span className="text-xs text-gray-400">Activity</span>
            </div>
            <h3 className="text-sm text-gray-400 mb-2">Steps Today</h3>
            <div className="flex items-center justify-center mb-4">
              <CircularProgress value={steps} max={10000} size={120} color="#FFD600" />
            </div>
            <p className="text-center text-xs text-gray-400">
              {10000 - steps} steps to go
            </p>
          </motion.div>

          {/* Weight Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            whileHover={{ y: -8, boxShadow: '0 0 40px rgba(255, 214, 0, 0.3)' }}
            className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-6 border border-yellow-500/10 hover:border-yellow-500/30 transition-all"
          >
            <div className="flex items-center justify-between mb-4">
              <Scale className="w-8 h-8 text-[#FFD600]" />
              <span className="text-xs text-gray-400">Current</span>
            </div>
            <h3 className="text-sm text-gray-400 mb-2">Body Weight</h3>
            <div className="flex flex-col items-center justify-center py-8">
              <motion.p
                className="text-5xl text-white mb-2"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 }}
              >
                {weight}
              </motion.p>
              <span className="text-gray-400">kg</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-green-500">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs">-2kg this month</span>
            </div>
          </motion.div>
        </div>

        {/* BMR/TDEE Calculator */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-8 border border-yellow-500/10"
        >
          <div className="flex items-center gap-3 mb-6">
            <Target className="w-8 h-8 text-[#FFD600]" />
            <h2 className="text-2xl text-white">BMR & TDEE Calculator</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <label className="block text-gray-400 mb-2">Age</label>
                <input
                  type="range"
                  min="18"
                  max="80"
                  value={bmrAge}
                  onChange={(e) => setBmrAge(parseInt(e.target.value))}
                  className="w-full accent-yellow-500"
                />
                <span className="text-[#FFD600]">{bmrAge} years</span>
              </div>

              <div>
                <label className="block text-gray-400 mb-2">Weight (kg)</label>
                <input
                  type="range"
                  min="40"
                  max="150"
                  value={bmrWeight}
                  onChange={(e) => setBmrWeight(parseInt(e.target.value))}
                  className="w-full accent-yellow-500"
                />
                <span className="text-[#FFD600]">{bmrWeight} kg</span>
              </div>

              <div>
                <label className="block text-gray-400 mb-2">Height (cm)</label>
                <input
                  type="range"
                  min="140"
                  max="220"
                  value={bmrHeight}
                  onChange={(e) => setBmrHeight(parseInt(e.target.value))}
                  className="w-full accent-yellow-500"
                />
                <span className="text-[#FFD600]">{bmrHeight} cm</span>
              </div>

              <div>
                <label className="block text-gray-400 mb-2">Activity Level</label>
                <select
                  value={activityLevel}
                  onChange={(e) => setActivityLevel(parseFloat(e.target.value))}
                  className="w-full bg-black/40 border border-yellow-500/20 rounded-lg px-4 py-3 text-white outline-none focus:border-yellow-500/50"
                >
                  <option value={1.2}>Sedentary</option>
                  <option value={1.375}>Light Activity</option>
                  <option value={1.55}>Moderate Activity</option>
                  <option value={1.725}>Very Active</option>
                  <option value={1.9}>Extremely Active</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col justify-center gap-6">
              <div className="bg-black/40 rounded-xl p-6 border border-yellow-500/20">
                <p className="text-gray-400 mb-2">Basal Metabolic Rate (BMR)</p>
                <motion.p
                  className="text-5xl text-[#FFD600] drop-shadow-[0_0_20px_#FFD600]"
                  key={bmr}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  {bmr}
                </motion.p>
                <p className="text-sm text-gray-500 mt-2">calories/day</p>
              </div>

              <div className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/5 rounded-xl p-6 border border-yellow-500/30">
                <p className="text-gray-400 mb-2">Total Daily Energy Expenditure</p>
                <motion.p
                  className="text-5xl text-white drop-shadow-[0_0_20px_#FFD600]"
                  key={tdee}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  {tdee}
                </motion.p>
                <p className="text-sm text-gray-500 mt-2">calories/day</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Nutrition Tracking */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-8 border border-yellow-500/10"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Apple className="w-8 h-8 text-[#FFD600]" />
              <h2 className="text-2xl text-white">Nutrition Tracker</h2>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400 transition-all shadow-[0_0_20px_rgba(255,214,0,0.4)]">
              <Plus className="w-4 h-4" />
              Add Food
            </button>
          </div>

          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                placeholder="Search for food..."
                className="w-full bg-black/40 border border-yellow-500/20 rounded-lg pl-12 pr-4 py-3 text-white outline-none focus:border-yellow-500/50"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { icon: Coffee, label: 'Breakfast', calories: 420 },
              { icon: Sun, label: 'Lunch', calories: 650 },
              { icon: Utensils, label: 'Dinner', calories: 280 },
              { icon: Moon, label: 'Snacks', calories: 100 },
            ].map((meal, index) => (
              <motion.div
                key={meal.label}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(255, 214, 0, 0.2)' }}
                className="bg-black/40 rounded-xl p-4 border border-yellow-500/10 hover:border-yellow-500/30 transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <meal.icon className="w-6 h-6 text-[#FFD600]" />
                    <span className="text-white">{meal.label}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-[#FFD600]">{meal.calories}</p>
                    <p className="text-xs text-gray-500">cal</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Macro Breakdown */}
          <div className="mt-6 grid grid-cols-3 gap-4">
            {[
              { label: 'Protein', value: protein, max: 150, color: '#FFD600' },
              { label: 'Carbs', value: carbs, max: 250, color: '#FFA500' },
              { label: 'Fat', value: fat, max: 70, color: '#FF6B6B' },
            ].map((macro) => (
              <div key={macro.label} className="bg-black/40 rounded-xl p-4">
                <p className="text-gray-400 text-sm mb-2">{macro.label}</p>
                <p className="text-2xl text-white mb-2">{macro.value}g</p>
                <div className="h-2 bg-[#2A2A2A] rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ backgroundColor: macro.color }}
                    initial={{ width: '0%' }}
                    whileInView={{ width: `${Math.min(Math.max(((macro.value || 0) / (macro.max || 1)) * 100, 0), 100)}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Mood Tracker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-8 border border-yellow-500/10"
        >
          <div className="flex items-center gap-3 mb-6">
            <Heart className="w-8 h-8 text-[#FFD600]" />
            <h2 className="text-2xl text-white">How are you feeling today?</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {moods.map((mood) => (
              <motion.button
                key={mood.label}
                onClick={() => setSelectedMood(mood.label)}
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.95 }}
                className={`p-6 rounded-xl border-2 transition-all ${
                  selectedMood === mood.label
                    ? 'border-yellow-500 bg-yellow-500/10 shadow-[0_0_30px_rgba(255,214,0,0.3)]'
                    : 'border-yellow-500/10 bg-black/40 hover:border-yellow-500/30'
                }`}
              >
                <motion.div
                  animate={selectedMood === mood.label ? { y: [0, -10, 0] } : {}}
                  transition={{ duration: 0.5 }}
                >
                  <mood.icon
                    className="w-12 h-12 mx-auto mb-3"
                    style={{ color: selectedMood === mood.label ? mood.color : '#666' }}
                  />
                </motion.div>
                <p className={`text-sm ${selectedMood === mood.label ? 'text-white' : 'text-gray-400'}`}>
                  {mood.label}
                </p>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Workout Plan Generator */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-[#1E1E1E] to-[#2A2A2A] rounded-2xl p-8 border border-yellow-500/10"
        >
          <div className="flex items-center gap-3 mb-6">
            <Dumbbell className="w-8 h-8 text-[#FFD600]" />
            <h2 className="text-2xl text-white">Today's Workout</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { name: 'Bench Press', sets: '4 x 10', category: 'Chest' },
              { name: 'Squats', sets: '5 x 8', category: 'Legs' },
              { name: 'Deadlifts', sets: '3 x 6', category: 'Back' },
              { name: 'Pull-ups', sets: '4 x 12', category: 'Back' },
              { name: 'Shoulder Press', sets: '4 x 10', category: 'Shoulders' },
              { name: 'Bicep Curls', sets: '3 x 12', category: 'Arms' },
            ].map((exercise, index) => (
              <motion.div
                key={exercise.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                whileHover={{
                  y: -8,
                  boxShadow: '0 10px 40px rgba(255, 214, 0, 0.3)',
                }}
                className="bg-black/40 rounded-xl p-6 border border-yellow-500/10 hover:border-yellow-500/30 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-gray-500 bg-yellow-500/10 px-3 py-1 rounded-full">
                    {exercise.category}
                  </span>
                  <Award className="w-5 h-5 text-yellow-500/50 group-hover:text-yellow-500 transition-colors" />
                </div>
                <h3 className="text-white mb-2">{exercise.name}</h3>
                <p className="text-[#FFD600] text-sm">{exercise.sets}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
