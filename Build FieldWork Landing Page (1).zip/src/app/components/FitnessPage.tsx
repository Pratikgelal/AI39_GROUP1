import { useState, useEffect, useRef } from 'react';
import { motion, useInView, useScroll, useTransform, AnimatePresence } from 'motion/react';
import {
  Flame, Apple, TrendingUp, Dumbbell, Heart, Smile, Meh, Frown,
  ChevronDown, Scale, Target, Calendar, Plus, Search, X, Activity,
  Info, Trash2, Zap
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ContactSection } from './ContactSection';

// ======================== SAMPLE DATA ========================
const weightData = [
  { week: 'Week 1', weight: 82 },
  { week: 'Week 2', weight: 81.5 },
  { week: 'Week 3', weight: 81 },
  { week: 'Week 4', weight: 80.2 },
  { week: 'Week 5', weight: 79.8 },
  { week: 'Week 6', weight: 79.2 },
  { week: 'Week 7', weight: 78.5 },
  { week: 'Week 8', weight: 78 },
];

const weeklyWorkout = [
  {
    day: 'Sunday',
    plan: 'Chest + Triceps + Wrist',
    icon: '💪',
    exercises: [
      { name: 'Bench Press', sets: '4', reps: '8-12', rest: '90s' },
      { name: 'Incline Dumbbell Press', sets: '3', reps: '10-12', rest: '60s' },
      { name: 'Cable Flyes', sets: '3', reps: '12-15', rest: '60s' },
      { name: 'Tricep Dips', sets: '3', reps: '10-12', rest: '60s' },
      { name: 'Overhead Tricep Extension', sets: '3', reps: '12-15', rest: '60s' },
      { name: 'Wrist Curls', sets: '3', reps: '15-20', rest: '45s' }
    ]
  },
  {
    day: 'Monday',
    plan: 'Back + Biceps + Abs',
    icon: '🦵',
    exercises: [
      { name: 'Deadlift', sets: '4', reps: '6-8', rest: '120s' },
      { name: 'Pull-ups', sets: '3', reps: '8-12', rest: '90s' },
      { name: 'Barbell Rows', sets: '4', reps: '8-10', rest: '90s' },
      { name: 'Bicep Curls', sets: '3', reps: '10-12', rest: '60s' },
      { name: 'Hammer Curls', sets: '3', reps: '10-12', rest: '60s' },
      { name: 'Plank Hold', sets: '3', reps: '60s', rest: '60s' }
    ]
  },
  {
    day: 'Tuesday',
    plan: 'Legs + Shoulders + Wrist',
    icon: '🏋️',
    exercises: [
      { name: 'Squats', sets: '4', reps: '8-12', rest: '120s' },
      { name: 'Leg Press', sets: '3', reps: '12-15', rest: '90s' },
      { name: 'Lunges', sets: '3', reps: '10/leg', rest: '60s' },
      { name: 'Overhead Press', sets: '4', reps: '8-10', rest: '90s' },
      { name: 'Lateral Raises', sets: '3', reps: '12-15', rest: '60s' },
      { name: 'Reverse Wrist Curls', sets: '3', reps: '15-20', rest: '45s' }
    ]
  },
  {
    day: 'Wednesday',
    plan: 'Chest + Triceps + Abs',
    icon: '💪',
    exercises: [
      { name: 'Dumbbell Bench Press', sets: '4', reps: '8-12', rest: '90s' },
      { name: 'Push-ups', sets: '3', reps: '15-20', rest: '60s' },
      { name: 'Chest Dips', sets: '3', reps: '10-12', rest: '60s' },
      { name: 'Skull Crushers', sets: '3', reps: '10-12', rest: '60s' },
      { name: 'Rope Pushdowns', sets: '3', reps: '12-15', rest: '60s' },
      { name: 'Russian Twists', sets: '3', reps: '20', rest: '45s' }
    ]
  },
  {
    day: 'Thursday',
    plan: 'Back + Biceps + Wrist',
    icon: '🦵',
    exercises: [
      { name: 'Lat Pulldowns', sets: '4', reps: '10-12', rest: '90s' },
      { name: 'Seated Cable Rows', sets: '3', reps: '10-12', rest: '90s' },
      { name: 'T-Bar Rows', sets: '3', reps: '10-12', rest: '90s' },
      { name: 'Preacher Curls', sets: '3', reps: '10-12', rest: '60s' },
      { name: 'Cable Curls', sets: '3', reps: '12-15', rest: '60s' },
      { name: 'Wrist Rollers', sets: '3', reps: '3 rolls', rest: '60s' }
    ]
  },
  {
    day: 'Friday',
    plan: 'Legs + Shoulders + Abs',
    icon: '🏋️',
    exercises: [
      { name: 'Romanian Deadlift', sets: '4', reps: '8-10', rest: '90s' },
      { name: 'Leg Curls', sets: '3', reps: '12-15', rest: '60s' },
      { name: 'Calf Raises', sets: '4', reps: '15-20', rest: '60s' },
      { name: 'Arnold Press', sets: '3', reps: '10-12', rest: '90s' },
      { name: 'Front Raises', sets: '3', reps: '12-15', rest: '60s' },
      { name: 'Leg Raises', sets: '3', reps: '15-20', rest: '45s' }
    ]
  },
  {
    day: 'Saturday',
    plan: 'Rest Day',
    icon: '🛌',
    exercises: []
  }
];

const sampleFoods = [
  { name: 'Grilled Chicken Breast', calories: 165, protein: 31, carbs: 0, fats: 3.6, fiber: 0, per: '100g' },
  { name: 'Brown Rice', calories: 218, protein: 5, carbs: 45, fats: 2, fiber: 3.5, per: '1 cup' },
  { name: 'Greek Yogurt', calories: 100, protein: 17, carbs: 6, fats: 0.4, fiber: 0, per: '150g' },
  { name: 'Banana', calories: 105, protein: 1.3, carbs: 27, fats: 0.4, fiber: 3.1, per: '1 medium' },
  { name: 'Almonds', calories: 164, protein: 6, carbs: 6, fats: 14, fiber: 3.5, per: '28g' },
  { name: 'Eggs', calories: 140, protein: 12, carbs: 1, fats: 10, fiber: 0, per: '2 large' },
  { name: 'Sweet Potato', calories: 112, protein: 2, carbs: 26, fats: 0.1, fiber: 3.8, per: '100g' },
  { name: 'Salmon', calories: 206, protein: 22, carbs: 0, fats: 12, fiber: 0, per: '100g' },
  { name: 'Broccoli', calories: 55, protein: 3.7, carbs: 11, fats: 0.6, fiber: 2.4, per: '150g' },
  { name: 'Oatmeal', calories: 389, protein: 17, carbs: 66, fats: 7, fiber: 10.6, per: '100g' },
  { name: 'Avocado', calories: 160, protein: 2, carbs: 9, fats: 15, fiber: 7, per: '100g' },
  { name: 'Whey Protein', calories: 120, protein: 24, carbs: 3, fats: 1.5, fiber: 0, per: '30g' },
];

// ======================== COMPONENTS ========================
function ScrollIndicator() {
  return (
    <motion.div
      animate={{ y: [0, 12, 0] }}
      transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
      className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
    >
      <span className="text-white/60" style={{ fontSize: '12px', letterSpacing: '2px' }}>SCROLL</span>
      <ChevronDown className="w-6 h-6 text-[#FFD600]" />
    </motion.div>
  );
}

function AnimatedCounter({ target, suffix = '' }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView) return;
    let start = 0;
    const duration = 2000;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [isInView, target]);

  return <div ref={ref}>{count}{suffix}</div>;
}

function SectionReveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

// ======================== MAIN COMPONENT ========================
export function FitnessPage({ onBack }: { onBack: () => void }) {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [moodMessage, setMoodMessage] = useState('');
  const [graphPeriod, setGraphPeriod] = useState<'weekly' | 'monthly'>('weekly');
  const [calorieGoal, setCalorieGoal] = useState(2200);
  const [weight, setWeight] = useState(75);
  const [height, setHeight] = useState(175);
  const [age, setAge] = useState(28);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [activityLevel, setActivityLevel] = useState(1.55);
  const [fitnessGoal, setFitnessGoal] = useState<'loss' | 'maintain' | 'gain'>('loss');
  const [searchQuery, setSearchQuery] = useState('');
  const [newFoodQuantity, setNewFoodQuantity] = useState('100');
  const [activeNavSection, setActiveNavSection] = useState('bmi');
  const [bmiSaved, setBmiSaved] = useState(false);
  const [calorieSaved, setCalorieSaved] = useState(false);
  const [macroSaved, setMacroSaved] = useState(false);
  const [dailyLogSaved, setDailyLogSaved] = useState(false);
  const [expandedDay, setExpandedDay] = useState<string | null>(null);
  const [meals, setMeals] = useState<{ breakfast: any[]; lunch: any[]; dinner: any[]; snacks: any[] }>({
    breakfast: [],
    lunch: [],
    dinner: [],
    snacks: [],
  });

  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroY = useTransform(scrollYProgress, [0, 1], ['0%', '30%']);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  const calculateBMI = () => {
    const heightInMeters = height / 100;
    return (weight / (heightInMeters * heightInMeters));
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { status: 'Underweight', color: '#4A9EFF' };
    if (bmi < 25) return { status: 'Normal', color: '#10B981' };
    if (bmi < 30) return { status: 'Overweight', color: '#F59E0B' };
    return { status: 'Obese', color: '#EF4444' };
  };

  const calculateBMR = () => {
    const genderOffset = gender === 'male' ? 5 : -161;
    return Math.round(10 * weight + 6.25 * height - 5 * age + genderOffset);
  };

  const calculateTDEE = () => {
    return Math.round(calculateBMR() * activityLevel);
  };

  const getTargetCalories = () => {
    const tdee = calculateTDEE();
    if (fitnessGoal === 'loss') return tdee - 400;
    if (fitnessGoal === 'gain') return tdee + 300;
    return tdee;
  };

  const calculateMacros = () => {
    const targetCals = getTargetCalories();
    let proteinMultiplier = 1.6;
    if (fitnessGoal === 'gain') proteinMultiplier = 2.0;
    else if (fitnessGoal === 'loss') proteinMultiplier = 2.2;

    const protein = Math.round(weight * proteinMultiplier);
    const proteinCals = protein * 4;
    const fatCals = targetCals * 0.25;
    const fats = Math.round(fatCals / 9);
    const carbCals = targetCals - proteinCals - fatCals;
    const carbs = Math.round(carbCals / 4);

    return { protein, carbs, fats };
  };

  const bmi = calculateBMI();
  const bmiCategory = getBMICategory(bmi);
  const macros = calculateMacros();

  const moods = [
    { icon: '😊', label: 'Great', value: 5 },
    { icon: '🙂', label: 'Good', value: 4 },
    { icon: '😐', label: 'Okay', value: 3 },
    { icon: '😕', label: 'Low', value: 2 },
    { icon: '😞', label: 'Bad', value: 1 },
  ];

  const filteredFoods = searchQuery
    ? sampleFoods.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  const totalCalories = [...meals.breakfast, ...meals.lunch, ...meals.dinner, ...meals.snacks].reduce((sum, f) => sum + f.calories, 0);
  const totalProtein = [...meals.breakfast, ...meals.lunch, ...meals.dinner, ...meals.snacks].reduce((sum, f) => sum + f.protein, 0);
  const totalCarbs = [...meals.breakfast, ...meals.lunch, ...meals.dinner, ...meals.snacks].reduce((sum, f) => sum + f.carbs, 0);
  const totalFats = [...meals.breakfast, ...meals.lunch, ...meals.dinner, ...meals.snacks].reduce((sum, f) => sum + f.fats, 0);
  const totalFiber = [...meals.breakfast, ...meals.lunch, ...meals.dinner, ...meals.snacks].reduce((sum, f) => sum + (f.fiber || 0), 0);

  const remainingCalories = calculateTDEE() - totalCalories;

  const addFood = (food: any, mealType: 'breakfast' | 'lunch' | 'dinner' | 'snacks') => {
    setMeals(prev => ({ ...prev, [mealType]: [...prev[mealType], { ...food, id: Date.now() }] }));
    setSearchQuery('');
  };


  const removeFood = (mealType: 'breakfast' | 'lunch' | 'dinner' | 'snacks', id: number) => {
    setMeals(prev => ({ ...prev, [mealType]: prev[mealType].filter((f) => f.id !== id) }));
  };

  const scrollToSection = (sectionId: string) => {
    setActiveNavSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen" style={{ background: '#0B0B0B' }}>
      {/* FITNESS NAVBAR */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="fixed top-0 left-0 right-0 z-50 px-6 py-4"
        style={{
          background: 'rgba(11,11,11,0.85)',
          backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(255,214,0,0.25)',
          boxShadow: '0 4px 24px rgba(255,214,0,0.08)'
        }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onBack}
            className="flex items-center gap-2"
          >
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FFD600, #FF9500)' }}>
              <Dumbbell className="w-5 h-5 text-black" />
            </div>
            <span className="text-white font-bold" style={{ fontSize: '18px' }}>VitaPulse</span>
          </motion.button>

          {/* Menu */}
          <div className="flex items-center gap-1">
            {[
              { id: 'bmi', label: 'BMI' },
              { id: 'nutrition', label: 'Diet' },
              { id: 'progress', label: 'Progress' },
              { id: 'workout', label: 'Workout Plan' }
            ].map((item) => (
              <motion.button
                key={item.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection(item.id)}
                className="relative px-5 py-2 rounded-lg"
                style={{
                  color: activeNavSection === item.id ? '#FFD600' : '#fff',
                  fontWeight: 700,
                  fontSize: '13px',
                  letterSpacing: '1px',
                  textTransform: 'uppercase',
                  background: activeNavSection === item.id ? 'rgba(255,214,0,0.1)' : 'transparent'
                }}
              >
                {item.label}
                {activeNavSection === item.id && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute bottom-0 left-0 right-0 h-0.5"
                    style={{ background: '#FFD600', boxShadow: '0 0 8px #FFD600' }}
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </motion.button>
            ))}
          </div>
        </div>
      </motion.nav>

      {/* HERO SECTION */}
      <section ref={heroRef} className="relative h-screen overflow-hidden">
        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="absolute inset-0"
        >
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(11,11,11,0.4), rgba(11,11,11,0.9))' }} />
          <img
            src="https://images.unsplash.com/photo-1770513649465-2c60c8039806?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
            alt="Gym"
            className="w-full h-full object-cover"
          />
        </motion.div>
        <div className="relative z-10 h-full flex flex-col items-center justify-center px-6 text-center">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onBack}
            className="absolute top-8 left-6 w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)' }}
          >
            <X className="w-5 h-5 text-white" />
          </motion.button>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <motion.h1
              className="text-white mb-4"
              style={{ fontSize: '72px', fontWeight: 800, lineHeight: 1, letterSpacing: '-2px', textShadow: '0 0 40px rgba(255,214,0,0.3)' }}
            >
              Transform<br />Your Body
            </motion.h1>
            <p className="text-white/70 max-w-md mx-auto mb-12" style={{ fontSize: '18px', lineHeight: 1.6 }}>
              Track nutrition, monitor progress, crush your fitness goals
            </p>

            {/* COMBINED STATS ROW */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="max-w-4xl mx-auto rounded-2xl p-6"
              style={{ background: '#1A1A1A', border: '1px solid rgba(255,214,0,0.2)' }}
            >
              <div className="grid grid-cols-3 divide-x" style={{ divideColor: 'rgba(255,214,0,0.15)' }}>
                {[
                  { icon: Flame, label: 'Calories Today', value: totalCalories, unit: '' },
                  { icon: Apple, label: 'Macros (P/C/F)', value: `${totalProtein}g / ${totalCarbs}g / ${totalFats}g`, unit: '' },
                  { icon: Scale, label: 'Current Weight', value: '78.0', unit: 'kg' }
                ].map((stat, i) => {
                  const Icon = stat.icon;
                  return (
                    <div key={stat.label} className="px-6 text-center">
                      <div className="flex items-center justify-center gap-2 mb-3">
                        <Icon className="w-5 h-5 text-[#FFD600]" />
                        <span className="text-white/50" style={{ fontSize: '12px', letterSpacing: '1px', textTransform: 'uppercase' }}>
                          {stat.label}
                        </span>
                      </div>
                      <div className="text-white" style={{ fontSize: '36px', fontWeight: 700, lineHeight: 1 }}>
                        {typeof stat.value === 'number' ? <AnimatedCounter target={stat.value} /> : stat.value}
                        {stat.unit && <span className="text-white/60 ml-2" style={{ fontSize: '18px' }}>{stat.unit}</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </motion.div>
        </div>
        <ScrollIndicator />
      </section>

      {/* FITNESS INTELLIGENCE SYSTEM */}
      <section id="bmi" className="py-20 px-6" style={{ background: '#0B0B0B' }}>
        <SectionReveal>
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-4">
              <h2 className="text-white mb-3" style={{ fontSize: '52px', fontWeight: 700, letterSpacing: '-1px' }}>
                Fitness Intelligence System
              </h2>
              <p className="text-white/60 mb-2" style={{ fontSize: '16px' }}>AI-powered analysis and personalized recommendations</p>
              <div className="flex items-center justify-center gap-2 text-white/40" style={{ fontSize: '12px' }}>
                <div className="w-1.5 h-1.5 rounded-full bg-[#FFD600] animate-pulse" />
                <span>Based on your body metrics · Updated in real-time</span>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mt-12 mb-8">
              {/* CARD 1: BMI CALCULATOR */}
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                whileHover={{ y: -8, boxShadow: '0 30px 60px rgba(255,214,0,0.3)' }}
                className="p-8 rounded-2xl relative"
                style={{
                  background: 'linear-gradient(145deg, #1A1A1A 0%, #141414 100%)',
                  border: '2px solid transparent',
                  backgroundImage: 'linear-gradient(145deg, #1A1A1A, #141414), linear-gradient(135deg, rgba(255,214,0,0.4), rgba(255,149,0,0.2))',
                  backgroundOrigin: 'border-box',
                  backgroundClip: 'padding-box, border-box',
                  boxShadow: '0 8px 32px rgba(255,214,0,0.15)'
                }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, rgba(255,214,0,0.2), rgba(255,149,0,0.1))' }}>
                    <Target className="w-7 h-7 text-[#FFD600]" />
                  </div>
                  <div>
                    <p className="text-white/50" style={{ fontSize: '11px', letterSpacing: '2px', textTransform: 'uppercase' }}>BMI Calculator</p>
                    <p className="text-[#FFD600]" style={{ fontSize: '13px', fontWeight: 600 }}>Body Analysis</p>
                  </div>
                </div>

                {/* Inputs */}
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-white/60 mb-2" style={{ fontSize: '11px', letterSpacing: '1px' }}>Height (cm)</label>
                    <input
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(Number(e.target.value))}
                      className="w-full bg-black/40 border rounded-xl px-4 py-3 text-white outline-none transition-all"
                      style={{
                        borderColor: 'rgba(255,214,0,0.2)',
                        fontSize: '16px',
                        fontWeight: 600
                      }}
                      onFocus={(e) => e.target.style.borderColor = '#FFD600'}
                      onBlur={(e) => e.target.style.borderColor = 'rgba(255,214,0,0.2)'}
                    />
                  </div>
                  <div>
                    <label className="block text-white/60 mb-2" style={{ fontSize: '11px', letterSpacing: '1px' }}>Weight (kg)</label>
                    <input
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(Number(e.target.value))}
                      className="w-full bg-black/40 border rounded-xl px-4 py-3 text-white outline-none transition-all"
                      style={{
                        borderColor: 'rgba(255,214,0,0.2)',
                        fontSize: '16px',
                        fontWeight: 600
                      }}
                      onFocus={(e) => e.target.style.borderColor = '#FFD600'}
                      onBlur={(e) => e.target.style.borderColor = 'rgba(255,214,0,0.2)'}
                    />
                  </div>
                </div>

                {/* BMI Result */}
                <div className="text-center py-6 px-4 rounded-xl mb-4" style={{ background: 'rgba(0,0,0,0.3)', border: `1px solid ${bmiCategory.color}30` }}>
                  <motion.div
                    key={bmi}
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                    className="text-white mb-2"
                    style={{ fontSize: '48px', fontWeight: 800, lineHeight: 1 }}
                  >
                    {bmi.toFixed(1)}
                  </motion.div>
                  <div className="inline-block px-4 py-1.5 rounded-full" style={{ background: `${bmiCategory.color}20`, border: `1px solid ${bmiCategory.color}` }}>
                    <span style={{ color: bmiCategory.color, fontSize: '12px', fontWeight: 700, letterSpacing: '1px' }}>
                      {bmiCategory.status.toUpperCase()}
                    </span>
                  </div>
                </div>

                {/* BMI Categories */}
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: 'Underweight', range: '< 18.5', color: '#4A9EFF', active: bmi < 18.5 },
                    { label: 'Normal', range: '18.5-24.9', color: '#10B981', active: bmi >= 18.5 && bmi < 25 },
                    { label: 'Overweight', range: '25-29.9', color: '#F59E0B', active: bmi >= 25 && bmi < 30 },
                    { label: 'Obese', range: '≥ 30', color: '#EF4444', active: bmi >= 30 }
                  ].map((cat) => (
                    <div
                      key={cat.label}
                      className="p-2 rounded-lg text-center transition-all"
                      style={{
                        background: cat.active ? `${cat.color}20` : 'rgba(255,255,255,0.03)',
                        border: `1px solid ${cat.active ? cat.color : 'rgba(255,255,255,0.05)'}`,
                        transform: cat.active ? 'scale(1.05)' : 'scale(1)'
                      }}
                    >
                      <div style={{ color: cat.active ? cat.color : 'rgba(255,255,255,0.3)', fontSize: '10px', fontWeight: 700 }}>{cat.label}</div>
                      <div style={{ color: 'rgba(255,255,255,0.25)', fontSize: '9px' }}>{cat.range}</div>
                    </div>
                  ))}
                </div>

                {/* What to do next */}
                <div className="mt-6 p-4 rounded-xl" style={{ background: 'rgba(255,214,0,0.05)', border: '1px solid rgba(255,214,0,0.15)' }}>
                  <p className="text-white/70 mb-2" style={{ fontSize: '12px', fontWeight: 600 }}>What to do next:</p>
                  <p className="text-white/50" style={{ fontSize: '11px', lineHeight: 1.6 }}>
                    {bmiCategory.status === 'Normal' || bmiCategory.status === 'Normal Weight'
                      ? 'You are in Normal range. Maintain calories and focus on muscle building.'
                      : bmiCategory.status === 'Underweight'
                      ? 'You are Underweight. Increase calories with protein-rich foods.'
                      : bmiCategory.status === 'Overweight'
                      ? 'You are Overweight. Focus on calorie deficit and regular exercise.'
                      : 'Consult a healthcare professional for personalized guidance.'}
                  </p>
                </div>

                {/* Save Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setBmiSaved(true)}
                  className="w-full mt-4 py-3 rounded-xl flex items-center justify-center gap-2"
                  style={{
                    background: bmiSaved ? 'rgba(16,185,129,0.15)' : 'rgba(255,214,0,0.1)',
                    border: `1px solid ${bmiSaved ? '#10B981' : 'rgba(255,214,0,0.3)'}`,
                    color: bmiSaved ? '#10B981' : '#FFD600',
                    fontSize: '13px',
                    fontWeight: 600
                  }}
                >
                  {bmiSaved ? '✓ Saved Successfully' : 'Save Data'}
                </motion.button>
              </motion.div>

              {/* CARD 2: CALORIE CALCULATOR */}
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                whileHover={{ y: -8, boxShadow: '0 30px 60px rgba(255,214,0,0.3)' }}
                className="p-8 rounded-2xl relative"
                style={{
                  background: 'linear-gradient(145deg, #1A1A1A 0%, #141414 100%)',
                  border: '2px solid transparent',
                  backgroundImage: 'linear-gradient(145deg, #1A1A1A, #141414), linear-gradient(135deg, rgba(255,214,0,0.4), rgba(255,149,0,0.2))',
                  backgroundOrigin: 'border-box',
                  backgroundClip: 'padding-box, border-box',
                  boxShadow: '0 8px 32px rgba(255,214,0,0.15)'
                }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, rgba(255,214,0,0.2), rgba(255,149,0,0.1))' }}>
                    <Flame className="w-7 h-7 text-[#FFD600]" />
                  </div>
                  <div>
                    <p className="text-white/50" style={{ fontSize: '11px', letterSpacing: '2px', textTransform: 'uppercase' }}>Calorie Calculator</p>
                    <p className="text-[#FFD600]" style={{ fontSize: '13px', fontWeight: 600 }}>Daily Targets</p>
                  </div>
                </div>

                {/* Inputs */}
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-white/60 mb-2" style={{ fontSize: '11px', letterSpacing: '1px' }}>Age</label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(Number(e.target.value))}
                      className="w-full bg-black/40 border rounded-xl px-4 py-3 text-white outline-none transition-all"
                      style={{ borderColor: 'rgba(255,214,0,0.2)', fontSize: '16px', fontWeight: 600 }}
                      onFocus={(e) => e.target.style.borderColor = '#FFD600'}
                      onBlur={(e) => e.target.style.borderColor = 'rgba(255,214,0,0.2)'}
                    />
                  </div>
                  <div>
                    <label className="block text-white/60 mb-2" style={{ fontSize: '11px', letterSpacing: '1px' }}>Gender</label>
                    <div className="grid grid-cols-2 gap-2">
                      {(['male', 'female'] as const).map((g) => (
                        <button
                          key={g}
                          onClick={() => setGender(g)}
                          className="py-3 rounded-xl capitalize transition-all"
                          style={{
                            background: gender === g ? 'rgba(255,214,0,0.2)' : 'rgba(255,255,255,0.05)',
                            border: `1px solid ${gender === g ? '#FFD600' : 'rgba(255,255,255,0.1)'}`,
                            color: gender === g ? '#FFD600' : 'rgba(255,255,255,0.5)',
                            fontSize: '13px',
                            fontWeight: 600
                          }}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-white/60 mb-2" style={{ fontSize: '11px', letterSpacing: '1px' }}>Activity Level</label>
                    <select
                      value={activityLevel}
                      onChange={(e) => setActivityLevel(Number(e.target.value))}
                      className="w-full bg-black/40 border rounded-xl px-4 py-3 text-white outline-none transition-all"
                      style={{ borderColor: 'rgba(255,214,0,0.2)', fontSize: '13px', fontWeight: 600 }}
                      onFocus={(e) => e.target.style.borderColor = '#FFD600'}
                      onBlur={(e) => e.target.style.borderColor = 'rgba(255,214,0,0.2)'}
                    >
                      <option value={1.2}>Sedentary</option>
                      <option value={1.375}>Light</option>
                      <option value={1.55}>Moderate</option>
                      <option value={1.725}>Active</option>
                      <option value={1.9}>Very Active</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-white/60 mb-2" style={{ fontSize: '11px', letterSpacing: '1px' }}>Goal</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['loss', 'maintain', 'gain'] as const).map((g) => (
                        <button
                          key={g}
                          onClick={() => setFitnessGoal(g)}
                          className="py-2.5 rounded-xl capitalize transition-all"
                          style={{
                            background: fitnessGoal === g ? 'rgba(255,214,0,0.2)' : 'rgba(255,255,255,0.05)',
                            border: `1px solid ${fitnessGoal === g ? '#FFD600' : 'rgba(255,255,255,0.1)'}`,
                            color: fitnessGoal === g ? '#FFD600' : 'rgba(255,255,255,0.5)',
                            fontSize: '11px',
                            fontWeight: 600
                          }}
                        >
                          {g === 'loss' ? 'Fat Loss' : g === 'gain' ? 'Muscle' : 'Maintain'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Results */}
                <div className="space-y-3">
                  <div className="p-4 rounded-xl" style={{ background: 'rgba(255,214,0,0.08)', border: '1px solid rgba(255,214,0,0.2)' }}>
                    <div className="flex items-center justify-between">
                      <span className="text-white/60" style={{ fontSize: '11px', letterSpacing: '1px' }}>MAINTENANCE</span>
                      <Zap className="w-4 h-4 text-[#FFD600]" />
                    </div>
                    <motion.div
                      key={calculateTDEE()}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-white mt-1"
                      style={{ fontSize: '28px', fontWeight: 800 }}
                    >
                      {calculateTDEE()}<span className="text-white/40" style={{ fontSize: '14px' }}> kcal/day</span>
                    </motion.div>
                  </div>
                  <div className="p-4 rounded-xl relative overflow-hidden" style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,214,0,0.3)' }}>
                    <motion.div
                      animate={{ x: ['-100%', '100%'] }}
                      transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                      className="absolute inset-0"
                      style={{
                        background: 'linear-gradient(90deg, transparent, rgba(255,214,0,0.1), transparent)',
                        pointerEvents: 'none'
                      }}
                    />
                    <div className="flex items-center justify-between relative z-10">
                      <span className="text-[#FFD600]" style={{ fontSize: '11px', letterSpacing: '1px', fontWeight: 700 }}>🎯 TARGET CALORIES</span>
                      <Target className="w-4 h-4 text-[#FFD600]" />
                    </div>
                    <motion.div
                      key={getTargetCalories()}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-[#FFD600] mt-1 relative z-10"
                      style={{ fontSize: '32px', fontWeight: 800, textShadow: '0 0 20px rgba(255,214,0,0.3)' }}
                    >
                      {getTargetCalories()}<span className="text-white/40" style={{ fontSize: '14px' }}> kcal/day</span>
                    </motion.div>
                    <p className="text-white/50 mt-1 relative z-10" style={{ fontSize: '10px' }}>
                      {fitnessGoal === 'loss' ? 'For fat loss' : fitnessGoal === 'gain' ? 'For muscle gain' : 'For maintenance'}
                    </p>
                  </div>
                </div>

                {/* What to do next */}
                <div className="mt-6 p-4 rounded-xl" style={{ background: 'rgba(255,214,0,0.05)', border: '1px solid rgba(255,214,0,0.15)' }}>
                  <p className="text-white/70 mb-2" style={{ fontSize: '12px', fontWeight: 600 }}>What to do next:</p>
                  <p className="text-white/50" style={{ fontSize: '11px', lineHeight: 1.6 }}>
                    Follow this calorie target daily for your goal
                  </p>
                </div>

                {/* Save Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setCalorieSaved(true)}
                  className="w-full mt-4 py-3 rounded-xl flex items-center justify-center gap-2"
                  style={{
                    background: calorieSaved ? 'rgba(16,185,129,0.15)' : 'rgba(255,214,0,0.1)',
                    border: `1px solid ${calorieSaved ? '#10B981' : 'rgba(255,214,0,0.3)'}`,
                    color: calorieSaved ? '#10B981' : '#FFD600',
                    fontSize: '13px',
                    fontWeight: 600
                  }}
                >
                  {calorieSaved ? '✓ Saved Successfully' : 'Save Data'}
                </motion.button>
              </motion.div>
            </div>

            {/* CARD 3: MACRO CALCULATOR (FULL WIDTH) */}
            <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
                whileHover={{ y: -8, boxShadow: '0 30px 60px rgba(255,214,0,0.3)' }}
                className="p-10 rounded-2xl relative max-w-4xl mx-auto"
                style={{
                  background: 'linear-gradient(145deg, #1A1A1A 0%, #141414 100%)',
                  border: '2px solid transparent',
                  backgroundImage: 'linear-gradient(145deg, #1A1A1A, #141414), linear-gradient(135deg, rgba(255,214,0,0.4), rgba(255,149,0,0.2))',
                  backgroundOrigin: 'border-box',
                  backgroundClip: 'padding-box, border-box',
                  boxShadow: '0 8px 32px rgba(255,214,0,0.15)'
                }}
              >
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, rgba(255,214,0,0.2), rgba(255,149,0,0.1))' }}>
                    <Apple className="w-7 h-7 text-[#FFD600]" />
                  </div>
                  <div>
                    <p className="text-white/50" style={{ fontSize: '11px', letterSpacing: '2px', textTransform: 'uppercase' }}>Macro Calculator</p>
                    <p className="text-[#FFD600]" style={{ fontSize: '13px', fontWeight: 600 }}>Nutrition Split</p>
                  </div>
                </div>

                {/* Macro Breakdown */}
                <div className="space-y-5">
                  {[
                    { label: 'Protein', value: macros.protein, unit: 'g', color: '#EF4444', max: 200 },
                    { label: 'Carbs', value: macros.carbs, unit: 'g', color: '#3B82F6', max: 300 },
                    { label: 'Fats', value: macros.fats, unit: 'g', color: '#10B981', max: 100 }
                  ].map((macro, i) => (
                    <motion.div
                      key={macro.label}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.4 + i * 0.1 }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white/70" style={{ fontSize: '13px', fontWeight: 600 }}>{macro.label}</span>
                        <span style={{ color: macro.color, fontSize: '18px', fontWeight: 800 }}>
                          {macro.value}{macro.unit}
                        </span>
                      </div>
                      <div className="h-3 rounded-full overflow-hidden" style={{ background: 'rgba(0,0,0,0.4)' }}>
                        <motion.div
                          initial={{ width: '0%' }}
                          whileInView={{ width: `${Math.min(Math.max(((macro.value || 0) / (macro.max || 1)) * 100, 0), 100)}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1, delay: 0.5 + i * 0.1, type: 'spring' }}
                          className="h-full rounded-full relative"
                          style={{
                            background: `linear-gradient(90deg, ${macro.color}, ${macro.color}dd)`,
                            boxShadow: `0 0 12px ${macro.color}66`
                          }}
                        >
                          <motion.div
                            animate={{ x: ['-100%', '100%'] }}
                            transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                            className="absolute inset-0"
                            style={{
                              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)'
                            }}
                          />
                        </motion.div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-6 p-4 rounded-xl" style={{ background: 'rgba(255,214,0,0.05)', border: '1px solid rgba(255,214,0,0.15)' }}>
                  <p className="text-white/50 text-center" style={{ fontSize: '11px', lineHeight: 1.5 }}>
                    Based on {getTargetCalories()} kcal target · {fitnessGoal === 'loss' ? 'High protein for fat loss' : fitnessGoal === 'gain' ? 'Protein-focused for muscle gain' : 'Balanced macros'}
                  </p>
                </div>

                {/* What to do next */}
                <div className="mt-4 p-4 rounded-xl" style={{ background: 'rgba(255,214,0,0.05)', border: '1px solid rgba(255,214,0,0.15)' }}>
                  <p className="text-white/70 mb-2" style={{ fontSize: '12px', fontWeight: 600 }}>What to do next:</p>
                  <p className="text-white/50" style={{ fontSize: '11px', lineHeight: 1.6 }}>
                    Try to hit these macros daily through your meals
                  </p>
                </div>

                {/* Save Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setMacroSaved(true)}
                  className="w-full mt-4 py-3 rounded-xl flex items-center justify-center gap-2"
                  style={{
                    background: macroSaved ? 'rgba(16,185,129,0.15)' : 'rgba(255,214,0,0.1)',
                    border: `1px solid ${macroSaved ? '#10B981' : 'rgba(255,214,0,0.3)'}`,
                    color: macroSaved ? '#10B981' : '#FFD600',
                    fontSize: '13px',
                    fontWeight: 600
                  }}
                >
                  {macroSaved ? '✓ Saved Successfully' : 'Save Data'}
                </motion.button>
              </motion.div>
          </div>
        </SectionReveal>
      </section>

      {/* MEAL CALORIE TRACKER (ADVANCED) SECTION */}
      <section id="nutrition" className="py-20 px-6">
        <SectionReveal>
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-white mb-3" style={{ fontSize: '48px', fontWeight: 700, letterSpacing: '-1px' }}>
                Meal Calorie Tracker
              </h2>
              <p className="text-white/60" style={{ fontSize: '16px' }}>Track your daily nutrition intake</p>
            </div>

            {/* Remaining Calories Banner */}
            {totalCalories > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-8 p-6 rounded-2xl text-center"
                style={{
                  background: remainingCalories >= 0 ? 'rgba(255,214,0,0.1)' : 'rgba(239,68,68,0.1)',
                  border: `2px solid ${remainingCalories >= 0 ? 'rgba(255,214,0,0.3)' : 'rgba(239,68,68,0.3)'}`,
                }}
              >
                <div className="text-white/60 mb-1" style={{ fontSize: '13px', letterSpacing: '1px' }}>TODAY'S REMAINING CALORIES</div>
                <motion.div
                  className={remainingCalories >= 0 ? 'text-[#FFD600]' : 'text-red-400'}
                  style={{ fontSize: '42px', fontWeight: 800 }}
                  key={remainingCalories}
                  initial={{ scale: 1.2 }}
                  animate={{ scale: 1 }}
                >
                  {remainingCalories >= 0 ? remainingCalories : Math.abs(remainingCalories)} kcal {remainingCalories < 0 && 'over'}
                </motion.div>
                <div className="text-white/50" style={{ fontSize: '13px' }}>
                  {remainingCalories >= 0 ? 'remaining for today' : 'exceeded your goal'}
                </div>
              </motion.div>
            )}

            {/* Search & Add Panel */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {/* Search Food */}
              <div className="relative">
                <div className="text-white/70 mb-3" style={{ fontSize: '13px', letterSpacing: '1px', textTransform: 'uppercase' }}>
                  Search Food
                </div>
                <div className="flex items-center gap-3 px-5 py-3.5 rounded-xl" style={{ background: '#1A1A1A', border: '1px solid rgba(255,214,0,0.2)' }}>
                  <Search className="w-5 h-5 text-[#FFD600]" />
                  <input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search food (e.g., rice, chicken, egg)"
                    className="flex-1 bg-transparent text-white outline-none"
                    style={{ fontSize: '14px' }}
                  />
                </div>
                <AnimatePresence>
                  {searchQuery && filteredFoods.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute top-full left-0 right-0 mt-2 p-2 rounded-xl z-20 max-h-80 overflow-y-auto"
                      style={{ background: '#0B0B0B', border: '1px solid rgba(255,214,0,0.3)' }}
                    >
                      {filteredFoods.map((food, i) => (
                        <div key={i} className="p-3 rounded-lg hover:bg-white/5 transition-colors mb-1">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="text-white mb-1" style={{ fontSize: '14px', fontWeight: 500 }}>{food.name}</div>
                              <div className="text-white/50" style={{ fontSize: '11px' }}>
                                {food.calories} cal • P:{food.protein}g C:{food.carbs}g F:{food.fats}g • {food.per}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-2">
                            {(['breakfast', 'lunch', 'dinner', 'snacks'] as const).map(meal => (
                              <motion.button
                                key={meal}
                                whileTap={{ scale: 0.95 }}
                                onClick={() => addFood(food, meal)}
                                className="flex-1 px-3 py-1.5 rounded-lg text-[#FFD600] capitalize"
                                style={{ background: 'rgba(255,214,0,0.1)', fontSize: '11px', fontWeight: 600 }}
                              >
                                + {meal}
                              </motion.button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Meal Sections */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {(['breakfast', 'lunch', 'dinner', 'snacks'] as const).map((mealType, idx) => (
                <motion.div
                  key={mealType}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.08 }}
                  className="p-6 rounded-2xl"
                  style={{ background: '#1A1A1A', border: '1px solid rgba(255,214,0,0.15)' }}
                >
                  <div className="mb-4">
                    <h3 className="text-white capitalize" style={{ fontSize: '18px', fontWeight: 600 }}>
                      {mealType}
                    </h3>
                  </div>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    <AnimatePresence>
                      {meals[mealType].length === 0 ? (
                        <div className="text-white/30 text-center py-8" style={{ fontSize: '13px' }}>No items added</div>
                      ) : (
                        meals[mealType].map((food) => (
                          <motion.div
                            key={food.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20 }}
                            className="flex items-center justify-between p-3 rounded-lg group hover:bg-white/5 transition-colors"
                            style={{ background: 'rgba(255,255,255,0.03)' }}
                          >
                            <div className="flex-1">
                              <div className="text-white mb-0.5" style={{ fontSize: '13px', fontWeight: 500 }}>{food.name}</div>
                              <div className="text-white/40" style={{ fontSize: '11px' }}>
                                {food.calories} cal • P:{food.protein}g C:{food.carbs}g F:{food.fats}g
                              </div>
                            </div>
                            <motion.button
                              whileTap={{ scale: 0.9 }}
                              onClick={() => removeFood(mealType, food.id)}
                              className="w-7 h-7 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                              style={{ background: 'rgba(239,68,68,0.15)' }}
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-400" />
                            </motion.button>
                          </motion.div>
                        ))
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Daily Summary */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="p-8 rounded-2xl"
              style={{ background: 'linear-gradient(135deg, rgba(255,214,0,0.08), rgba(255,165,0,0.05))', border: '2px solid rgba(255,214,0,0.25)' }}
            >
              <h3 className="text-white mb-6 text-center" style={{ fontSize: '24px', fontWeight: 700 }}>Daily Summary</h3>
              <div className="grid md:grid-cols-5 gap-6">
                {[
                  { label: 'Calories', value: totalCalories, unit: 'kcal', color: '#FFD600', max: calculateTDEE() },
                  { label: 'Protein', value: totalProtein, unit: 'g', color: '#EF4444', max: 150 },
                  { label: 'Carbs', value: totalCarbs, unit: 'g', color: '#3B82F6', max: 250 },
                  { label: 'Fats', value: totalFats, unit: 'g', color: '#10B981', max: 80 },
                  { label: 'Fiber', value: totalFiber.toFixed(1), unit: 'g', color: '#A78BFA', max: 30 },
                ].map((item, i) => (
                  <div key={item.label}>
                    <div className="text-white/60 mb-2 text-center" style={{ fontSize: '11px', letterSpacing: '1px', textTransform: 'uppercase' }}>
                      {item.label}
                    </div>
                    <div className="text-center mb-3">
                      <motion.span
                        className="text-white"
                        style={{ fontSize: '28px', fontWeight: 700 }}
                        key={item.value}
                        initial={{ scale: 1.2 }}
                        animate={{ scale: 1 }}
                      >
                        {typeof item.value === 'number' ? Math.round(item.value) : item.value}
                      </motion.span>
                      <span className="text-white/40 ml-1" style={{ fontSize: '13px' }}>{item.unit}</span>
                    </div>
                    <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
                      <motion.div
                        className="h-full rounded-full"
                        style={{ background: `linear-gradient(90deg, ${item.color}, ${item.color}cc)` }}
                        initial={{ width: '0%' }}
                        animate={{ width: `${Math.min(Math.max(((Number(item.value) || 0) / (item.max || 1)) * 100, 0), 100)}%` }}
                        transition={{ duration: 1, delay: i * 0.1 }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* Save Daily Log Button */}
              <div className="mt-8 text-center">
                <p className="text-white/50 mb-4" style={{ fontSize: '13px' }}>Save your daily intake after meals</p>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setDailyLogSaved(true)}
                  className="px-8 py-3.5 rounded-xl"
                  style={{
                    background: dailyLogSaved ? 'rgba(16,185,129,0.2)' : 'rgba(255,214,0,0.15)',
                    border: `2px solid ${dailyLogSaved ? '#10B981' : '#FFD600'}`,
                    color: dailyLogSaved ? '#10B981' : '#FFD600',
                    fontSize: '15px',
                    fontWeight: 700
                  }}
                >
                  {dailyLogSaved ? '✓ Daily Log Saved' : 'Save Daily Log'}
                </motion.button>
              </div>
            </motion.div>
          </div>
        </SectionReveal>
      </section>

      {/* PROGRESS GRAPH SECTION */}
      <section id="progress" className="py-20 px-6" style={{ background: '#161616' }}>
        <SectionReveal>
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-white mb-2" style={{ fontSize: '48px', fontWeight: 700, letterSpacing: '-1px' }}>
                  Progress Tracker
                </h2>
                <p className="text-white/60" style={{ fontSize: '16px' }}>Monitor your weight journey</p>
              </div>
              <div className="flex gap-2">
                {(['weekly', 'monthly'] as const).map(period => (
                  <motion.button
                    key={period}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setGraphPeriod(period)}
                    className="px-5 py-2 rounded-xl capitalize"
                    style={{
                      background: graphPeriod === period ? '#FFD600' : 'rgba(255,255,255,0.05)',
                      color: graphPeriod === period ? '#0B0B0B' : '#fff',
                      fontSize: '14px',
                      fontWeight: 600,
                    }}
                  >
                    {period}
                  </motion.button>
                ))}
              </div>
            </div>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
              className="p-8 rounded-2xl"
              style={{ background: '#1E1E1E', border: '1px solid rgba(255,214,0,0.2)' }}
            >
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={weightData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="week" stroke="rgba(255,255,255,0.4)" style={{ fontSize: '12px' }} />
                  <YAxis stroke="rgba(255,255,255,0.4)" style={{ fontSize: '12px' }} domain={[75, 85]} />
                  <Tooltip
                    contentStyle={{
                      background: '#0B0B0B',
                      border: '1px solid rgba(255,214,0,0.3)',
                      borderRadius: '12px',
                      color: '#fff',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="weight"
                    stroke="#FFD600"
                    strokeWidth={3}
                    dot={{ fill: '#FFD600', r: 5 }}
                    activeDot={{ r: 8, fill: '#FFD600', stroke: '#0B0B0B', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </motion.div>
          </div>
        </SectionReveal>
      </section>

      {/* WORKOUT PLANS SECTION - 7 DAY WEEKLY ROUTINE */}
      <section id="workout" className="py-20 px-6">
        <SectionReveal>
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-white mb-3" style={{ fontSize: '48px', fontWeight: 700, letterSpacing: '-1px' }}>
                Weekly Workout Routine
              </h2>
              <p className="text-white/60" style={{ fontSize: '16px' }}>Your 7-day structured training plan</p>
            </div>
            <div className="grid md:grid-cols-7 gap-4">
              {weeklyWorkout.map((day, i) => (
                <motion.div
                  key={day.day}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  whileHover={day.plan !== 'Rest Day' ? { y: -8, boxShadow: '0 25px 50px rgba(255,214,0,0.25)' } : {}}
                  onClick={() => day.plan !== 'Rest Day' && setExpandedDay(expandedDay === day.day ? null : day.day)}
                  className={`p-4 rounded-2xl ${day.plan !== 'Rest Day' ? 'cursor-pointer' : ''}`}
                  style={{
                    background: day.plan === 'Rest Day' ? '#0D0D0D' : expandedDay === day.day ? 'rgba(255,214,0,0.1)' : '#161616',
                    border: `2px solid ${expandedDay === day.day ? '#FFD600' : day.plan === 'Rest Day' ? 'rgba(255,255,255,0.05)' : 'rgba(255,214,0,0.15)'}`,
                    opacity: day.plan === 'Rest Day' ? 0.6 : 1
                  }}
                >
                  <div className="text-center">
                    <div style={{ fontSize: '32px', marginBottom: '8px' }}>{day.icon}</div>
                    <p className="text-white/50 mb-1" style={{ fontSize: '11px', letterSpacing: '1px', textTransform: 'uppercase' }}>{day.day}</p>
                    <p className="text-white" style={{ fontSize: '12px', fontWeight: 600, lineHeight: 1.3 }}>{day.plan}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Expanded Exercise Details */}
            <AnimatePresence>
              {expandedDay && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-8 p-8 rounded-2xl overflow-hidden"
                  style={{ background: '#1A1A1A', border: '2px solid rgba(255,214,0,0.25)' }}
                >
                  {weeklyWorkout.find(d => d.day === expandedDay) && (
                    <>
                      <div className="flex items-center justify-between mb-6">
                        <div>
                          <h3 className="text-white mb-1" style={{ fontSize: '28px', fontWeight: 700 }}>
                            {weeklyWorkout.find(d => d.day === expandedDay)!.day} Workout
                          </h3>
                          <p className="text-[#FFD600]" style={{ fontSize: '16px', fontWeight: 600 }}>
                            {weeklyWorkout.find(d => d.day === expandedDay)!.plan}
                          </p>
                        </div>
                        <motion.button
                          whileTap={{ scale: 0.9 }}
                          onClick={() => setExpandedDay(null)}
                          className="w-10 h-10 rounded-xl flex items-center justify-center"
                          style={{ background: 'rgba(255,255,255,0.05)' }}
                        >
                          <X className="w-5 h-5 text-white/60" />
                        </motion.button>
                      </div>
                      <div className="space-y-3">
                        {weeklyWorkout.find(d => d.day === expandedDay)!.exercises.map((exercise, idx) => (
                          <motion.div
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            className="p-4 rounded-xl"
                            style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,214,0,0.1)' }}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,214,0,0.15)', color: '#FFD600', fontSize: '13px', fontWeight: 700 }}>
                                  {idx + 1}
                                </div>
                                <span className="text-white" style={{ fontSize: '15px', fontWeight: 600 }}>{exercise.name}</span>
                              </div>
                              <div className="flex items-center gap-4">
                                <div className="text-center">
                                  <p className="text-white/40" style={{ fontSize: '10px', marginBottom: '2px' }}>Sets</p>
                                  <p className="text-[#FFD600]" style={{ fontSize: '14px', fontWeight: 700 }}>{exercise.sets}</p>
                                </div>
                                <div className="text-center">
                                  <p className="text-white/40" style={{ fontSize: '10px', marginBottom: '2px' }}>Reps</p>
                                  <p className="text-[#FFD600]" style={{ fontSize: '14px', fontWeight: 700 }}>{exercise.reps}</p>
                                </div>
                                <div className="text-center">
                                  <p className="text-white/40" style={{ fontSize: '10px', marginBottom: '2px' }}>Rest</p>
                                  <p className="text-white/60" style={{ fontSize: '14px', fontWeight: 600 }}>{exercise.rest}</p>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SectionReveal>
      </section>

      {/* MOOD TRACKER SECTION */}
      <section className="py-20 px-6" style={{ background: '#161616' }}>
        <SectionReveal>
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-white mb-3" style={{ fontSize: '48px', fontWeight: 700, letterSpacing: '-1px' }}>
              How Are You Feeling?
            </h2>
            <p className="text-white/60 mb-12" style={{ fontSize: '16px' }}>Track your daily mood and energy</p>
            <div className="flex justify-center gap-6">
              {moods.map((mood, i) => (
                <motion.div
                  key={i}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedMood(mood.value)}
                  className="cursor-pointer"
                >
                  <motion.div
                    className="w-20 h-20 rounded-2xl flex items-center justify-center mb-2"
                    style={{
                      background: selectedMood === mood.value ? 'rgba(255,214,0,0.2)' : 'rgba(255,255,255,0.05)',
                      border: `2px solid ${selectedMood === mood.value ? '#FFD600' : 'transparent'}`,
                      fontSize: '36px',
                    }}
                    animate={selectedMood === mood.value ? { scale: [1, 1.1, 1] } : {}}
                  >
                    {mood.icon}
                  </motion.div>
                  <div
                    className="text-white/60"
                    style={{ fontSize: '12px', color: selectedMood === mood.value ? '#FFD600' : undefined }}
                  >
                    {mood.label}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Message Box */}
            {selectedMood !== null && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 max-w-2xl mx-auto"
              >
                <textarea
                  value={moodMessage}
                  onChange={(e) => setMoodMessage(e.target.value)}
                  placeholder="How are you feeling today? Write your thoughts..."
                  className="w-full px-6 py-4 rounded-2xl bg-transparent text-white outline-none resize-none"
                  style={{
                    background: '#1A1A1A',
                    border: '1px solid rgba(255,214,0,0.2)',
                    fontSize: '15px',
                    minHeight: '120px',
                    lineHeight: 1.6
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#FFD600'}
                  onBlur={(e) => e.target.style.borderColor = 'rgba(255,214,0,0.2)'}
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setMoodMessage('');
                    setSelectedMood(null);
                  }}
                  className="w-full mt-4 py-4 rounded-2xl flex items-center justify-center gap-2"
                  style={{
                    background: 'linear-gradient(135deg, #FFD600, #FFA500)',
                    color: '#0B0B0B',
                    fontSize: '16px',
                    fontWeight: 700,
                    border: 'none'
                  }}
                >
                  <Send className="w-5 h-5" />
                  Send Mood Entry
                </motion.button>
              </motion.div>
            )}
          </div>
        </SectionReveal>
      </section>

      {/* MOTIVATION SECTION */}
      <section className="py-32 px-6">
        <SectionReveal>
          <div className="max-w-4xl mx-auto text-center">
            <motion.h2
              className="text-white mb-6"
              style={{
                fontSize: '64px',
                fontWeight: 800,
                lineHeight: 1.1,
                letterSpacing: '-2px',
                textShadow: '0 0 80px rgba(255,214,0,0.4)',
              }}
            >
              Push Harder<br />Than Yesterday
            </motion.h2>
            <p className="text-white/60 max-w-2xl mx-auto" style={{ fontSize: '18px', lineHeight: 1.7 }}>
              Every rep, every set, every meal brings you closer to your goals. Stay consistent, stay focused, stay unstoppable.
            </p>
          </div>
        </SectionReveal>
      </section>

      {/* CONTACT SECTION */}
      <ContactSection compact={true} />

      {/* Footer Spacing */}
      <div className="h-20" />
    </div>
  );
}
