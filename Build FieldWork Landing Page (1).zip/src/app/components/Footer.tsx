import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  onPrivacyClick?: () => void;
}

export function Footer({ onPrivacyClick }: FooterProps = {}) {
  return (
    <footer className="bg-gradient-to-b from-black via-[#0D0D0D] to-black text-white pt-20 pb-10 border-t border-white/5" id="contact">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-[#00C897] to-teal-400 bg-clip-text text-transparent drop-shadow-[0_0_10px_rgba(0,200,151,0.3)]">
              VITAPULSE
            </h3>
            <p className="text-gray-400 mb-6">
              Your journey to optimal health and fitness starts here. Transform your life with our holistic approach.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 flex items-center justify-center hover:bg-[#00C897] hover:border-[#00C897] hover:shadow-[0_0_20px_rgba(0,200,151,0.4)] transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 flex items-center justify-center hover:bg-[#00C897] hover:border-[#00C897] hover:shadow-[0_0_20px_rgba(0,200,151,0.4)] transition-all">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 flex items-center justify-center hover:bg-[#00C897] hover:border-[#00C897] hover:shadow-[0_0_20px_rgba(0,200,151,0.4)] transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 flex items-center justify-center hover:bg-[#00C897] hover:border-[#00C897] hover:shadow-[0_0_20px_rgba(0,200,151,0.4)] transition-all">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <a href="#home" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Our Services
                </a>
              </li>
              <li>
                <a href="#bmi" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  BMI Calculator
                </a>
              </li>
              <li>
                <a href="#wellness" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Wellness Programs
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Services</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Personal Training
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Yoga Classes
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Nutrition Coaching
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Meditation Sessions
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  Health Assessments
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-1" />
                <span className="text-gray-400">
                  123 Wellness Ave, Health City, HC 12345
                </span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <a href="tel:+1234567890" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  +1 (234) 567-890
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <a href="mailto:vitaapulsee@gmail.com" className="text-gray-400 hover:text-[#00C897] transition-colors">
                  vitaapulsee@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-sm">
              © 2026 VITAPULSE. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm">
              <button
                onClick={onPrivacyClick}
                className="text-gray-400 hover:text-[#00C897] transition-colors cursor-pointer"
              >
                Privacy Policy
              </button>
              <a href="#" className="text-gray-400 hover:text-[#00C897] transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-[#00C897] transition-colors">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
