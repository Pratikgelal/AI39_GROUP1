import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';

interface GetStartedCTAProps {
  onGetStarted: () => void;
}

export function GetStartedCTA({ onGetStarted }: GetStartedCTAProps) {
  return (
    <section className="py-24 px-6 bg-gradient-to-br from-emerald-600 via-teal-600 to-green-600 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="space-y-6"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full mb-4">
            <Sparkles className="w-10 h-10 text-white" />
          </div>

          <h2 className="text-4xl md:text-5xl lg:text-6xl text-white">
            Ready to Transform Your Life?
          </h2>

          <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto">
            Get your personalized health and fitness plan in just a few minutes
          </p>

          <div className="pt-6">
            <motion.button
              onClick={onGetStarted}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-3 px-10 py-5 bg-gradient-to-r from-orange-500 to-amber-600 text-white text-lg rounded-full shadow-2xl hover:from-orange-600 hover:to-amber-700 transition-all"
            >
              <span>Get Started Now</span>
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 8l4 4m0 0l-4 4m4-4H3"
                />
              </svg>
            </motion.button>
          </div>

          <p className="text-sm text-white/80 pt-4">
            No credit card required • Free personalized plan • Join 10,000+ members
          </p>
        </motion.div>
      </div>
    </section>
  );
}
