import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Moon, Activity, FileText, Target, Zap, Calendar,
  Bot, TrendingUp, Mic, Stethoscope, AlertTriangle,
  Bell, Users, Upload, MapPin, Navigation, DollarSign,
  Search, Home, Heart, BarChart2, User, ChevronLeft, ChevronRight,
  ArrowRight, Plus, Check, X, Send, Camera, Phone, Shield,
  Droplets, Flame, MessageSquare, Star, RefreshCw, Download,
  Clock, Settings, Pill, Thermometer, Map, Brain, Scan,
  Timer, Dumbbell, Award, HeartPulse, AlertOctagon,
  BookOpen, Wallet, UserPlus, UserCheck, Radio, CheckCircle, Circle,
  ChevronDown, Coffee, Wind, Leaf, Info, Smile, Eye, Image
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, AreaChart, Area, PieChart, Pie, Cell
} from 'recharts';

// ======================== TYPES ========================
type ScreenId =
  | 'main' | 'sleep' | 'timeline' | 'weekly' | 'goals' | 'motivation'
  | 'sleep-planner' | 'ai-chat' | 'risk' | 'multimodal' | 'image-scan'
  | 'symptom' | 'first-aid' | 'emergency' | 'family' | 'reports'
  | 'healthcare' | 'specialist' | 'outbreak' | 'expense' | 'profile';

// ======================== SAMPLE DATA ========================
const sleepWeekData = [
  { day: 'Mon', hours: 7.5, quality: 85 },
  { day: 'Tue', hours: 6.0, quality: 65 },
  { day: 'Wed', hours: 8.0, quality: 92 },
  { day: 'Thu', hours: 6.5, quality: 72 },
  { day: 'Fri', hours: 7.2, quality: 80 },
  { day: 'Sat', hours: 9.0, quality: 95 },
  { day: 'Sun', hours: 5.5, quality: 58 },
];

const stepsData = [
  { time: '6am', steps: 200 }, { time: '8am', steps: 1400 },
  { time: '10am', steps: 3200 }, { time: '12pm', steps: 5100 },
  { time: '2pm', steps: 6300 }, { time: '4pm', steps: 7800 },
  { time: '6pm', steps: 8432 }, { time: '8pm', steps: 8600 },
];

const weeklyHealthData = [
  { day: 'Mon', steps: 9200, calories: 2100, sleep: 7.5 },
  { day: 'Tue', steps: 7400, calories: 1900, sleep: 6.0 },
  { day: 'Wed', steps: 11000, calories: 2400, sleep: 8.0 },
  { day: 'Thu', steps: 8432, calories: 2050, sleep: 6.5 },
  { day: 'Fri', steps: 9800, calories: 2200, sleep: 7.2 },
  { day: 'Sat', steps: 6200, calories: 1800, sleep: 9.0 },
  { day: 'Sun', steps: 5100, calories: 1700, sleep: 5.5 },
];

const expenseData = [
  { category: 'Medicine', amount: 120, color: '#00C897' },
  { category: 'Gym', amount: 80, color: '#4A9EFF' },
  { category: 'Supplements', amount: 65, color: '#F59E0B' },
  { category: 'Doctor', amount: 150, color: '#EF4444' },
  { category: 'Other', amount: 45, color: '#A78BFA' },
];

const expenseMonthly = [
  { month: 'Jan', total: 320 }, { month: 'Feb', total: 410 },
  { month: 'Mar', total: 380 }, { month: 'Apr', total: 460 },
  { month: 'May', total: 290 }, { month: 'Jun', total: 505 },
];

const goals = [
  { id: 1, title: 'Walk 10,000 steps daily', progress: 84, color: '#00C897', icon: Activity },
  { id: 2, title: 'Sleep 8 hours each night', progress: 68, color: '#4A9EFF', icon: Moon },
  { id: 3, title: 'Drink 2.5L water daily', progress: 72, color: '#38BDF8', icon: Droplets },
  { id: 4, title: 'Workout 5x per week', progress: 60, color: '#F59E0B', icon: Dumbbell },
];

const familyMembers = [
  { id: 1, name: 'You', age: 28, status: 'Healthy', color: '#00C897', avatar: '👨' },
  { id: 2, name: 'Sarah (Wife)', age: 26, status: 'Check-up due', color: '#F59E0B', avatar: '👩' },
  { id: 3, name: 'Dad', age: 56, status: 'Hypertension', color: '#EF4444', avatar: '👴' },
  { id: 4, name: 'Mom', age: 52, status: 'Healthy', color: '#00C897', avatar: '👩‍🦳' },
];

const nearbyPlaces = [
  { name: 'City Medical Center', type: 'Hospital', distance: '0.8 km', open: true, rating: 4.5 },
  { name: 'LifeCare Clinic', type: 'Clinic', distance: '1.2 km', open: true, rating: 4.2 },
  { name: 'Apollo Pharmacy', type: 'Pharmacy', distance: '0.3 km', open: true, rating: 4.7 },
  { name: 'WellnessFirst Lab', type: 'Diagnostics', distance: '2.1 km', open: false, rating: 4.4 },
];

const specialists = [
  { type: 'Cardiologist', icon: HeartPulse, color: '#EF4444', count: 12, available: true },
  { type: 'Neurologist', icon: Brain, color: '#8B5CF6', count: 8, available: true },
  { type: 'Dermatologist', icon: Scan, color: '#F59E0B', count: 15, available: true },
  { type: 'Orthopedist', icon: Activity, color: '#3B82F6', count: 9, available: false },
  { type: 'Dietitian', icon: Leaf, color: '#10B981', count: 20, available: true },
  { type: 'Psychiatrist', icon: Brain, color: '#A78BFA', count: 7, available: true },
];

const outbreakAlerts = [
  { disease: 'Seasonal Flu', level: 'Medium', area: '5 km radius', cases: 234, color: '#F59E0B' },
  { disease: 'Dengue', level: 'High', area: '8 km radius', cases: 67, color: '#EF4444' },
  { disease: 'COVID-19', level: 'Low', area: '10 km radius', cases: 12, color: '#10B981' },
];

const timelineEvents = [
  { time: '6:30 AM', event: 'Woke up', icon: '🌅', color: '#F59E0B' },
  { time: '7:00 AM', event: 'Morning walk - 2.1 km', icon: '🚶', color: '#00C897' },
  { time: '8:30 AM', event: 'Breakfast + Supplements', icon: '🥗', color: '#4A9EFF' },
  { time: '10:15 AM', event: 'Heart rate spike (92 BPM)', icon: '❤️', color: '#EF4444' },
  { time: '12:30 PM', event: 'Lunch + Water (0.5L)', icon: '🍱', color: '#4A9EFF' },
  { time: '3:00 PM', event: 'Gym Session - 45 min', icon: '🏋️', color: '#F59E0B' },
  { time: '6:00 PM', event: 'Evening steps target met', icon: '🎯', color: '#00C897' },
  { time: '9:30 PM', event: 'Dinner', icon: '🍽️', color: '#A78BFA' },
];

const riskFactors = [
  { factor: 'Cardiovascular', risk: 18, color: '#EF4444', level: 'Low' },
  { factor: 'Diabetes', risk: 24, color: '#F59E0B', level: 'Low-Med' },
  { factor: 'Hypertension', risk: 31, color: '#F97316', level: 'Medium' },
  { factor: 'Obesity', risk: 12, color: '#10B981', level: 'Low' },
  { factor: 'Mental Health', risk: 22, color: '#8B5CF6', level: 'Low-Med' },
];

const motivationQuotes = [
  { quote: "Every step you take today is an investment in your future health. Keep moving forward!", author: "Dr. Sarah Johnson" },
  { quote: "Your body is your most priceless possession. Take care of it with the same love you give others.", author: "VitaPulse AI" },
  { quote: "Small consistent actions create massive health transformations. You're doing great!", author: "Wellness Coach" },
  { quote: "Rest is not laziness. Sleep is one of the most powerful tools for healing and growth.", author: "Dr. Matthew Walker" },
];

// ======================== SHARED COMPONENTS ========================
const BG = 'linear-gradient(170deg, #0B2D22 0%, #0A1E35 50%, #080F1E 100%)';
const CARD_BG = 'rgba(255,255,255,0.07)';
const CARD_BORDER = 'rgba(255,255,255,0.1)';

function GlassCard({ children, className = '', onClick, style = {} }: {
  children: React.ReactNode; className?: string;
  onClick?: () => void; style?: React.CSSProperties;
}) {
  return (
    <motion.div
      whileHover={onClick ? { scale: 1.02, y: -2 } : undefined}
      whileTap={onClick ? { scale: 0.97 } : undefined}
      onClick={onClick}
      className={`rounded-2xl ${onClick ? 'cursor-pointer' : ''} ${className}`}
      style={{ background: CARD_BG, border: `1px solid ${CARD_BORDER}`, backdropFilter: 'blur(12px)', ...style }}
    >
      {children}
    </motion.div>
  );
}

function ScreenWrapper({ children, onBack, title, subtitle, accentColor = '#00C897' }: {
  children: React.ReactNode; onBack: () => void;
  title: string; subtitle?: string; accentColor?: string;
}) {
  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 28, stiffness: 250 }}
      className="absolute inset-0 z-20 overflow-y-auto overscroll-contain"
      style={{ background: BG }}
    >
      <div className="sticky top-0 z-10 px-4 pt-12 pb-4" style={{ background: 'rgba(8,15,30,0.92)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <div className="flex items-center gap-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onBack}
            className="flex items-center justify-center w-9 h-9 rounded-full"
            style={{ background: 'rgba(255,255,255,0.1)' }}
          >
            <ChevronLeft className="w-5 h-5 text-white" />
          </motion.button>
          <div>
            <h2 className="text-white" style={{ fontSize: '17px', fontWeight: 600 }}>{title}</h2>
            {subtitle && <p className="text-white/50" style={{ fontSize: '12px' }}>{subtitle}</p>}
          </div>
        </div>
      </div>
      <div className="px-4 pb-28 pt-4 space-y-4">
        {children}
      </div>
    </motion.div>
  );
}

function SectionHeader({ title, color = '#00C897', icon: Icon }: { title: string; color?: string; icon?: React.ElementType }) {
  return (
    <div className="flex items-center gap-2 mb-3 mt-2">
      <div className="w-1 h-5 rounded-full" style={{ background: color }} />
      {Icon && <Icon className="w-4 h-4" style={{ color }} />}
      <span className="uppercase tracking-widest" style={{ fontSize: '11px', fontWeight: 700, color }}>{title}</span>
    </div>
  );
}

function StatPill({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex flex-col items-center px-4 py-2 rounded-xl" style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
      <span className="font-bold" style={{ color, fontSize: '16px' }}>{value}</span>
      <span className="text-white/50" style={{ fontSize: '10px' }}>{label}</span>
    </div>
  );
}

function ProgressBar({ value, color, height = 6, label }: { value: number; color: string; height?: number; label?: string }) {
  return (
    <div>
      {label && (
        <div className="flex justify-between mb-1">
          <span className="text-white/60" style={{ fontSize: '12px' }}>{label}</span>
          <span style={{ color, fontSize: '12px', fontWeight: 600 }}>{value}%</span>
        </div>
      )}
      <div className="w-full rounded-full overflow-hidden" style={{ height, background: 'rgba(255,255,255,0.1)' }}>
        <motion.div
          initial={{ width: '0%' }}
          animate={{ width: `${Math.min(Math.max(value || 0, 0), 100)}%` }}
          transition={{ duration: 1, ease: 'easeOut', delay: 0.2 }}
          className="h-full rounded-full"
          style={{ background: `linear-gradient(90deg, ${color}, ${color}99)` }}
        />
      </div>
    </div>
  );
}

function ActionBtn({ children, color = '#00C897', onClick, variant = 'filled', icon: Icon }: {
  children: React.ReactNode; color?: string; onClick?: () => void;
  variant?: 'filled' | 'outline'; icon?: React.ElementType;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.96 }}
      whileHover={{ scale: 1.02 }}
      onClick={onClick}
      className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl"
      style={variant === 'filled'
        ? { background: `linear-gradient(135deg, ${color}, ${color}cc)`, color: '#fff' }
        : { border: `1px solid ${color}60`, color, background: `${color}10` }
      }
    >
      {Icon && <Icon className="w-4 h-4" />}
      <span style={{ fontSize: '13px', fontWeight: 600 }}>{children}</span>
    </motion.button>
  );
}

// ======================== SLEEP QUALITY SCREEN ========================
function SleepScreen({ onBack }: { onBack: () => void }) {
  const [selectedDay, setSelectedDay] = useState(3);
  const tonight = { bedtime: '10:30 PM', wakeup: '6:30 AM', deep: 2.1, rem: 1.8, light: 2.6 };

  return (
    <ScreenWrapper onBack={onBack} title="Sleep Quality Tracker" subtitle="Last 7 days analysis" accentColor="#4A9EFF">
      <GlassCard className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-white/50 mb-1" style={{ fontSize: '12px' }}>Tonight's Sleep</p>
            <div className="flex items-end gap-2">
              <span className="text-white" style={{ fontSize: '42px', fontWeight: 700, lineHeight: 1 }}>6.5</span>
              <span className="text-white/50 mb-1">hrs</span>
            </div>
          </div>
          <div className="flex items-center justify-center w-20 h-20 rounded-full" style={{ background: 'conic-gradient(#4A9EFF 72%, rgba(255,255,255,0.1) 72%)', padding: '3px' }}>
            <div className="w-full h-full rounded-full flex items-center justify-center" style={{ background: '#0B1E30' }}>
              <div className="text-center">
                <span className="text-white" style={{ fontSize: '18px', fontWeight: 700 }}>72</span>
                <span className="text-white/50 block" style={{ fontSize: '9px' }}>score</span>
              </div>
            </div>
          </div>
        </div>
        <div className="p-3 rounded-xl mb-4 flex items-start gap-2" style={{ background: 'rgba(74,158,255,0.15)', border: '1px solid rgba(74,158,255,0.3)' }}>
          <Info className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
          <p className="text-blue-300" style={{ fontSize: '12px' }}>💤 You slept 1.5 hours less than your goal. Try going to bed 30 minutes earlier tonight.</p>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[['Deep Sleep', `${tonight.deep}h`, '#6366F1'], ['REM Sleep', `${tonight.rem}h`, '#8B5CF6'], ['Light Sleep', `${tonight.light}h`, '#4A9EFF']].map(([label, val, color]) => (
            <div key={label as string} className="rounded-xl p-3 text-center" style={{ background: `${color as string}15`, border: `1px solid ${color as string}30` }}>
              <div className="font-bold" style={{ color: color as string, fontSize: '16px' }}>{val}</div>
              <div className="text-white/50" style={{ fontSize: '10px' }}>{label}</div>
            </div>
          ))}
        </div>
      </GlassCard>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>7-Day Sleep Pattern</h3>
        <div className="flex gap-1 mb-3">
          {sleepWeekData.map((d, i) => (
            <button
              key={d.day}
              onClick={() => setSelectedDay(i)}
              className="flex-1 py-1.5 rounded-lg text-center transition-all"
              style={{ background: selectedDay === i ? '#4A9EFF25' : 'transparent', border: selectedDay === i ? '1px solid #4A9EFF60' : '1px solid transparent' }}
            >
              <span style={{ fontSize: '10px', color: selectedDay === i ? '#4A9EFF' : 'rgba(255,255,255,0.4)' }}>{d.day}</span>
            </button>
          ))}
        </div>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={sleepWeekData} barSize={20}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="day" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} axisLine={false} tickLine={false} domain={[0, 10]} />
            <Tooltip contentStyle={{ background: '#0A1E35', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff' }} />
            <Bar dataKey="hours" fill="#4A9EFF" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </GlassCard>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Bedtime Schedule</h3>
        <div className="flex justify-between items-center">
          <div className="text-center">
            <Moon className="w-5 h-5 mx-auto mb-1" style={{ color: '#4A9EFF' }} />
            <div className="text-white font-semibold">{tonight.bedtime}</div>
            <div className="text-white/40" style={{ fontSize: '11px' }}>Bedtime</div>
          </div>
          <ArrowRight className="w-5 h-5 text-white/30" />
          <div className="text-center">
            <Zap className="w-5 h-5 mx-auto mb-1" style={{ color: '#F59E0B' }} />
            <div className="text-white font-semibold">{tonight.wakeup}</div>
            <div className="text-white/40" style={{ fontSize: '11px' }}>Wake-up</div>
          </div>
        </div>
      </GlassCard>
      <ActionBtn color="#4A9EFF" icon={Settings}>Set Sleep Schedule</ActionBtn>
    </ScreenWrapper>
  );
}

// ======================== HEALTH TIMELINE SCREEN ========================
function TimelineScreen({ onBack }: { onBack: () => void }) {
  return (
    <ScreenWrapper onBack={onBack} title="Health Timeline" subtitle="Today's activity log">
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white" style={{ fontSize: '14px', fontWeight: 600 }}>Thursday, Apr 30</h3>
          <div className="px-3 py-1 rounded-full" style={{ background: '#00C89720', border: '1px solid #00C89740' }}>
            <span style={{ color: '#00C897', fontSize: '11px', fontWeight: 600 }}>8 Events</span>
          </div>
        </div>
        <div className="space-y-0">
          {timelineEvents.map((event, i) => (
            <div key={i} className="flex gap-3">
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-base shrink-0 z-10" style={{ background: `${event.color}20`, border: `2px solid ${event.color}50` }}>
                  {event.icon}
                </div>
                {i < timelineEvents.length - 1 && <div className="w-0.5 flex-1 my-1" style={{ background: 'rgba(255,255,255,0.1)' }} />}
              </div>
              <div className="pb-4">
                <p className="text-white/40" style={{ fontSize: '11px' }}>{event.time}</p>
                <p className="text-white" style={{ fontSize: '13px' }}>{event.event}</p>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
      <div className="flex gap-3">
        <ActionBtn color="#00C897" icon={Plus}>Add Event</ActionBtn>
        <ActionBtn color="#4A9EFF" variant="outline" icon={Download}>Export</ActionBtn>
      </div>
    </ScreenWrapper>
  );
}

// ======================== WEEKLY REPORT SCREEN ========================
function WeeklyReportScreen({ onBack }: { onBack: () => void }) {
  const stats = [
    { label: 'Avg Steps', value: '8,391', change: '+12%', color: '#00C897' },
    { label: 'Avg Sleep', value: '7.1h', change: '-5%', color: '#4A9EFF' },
    { label: 'Avg Calories', value: '2,021', change: '+3%', color: '#F59E0B' },
    { label: 'Active Days', value: '5/7', change: '+1', color: '#A78BFA' },
  ];

  return (
    <ScreenWrapper onBack={onBack} title="Weekly Health Report" subtitle="Apr 23 – Apr 30, 2026">
      <div className="grid grid-cols-2 gap-3">
        {stats.map(s => (
          <GlassCard key={s.label} className="p-4">
            <div className="text-white/50 mb-1" style={{ fontSize: '11px' }}>{s.label}</div>
            <div className="font-bold text-white" style={{ fontSize: '22px' }}>{s.value}</div>
            <div style={{ color: s.change.startsWith('-') ? '#EF4444' : '#00C897', fontSize: '11px', fontWeight: 600 }}>{s.change} vs last week</div>
          </GlassCard>
        ))}
      </div>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Steps This Week</h3>
        <ResponsiveContainer width="100%" height={140}>
          <AreaChart data={weeklyHealthData}>
            <defs>
              <linearGradient id="stepsGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00C897" stopOpacity={0.4} />
                <stop offset="95%" stopColor="#00C897" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="day" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: '#0A1E35', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff' }} />
            <Area type="monotone" dataKey="steps" stroke="#00C897" fill="url(#stepsGrad)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </GlassCard>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Health Score Breakdown</h3>
        {[['Fitness', 78, '#00C897'], ['Nutrition', 65, '#F59E0B'], ['Sleep', 71, '#4A9EFF'], ['Mental', 82, '#A78BFA']].map(([label, val, color]) => (
          <div key={label as string} className="mb-3">
            <ProgressBar value={val as number} color={color as string} label={label as string} />
          </div>
        ))}
      </GlassCard>
      <ActionBtn color="#00C897" icon={Download}>Download PDF Report</ActionBtn>
    </ScreenWrapper>
  );
}

// ======================== GOAL SETTING SCREEN ========================
function GoalsScreen({ onBack }: { onBack: () => void }) {
  const [localGoals, setLocalGoals] = useState(goals);
  const [showAdd, setShowAdd] = useState(false);
  const [newGoal, setNewGoal] = useState('');

  return (
    <ScreenWrapper onBack={onBack} title="Goal Setting System" subtitle="Your active health goals">
      <div className="flex items-center justify-between">
        <div className="text-white/60" style={{ fontSize: '13px' }}>4 Active Goals</div>
        <ActionBtn color="#00C897" icon={Plus} onClick={() => setShowAdd(!showAdd)}>Add Goal</ActionBtn>
      </div>
      {showAdd && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <GlassCard className="p-4">
            <input
              value={newGoal}
              onChange={e => setNewGoal(e.target.value)}
              placeholder="Enter your health goal..."
              className="w-full bg-transparent text-white outline-none"
              style={{ border: 'none', fontSize: '14px', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '8px' }}
            />
            <div className="flex gap-2 mt-3">
              <ActionBtn color="#00C897" onClick={() => { if (newGoal) { setNewGoal(''); setShowAdd(false); } }}>Save Goal</ActionBtn>
              <ActionBtn color="#EF4444" variant="outline" onClick={() => setShowAdd(false)}>Cancel</ActionBtn>
            </div>
          </GlassCard>
        </motion.div>
      )}
      {localGoals.map((goal) => {
        const Icon = goal.icon;
        return (
          <GlassCard key={goal.id} className="p-4">
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${goal.color}20`, border: `1px solid ${goal.color}40` }}>
                <Icon className="w-5 h-5" style={{ color: goal.color }} />
              </div>
              <div className="flex-1">
                <p className="text-white" style={{ fontSize: '14px', fontWeight: 500 }}>{goal.title}</p>
                <ProgressBar value={goal.progress} color={goal.color} />
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/40" style={{ fontSize: '11px' }}>Daily streak: 7 days 🔥</span>
              <span className="font-bold" style={{ color: goal.color, fontSize: '13px' }}>{goal.progress}%</span>
            </div>
          </GlassCard>
        );
      })}
    </ScreenWrapper>
  );
}

// ======================== MOTIVATION SCREEN ========================
function MotivationScreen({ onBack }: { onBack: () => void }) {
  const [quoteIdx, setQuoteIdx] = useState(0);
  const [liked, setLiked] = useState(false);

  return (
    <ScreenWrapper onBack={onBack} title="Daily Motivation" subtitle="Your wellness inspiration">
      <GlassCard className="p-6" style={{ background: 'linear-gradient(135deg, rgba(0,200,151,0.15), rgba(74,158,255,0.15))', border: '1px solid rgba(0,200,151,0.3)' }}>
        <div className="text-3xl mb-4 text-center">✨</div>
        <p className="text-white text-center leading-relaxed mb-4" style={{ fontSize: '16px', fontStyle: 'italic' }}>
          "{motivationQuotes[quoteIdx].quote}"
        </p>
        <p className="text-center" style={{ color: '#00C897', fontSize: '12px' }}>— {motivationQuotes[quoteIdx].author}</p>
      </GlassCard>
      <div className="flex gap-3 justify-center">
        <ActionBtn color="#00C897" icon={RefreshCw} onClick={() => { setQuoteIdx((quoteIdx + 1) % motivationQuotes.length); setLiked(false); }}>New Quote</ActionBtn>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setLiked(!liked)}
          className="w-12 h-12 rounded-xl flex items-center justify-center"
          style={{ background: liked ? '#EF444420' : 'rgba(255,255,255,0.08)', border: liked ? '1px solid #EF444460' : '1px solid rgba(255,255,255,0.1)' }}
        >
          <Heart className="w-5 h-5" style={{ color: liked ? '#EF4444' : 'rgba(255,255,255,0.4)', fill: liked ? '#EF4444' : 'none' }} />
        </motion.button>
      </div>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Wellness Streak</h3>
        <div className="grid grid-cols-7 gap-1.5">
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
            <div key={i} className="flex flex-col items-center gap-1">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: i < 5 ? '#00C89730' : 'rgba(255,255,255,0.06)', border: i < 5 ? '1px solid #00C89760' : '1px solid rgba(255,255,255,0.1)' }}>
                {i < 5 ? <Check className="w-3.5 h-3.5" style={{ color: '#00C897' }} /> : <span style={{ fontSize: '10px', color: 'rgba(255,255,255,0.3)' }}>—</span>}
              </div>
              <span style={{ fontSize: '9px', color: 'rgba(255,255,255,0.4)' }}>{day}</span>
            </div>
          ))}
        </div>
        <p className="mt-3 text-white/60 text-center" style={{ fontSize: '12px' }}>🔥 5-day wellness streak! Keep going!</p>
      </GlassCard>
    </ScreenWrapper>
  );
}

// ======================== SLEEP PLANNER SCREEN ========================
function SleepPlannerScreen({ onBack }: { onBack: () => void }) {
  const [bedtime, setBedtime] = useState('22:30');
  const [wakeup, setWakeup] = useState('06:30');
  const [alarmOn, setAlarmOn] = useState(true);
  const [smartWakeup, setSmartWakeup] = useState(true);

  const calcDuration = () => {
    const [bh, bm] = bedtime.split(':').map(Number);
    const [wh, wm] = wakeup.split(':').map(Number);
    const bed = bh * 60 + bm;
    const wake = wh * 60 + wm;
    const diff = wake < bed ? (24 * 60 - bed + wake) : wake - bed;
    return `${Math.floor(diff / 60)}h ${diff % 60}m`;
  };

  return (
    <ScreenWrapper onBack={onBack} title="Sleep Planner" subtitle="Optimize your sleep schedule">
      <GlassCard className="p-5">
        <h3 className="text-white mb-4" style={{ fontSize: '14px', fontWeight: 600 }}>Tonight's Schedule</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-white/50 block mb-2" style={{ fontSize: '11px' }}>Bedtime 🌙</label>
            <input
              type="time"
              value={bedtime}
              onChange={e => setBedtime(e.target.value)}
              className="w-full rounded-xl px-3 py-2 text-white outline-none"
              style={{ background: 'rgba(74,158,255,0.15)', border: '1px solid rgba(74,158,255,0.4)', fontSize: '16px', colorScheme: 'dark' }}
            />
          </div>
          <div>
            <label className="text-white/50 block mb-2" style={{ fontSize: '11px' }}>Wake-up ⏰</label>
            <input
              type="time"
              value={wakeup}
              onChange={e => setWakeup(e.target.value)}
              className="w-full rounded-xl px-3 py-2 text-white outline-none"
              style={{ background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.4)', fontSize: '16px', colorScheme: 'dark' }}
            />
          </div>
        </div>
        <div className="mt-4 p-3 rounded-xl text-center" style={{ background: 'rgba(0,200,151,0.15)', border: '1px solid rgba(0,200,151,0.3)' }}>
          <span className="text-white/60" style={{ fontSize: '12px' }}>Planned Sleep Duration</span>
          <div className="font-bold" style={{ color: '#00C897', fontSize: '24px' }}>{calcDuration()}</div>
        </div>
      </GlassCard>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Smart Settings</h3>
        {[
          { label: 'Sleep Alarm', desc: 'Remind me 30 min before bedtime', state: alarmOn, set: setAlarmOn, color: '#4A9EFF' },
          { label: 'Smart Wake-up', desc: 'Wake during light sleep phase', state: smartWakeup, set: setSmartWakeup, color: '#00C897' },
        ].map(item => (
          <div key={item.label} className="flex items-center justify-between py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            <div>
              <p className="text-white" style={{ fontSize: '14px' }}>{item.label}</p>
              <p className="text-white/40" style={{ fontSize: '11px' }}>{item.desc}</p>
            </div>
            <motion.button
              onClick={() => item.set(!item.state)}
              className="w-12 h-6 rounded-full relative transition-all"
              style={{ background: item.state ? item.color : 'rgba(255,255,255,0.15)' }}
            >
              <motion.div
                animate={{ x: item.state ? 24 : 2 }}
                className="absolute top-0.5 w-5 h-5 rounded-full bg-white"
                style={{ bottom: 2 }}
              />
            </motion.button>
          </div>
        ))}
      </GlassCard>
      <ActionBtn color="#4A9EFF" icon={Timer}>Save Sleep Plan</ActionBtn>
    </ScreenWrapper>
  );
}

// ======================== AI HEALTH ASSISTANT SCREEN ========================
function AIAssistantScreen({ onBack }: { onBack: () => void }) {
  const [messages, setMessages] = useState([
    { role: 'ai', text: "Hi! I'm your AI health assistant. I can analyze your health data, answer questions, and provide personalized recommendations. How can I help you today? 😊" },
    { role: 'user', text: "Why have I been feeling tired lately?" },
    { role: 'ai', text: "Based on your health data, I notice you've been sleeping only 6.5 hours on average this week, below your 8-hour goal. Your activity levels also dropped by 15% this week. Here are my recommendations:\n\n• Aim for bed by 10:30 PM tonight\n• Try a 15-min afternoon walk\n• Check your iron and vitamin D levels\n\nWould you like me to schedule a health check?" },
  ]);
  const [input, setInput] = useState('');

  const aiReplies = [
    "Based on your health metrics, your cardiovascular health is looking great! Your resting heart rate of 68 BPM is in the optimal range.",
    "I've analyzed your sleep patterns. You tend to sleep best on weekends. Try maintaining a consistent schedule even on weekdays.",
    "Your water intake is slightly below optimal. I recommend drinking 2 glasses in the morning to boost your metabolism.",
    "Great question! Your weekly steps average of 8,391 is above the recommended 7,500. Keep up the excellent work! 🌟",
  ];

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMsg = { role: 'user', text: input };
    const aiMsg = { role: 'ai', text: aiReplies[Math.floor(Math.random() * aiReplies.length)] };
    setMessages(prev => [...prev, userMsg, aiMsg]);
    setInput('');
  };

  return (
    <ScreenWrapper onBack={onBack} title="AI Health Assistant" subtitle="Powered by VitaPulse AI">
      <div className="space-y-3 pb-2">
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            {msg.role === 'ai' && (
              <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ background: 'linear-gradient(135deg, #00C897, #4A9EFF)' }}>
                <Bot className="w-4 h-4 text-white" />
              </div>
            )}
            <div
              className="max-w-[85%] rounded-2xl px-4 py-3 whitespace-pre-line"
              style={msg.role === 'ai'
                ? { background: 'rgba(255,255,255,0.09)', color: 'rgba(255,255,255,0.85)', fontSize: '13px', borderBottomLeftRadius: 4 }
                : { background: 'linear-gradient(135deg, #00C897, #00A8FF)', color: '#fff', fontSize: '13px', borderBottomRightRadius: 4 }
              }
            >
              {msg.text}
            </div>
          </motion.div>
        ))}
      </div>
      <div className="sticky bottom-0 pt-2">
        <div className="flex gap-2 p-3 rounded-2xl" style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.1)' }}>
          <Mic className="w-5 h-5 text-white/40 shrink-0 mt-2.5" />
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendMessage()}
            placeholder="Ask about your health..."
            className="flex-1 bg-transparent text-white outline-none placeholder:text-white/30"
            style={{ fontSize: '14px' }}
          />
          <motion.button whileTap={{ scale: 0.9 }} onClick={sendMessage} className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'linear-gradient(135deg, #00C897, #4A9EFF)' }}>
            <Send className="w-4 h-4 text-white" />
          </motion.button>
        </div>
        <div className="flex gap-2 mt-2 flex-wrap">
          {['Sleep tips', 'My health score', 'Nutrition advice'].map(q => (
            <button key={q} onClick={() => setInput(q)} className="px-3 py-1.5 rounded-full text-white/60" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', fontSize: '11px' }}>
              {q}
            </button>
          ))}
        </div>
      </div>
    </ScreenWrapper>
  );
}

// ======================== HEALTH RISK PREDICTOR SCREEN ========================
function HealthRiskScreen({ onBack }: { onBack: () => void }) {
  return (
    <ScreenWrapper onBack={onBack} title="Health Risk Predictor" subtitle="AI-powered risk analysis">
      <GlassCard className="p-4" style={{ background: 'linear-gradient(135deg, rgba(0,200,151,0.12), rgba(74,158,255,0.12))', border: '1px solid rgba(0,200,151,0.25)' }}>
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-6 h-6" style={{ color: '#00C897' }} />
          <div>
            <p className="text-white font-semibold">Overall Risk Level</p>
            <p style={{ color: '#00C897', fontSize: '12px' }}>Low Risk — Great health profile!</p>
          </div>
        </div>
        <div className="flex items-center justify-center my-4">
          <div className="relative w-32 h-32">
            <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
              <circle cx="60" cy="60" r="50" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="10" />
              <circle cx="60" cy="60" r="50" fill="none" stroke="#00C897" strokeWidth="10" strokeDasharray={`${2 * Math.PI * 50 * 0.22} ${2 * Math.PI * 50}`} strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-white" style={{ fontSize: '28px', fontWeight: 700 }}>22%</span>
              <span className="text-white/40" style={{ fontSize: '10px' }}>Risk Score</span>
            </div>
          </div>
        </div>
      </GlassCard>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Risk Breakdown</h3>
        {riskFactors.map(rf => (
          <div key={rf.factor} className="mb-3">
            <div className="flex justify-between mb-1">
              <span className="text-white/70" style={{ fontSize: '13px' }}>{rf.factor}</span>
              <span className="px-2 py-0.5 rounded-full" style={{ background: `${rf.color}20`, color: rf.color, fontSize: '10px', fontWeight: 600 }}>{rf.level}</span>
            </div>
            <ProgressBar value={rf.risk} color={rf.color} />
          </div>
        ))}
      </GlassCard>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>AI Recommendations</h3>
        {['Reduce sodium intake to manage blood pressure risk', 'Schedule annual HbA1c test for diabetes screening', 'Add 20 min cardio 3x/week for heart health'].map((rec, i) => (
          <div key={i} className="flex items-start gap-2 mb-2">
            <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#00C897' }} />
            <span className="text-white/70" style={{ fontSize: '12px' }}>{rec}</span>
          </div>
        ))}
      </GlassCard>
      <ActionBtn color="#4A9EFF" icon={TrendingUp}>Run Full Analysis</ActionBtn>
    </ScreenWrapper>
  );
}

// ======================== MULTIMODAL INPUT SCREEN ========================
function MultimodalScreen({ onBack }: { onBack: () => void }) {
  const [activeMode, setActiveMode] = useState<'text' | 'voice' | 'image'>('text');
  const [text, setText] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  return (
    <ScreenWrapper onBack={onBack} title="Multimodal Input" subtitle="Text, Voice, or Image">
      <div className="grid grid-cols-3 gap-2">
        {([['text', MessageSquare, '#00C897', 'Type'], ['voice', Mic, '#4A9EFF', 'Speak'], ['image', Image, '#F59E0B', 'Upload']] as const).map(([mode, Icon, color, label]) => (
          <motion.button
            key={mode}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveMode(mode)}
            className="flex flex-col items-center gap-2 p-4 rounded-2xl transition-all"
            style={{ background: activeMode === mode ? `${color}20` : 'rgba(255,255,255,0.06)', border: `1px solid ${activeMode === mode ? `${color}60` : 'rgba(255,255,255,0.1)'}` }}
          >
            <Icon className="w-6 h-6" style={{ color: activeMode === mode ? color : 'rgba(255,255,255,0.4)' }} />
            <span style={{ fontSize: '12px', color: activeMode === mode ? color : 'rgba(255,255,255,0.5)', fontWeight: 600 }}>{label}</span>
          </motion.button>
        ))}
      </div>
      <AnimatePresence mode="wait">
        {activeMode === 'text' && (
          <motion.div key="text" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-4">
              <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                placeholder="Describe your symptoms, medications, or health concerns..."
                className="w-full bg-transparent text-white outline-none resize-none placeholder:text-white/30"
                rows={5}
                style={{ fontSize: '14px' }}
              />
              <div className="flex justify-between items-center mt-2">
                <span className="text-white/30" style={{ fontSize: '11px' }}>{text.length}/500</span>
                <ActionBtn color="#00C897" icon={Send} onClick={() => setText('')}>Submit</ActionBtn>
              </div>
            </GlassCard>
          </motion.div>
        )}
        {activeMode === 'voice' && (
          <motion.div key="voice" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-6 flex flex-col items-center">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsRecording(!isRecording)}
                className="w-20 h-20 rounded-full flex items-center justify-center mb-4"
                style={{ background: isRecording ? 'linear-gradient(135deg, #EF4444, #F97316)' : 'linear-gradient(135deg, #4A9EFF, #00C897)' }}
              >
                {isRecording ? <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1 }}><X className="w-8 h-8 text-white" /></motion.div> : <Mic className="w-8 h-8 text-white" />}
              </motion.button>
              <p className="text-white" style={{ fontSize: '14px' }}>{isRecording ? '🔴 Recording...' : 'Tap to start recording'}</p>
            </GlassCard>
          </motion.div>
        )}
        {activeMode === 'image' && (
          <motion.div key="image" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-6 flex flex-col items-center" style={{ border: '2px dashed rgba(245,158,11,0.4)' }}>
              <Image className="w-12 h-12 mb-3" style={{ color: '#F59E0B' }} />
              <p className="text-white mb-1" style={{ fontSize: '14px', fontWeight: 500 }}>Upload Health Image</p>
              <p className="text-white/40 text-center mb-4" style={{ fontSize: '12px' }}>Prescriptions, reports, skin conditions, X-rays</p>
              <ActionBtn color="#F59E0B" icon={Upload}>Choose Image</ActionBtn>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>
    </ScreenWrapper>
  );
}

// ======================== MEDICAL IMAGE SCANNER SCREEN ========================
function MedicalImageScreen({ onBack }: { onBack: () => void }) {
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(false);
  const runScan = () => { setScanning(true); setTimeout(() => { setScanning(false); setScanned(true); }, 2500); };

  return (
    <ScreenWrapper onBack={onBack} title="Medical Image Scanner" subtitle="AI-powered analysis">
      <GlassCard className="p-5 flex flex-col items-center" style={{ border: '1px solid rgba(167,139,250,0.3)' }}>
        {!scanned ? (
          <>
            <div className="relative w-40 h-40 mb-4">
              <div className="w-full h-full rounded-2xl flex items-center justify-center" style={{ background: 'rgba(167,139,250,0.1)', border: '2px dashed rgba(167,139,250,0.4)' }}>
                {scanning ? (
                  <div className="flex flex-col items-center">
                    <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}>
                      <Scan className="w-12 h-12" style={{ color: '#A78BFA' }} />
                    </motion.div>
                    <p className="text-white/60 mt-2" style={{ fontSize: '11px' }}>Analyzing...</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <Camera className="w-12 h-12 mx-auto mb-2" style={{ color: '#A78BFA' }} />
                    <p className="text-white/50" style={{ fontSize: '11px' }}>Upload Image</p>
                  </div>
                )}
              </div>
            </div>
            {!scanning && (
              <div className="flex gap-3">
                <ActionBtn color="#A78BFA" icon={Upload} onClick={runScan}>Upload & Scan</ActionBtn>
                <ActionBtn color="#A78BFA" variant="outline" icon={Camera}>Take Photo</ActionBtn>
              </div>
            )}
          </>
        ) : (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="w-full">
            <div className="flex items-center gap-2 mb-4 p-3 rounded-xl" style={{ background: 'rgba(0,200,151,0.15)', border: '1px solid rgba(0,200,151,0.3)' }}>
              <CheckCircle className="w-5 h-5" style={{ color: '#00C897' }} />
              <span className="text-white" style={{ fontSize: '13px', fontWeight: 500 }}>Analysis Complete</span>
            </div>
            {[['Type', 'Chest X-Ray'], ['Condition', 'Normal — No abnormalities'], ['Confidence', '96.4%'], ['Recommendation', 'No immediate action needed']].map(([label, val]) => (
              <div key={label} className="flex justify-between py-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                <span className="text-white/50" style={{ fontSize: '12px' }}>{label}</span>
                <span className="text-white" style={{ fontSize: '12px', fontWeight: 500 }}>{val}</span>
              </div>
            ))}
            <div className="flex gap-3 mt-4">
              <ActionBtn color="#A78BFA" icon={Download}>Save Report</ActionBtn>
              <ActionBtn color="#00C897" variant="outline" icon={RefreshCw} onClick={() => setScanned(false)}>Scan New</ActionBtn>
            </div>
          </motion.div>
        )}
      </GlassCard>
    </ScreenWrapper>
  );
}

// ======================== SYMPTOM CHECKER SCREEN ========================
function SymptomCheckerScreen({ onBack }: { onBack: () => void }) {
  const [query, setQuery] = useState('');
  const [checked, setChecked] = useState(false);
  const symptoms = ['Headache', 'Fever', 'Fatigue', 'Nausea', 'Cough', 'Chest Pain', 'Shortness of Breath', 'Dizziness'];
  const [selected, setSelected] = useState<string[]>(['Headache', 'Fatigue']);
  const toggle = (s: string) => setSelected(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  return (
    <ScreenWrapper onBack={onBack} title="Symptom & Medicine Checker" subtitle="AI-powered diagnosis support">
      <GlassCard className="p-4">
        <div className="flex gap-2 mb-3 rounded-xl overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
          <Search className="w-5 h-5 text-white/40 ml-3 shrink-0 my-3" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search symptoms or medicine..."
            className="flex-1 bg-transparent text-white outline-none py-3 pr-3"
            style={{ fontSize: '14px' }}
          />
        </div>
        <h4 className="text-white/60 mb-2" style={{ fontSize: '12px' }}>Select Your Symptoms</h4>
        <div className="flex flex-wrap gap-2">
          {symptoms.map(s => (
            <button
              key={s}
              onClick={() => toggle(s)}
              className="px-3 py-1.5 rounded-full transition-all"
              style={{
                background: selected.includes(s) ? '#00C89720' : 'rgba(255,255,255,0.06)',
                border: `1px solid ${selected.includes(s) ? '#00C89760' : 'rgba(255,255,255,0.1)'}`,
                color: selected.includes(s) ? '#00C897' : 'rgba(255,255,255,0.5)',
                fontSize: '12px'
              }}
            >
              {s}
            </button>
          ))}
        </div>
      </GlassCard>
      {checked && selected.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <GlassCard className="p-4">
            <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Possible Conditions</h3>
            {[
              { name: 'Tension Headache', match: '87%', severity: 'Mild', color: '#F59E0B' },
              { name: 'Viral Fatigue', match: '73%', severity: 'Mild', color: '#00C897' },
              { name: 'Dehydration', match: '65%', severity: 'Mild', color: '#4A9EFF' },
            ].map(c => (
              <div key={c.name} className="flex items-center justify-between p-3 rounded-xl mb-2" style={{ background: `${c.color}12`, border: `1px solid ${c.color}30` }}>
                <div>
                  <p className="text-white" style={{ fontSize: '13px', fontWeight: 500 }}>{c.name}</p>
                  <p style={{ color: c.color, fontSize: '11px' }}>Match: {c.match} • {c.severity}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-white/30" />
              </div>
            ))}
            <div className="mt-3 p-3 rounded-xl" style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)' }}>
              <p className="text-red-400" style={{ fontSize: '11px' }}>⚠️ This is not a medical diagnosis. Please consult a doctor for proper evaluation.</p>
            </div>
          </GlassCard>
        </motion.div>
      )}
      <div className="flex gap-3">
        <ActionBtn color="#00C897" icon={Stethoscope} onClick={() => setChecked(true)}>Check Now</ActionBtn>
        {checked && <ActionBtn color="#4A9EFF" variant="outline" icon={RefreshCw} onClick={() => { setChecked(false); setSelected([]); }}>Reset</ActionBtn>}
      </div>
    </ScreenWrapper>
  );
}

// ======================== FIRST AID SCREEN ========================
function FirstAidScreen({ onBack }: { onBack: () => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  const categories = [
    { name: 'CPR', icon: '❤️‍🔥', color: '#EF4444', steps: ['Call emergency services (911)', 'Push hard and fast on center of chest', '100-120 compressions per minute', 'Give rescue breaths every 30 compressions', 'Continue until help arrives'] },
    { name: 'Choking', icon: '🫁', color: '#F97316', steps: ['Ask "Are you choking?"', 'Give 5 back blows between shoulder blades', 'Give 5 abdominal thrusts (Heimlich)', 'Alternate until object dislodges', 'Call 911 if unconscious'] },
    { name: 'Burns', icon: '🔥', color: '#F59E0B', steps: ['Cool burn under cool (not cold) water for 20 min', 'Remove clothing near burn carefully', 'Cover with cling wrap or clean cloth', 'Do NOT apply ice, butter, or toothpaste', 'Seek medical attention for severe burns'] },
    { name: 'Bleeding', icon: '🩸', color: '#EF4444', steps: ['Apply direct pressure with clean cloth', 'Keep pressure for at least 10-15 minutes', 'Elevate the wound above heart level', 'Do NOT remove the cloth if soaked — add more', 'Seek emergency care for severe bleeding'] },
    { name: 'Fracture', icon: '🦴', color: '#8B5CF6', steps: ['Do not try to straighten the limb', 'Immobilize the injury with a splint', 'Apply ice wrapped in cloth for swelling', 'Elevate if possible', 'Seek emergency medical care immediately'] },
    { name: 'Seizure', icon: '⚡', color: '#A78BFA', steps: ['Clear area of hard or sharp objects', 'Cushion the head gently', 'Turn person to their side if possible', 'Time the seizure duration', 'Call 911 if seizure lasts >5 min'] },
  ];
  const selectedCat = categories.find(c => c.name === selected);

  return (
    <ScreenWrapper onBack={onBack} title="AI First Aid Guide" subtitle="Emergency step-by-step instructions" accentColor="#EF4444">
      {!selectedCat ? (
        <>
          <div className="p-3 rounded-xl mb-2" style={{ background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.4)' }}>
            <p className="text-red-300" style={{ fontSize: '12px' }}>🚨 For life-threatening emergencies, always call emergency services first!</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {categories.map(cat => (
              <GlassCard key={cat.name} className="p-4" onClick={() => setSelected(cat.name)} style={{ border: `1px solid ${cat.color}30` }}>
                <div className="text-3xl mb-2">{cat.icon}</div>
                <p className="text-white" style={{ fontSize: '14px', fontWeight: 600 }}>{cat.name}</p>
                <p className="text-white/40" style={{ fontSize: '11px' }}>{cat.steps.length} steps</p>
              </GlassCard>
            ))}
          </div>
        </>
      ) : (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <div className="flex items-center gap-3 mb-4">
            <span className="text-4xl">{selectedCat.icon}</span>
            <div>
              <h3 className="text-white" style={{ fontSize: '18px', fontWeight: 700 }}>{selectedCat.name}</h3>
              <p className="text-white/40" style={{ fontSize: '12px' }}>{selectedCat.steps.length} Emergency Steps</p>
            </div>
          </div>
          {selectedCat.steps.map((step, i) => (
            <GlassCard key={i} className="p-3 flex items-start gap-3 mb-2" style={{ border: `1px solid ${selectedCat.color}25` }}>
              <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 font-bold" style={{ background: `${selectedCat.color}25`, color: selectedCat.color, fontSize: '12px' }}>{i + 1}</div>
              <p className="text-white" style={{ fontSize: '13px', lineHeight: '1.5' }}>{step}</p>
            </GlassCard>
          ))}
          <div className="flex gap-3 mt-4">
            <ActionBtn color="#EF4444" icon={Phone}>Call Emergency</ActionBtn>
            <ActionBtn color={selectedCat.color} variant="outline" onClick={() => setSelected(null)}>← Back</ActionBtn>
          </div>
        </motion.div>
      )}
    </ScreenWrapper>
  );
}

// ======================== EMERGENCY DETECTION SCREEN ========================
function EmergencyScreen({ onBack }: { onBack: () => void }) {
  const [autoDetect, setAutoDetect] = useState(true);
  const [fallDetect, setFallDetect] = useState(true);
  const [heartAlert, setHeartAlert] = useState(false);
  const [sosActive, setSosActive] = useState(false);

  return (
    <ScreenWrapper onBack={onBack} title="Emergency Detection" subtitle="Auto alert system" accentColor="#EF4444">
      <GlassCard className="p-5" style={{ border: `2px solid ${sosActive ? '#EF4444' : 'rgba(255,255,255,0.1)'}`, background: sosActive ? 'rgba(239,68,68,0.1)' : CARD_BG }}>
        <div className="flex flex-col items-center">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setSosActive(!sosActive)}
            className="w-28 h-28 rounded-full flex items-center justify-center mb-4"
            style={{ background: sosActive ? 'linear-gradient(135deg, #EF4444, #DC2626)' : 'rgba(239,68,68,0.2)', border: '3px solid rgba(239,68,68,0.6)' }}
          >
            {sosActive ? (
              <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 0.8 }}>
                <AlertOctagon className="w-12 h-12 text-white" />
              </motion.div>
            ) : (
              <Phone className="w-12 h-12" style={{ color: '#EF4444' }} />
            )}
          </motion.button>
          <p className="text-white font-bold" style={{ fontSize: '16px' }}>{sosActive ? '🚨 SOS ACTIVE' : 'Press to Send SOS Alert'}</p>
          {sosActive && <p className="text-red-400 mt-1" style={{ fontSize: '12px' }}>Emergency contacts notified</p>}
        </div>
      </GlassCard>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Auto Detection Settings</h3>
        {[
          { label: 'Auto Emergency Detection', desc: 'AI monitors for emergency patterns', state: autoDetect, set: setAutoDetect, color: '#EF4444' },
          { label: 'Fall Detection', desc: 'Detects sudden falls via accelerometer', state: fallDetect, set: setFallDetect, color: '#F97316' },
          { label: 'Heart Rate Alerts', desc: 'Alert when BPM goes outside safe range', state: heartAlert, set: setHeartAlert, color: '#8B5CF6' },
        ].map(item => (
          <div key={item.label} className="flex items-center justify-between py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            <div>
              <p className="text-white" style={{ fontSize: '14px' }}>{item.label}</p>
              <p className="text-white/40" style={{ fontSize: '11px' }}>{item.desc}</p>
            </div>
            <motion.button onClick={() => item.set(!item.state)} className="w-12 h-6 rounded-full relative" style={{ background: item.state ? item.color : 'rgba(255,255,255,0.15)' }}>
              <motion.div animate={{ x: item.state ? 24 : 2 }} className="absolute top-0.5 w-5 h-5 rounded-full bg-white" />
            </motion.button>
          </div>
        ))}
      </GlassCard>
    </ScreenWrapper>
  );
}

// ======================== FAMILY HEALTH SCREEN ========================
function FamilyHealthScreen({ onBack }: { onBack: () => void }) {
  const [activeMember, setActiveMember] = useState(0);

  return (
    <ScreenWrapper onBack={onBack} title="Family Health Manager" subtitle="Manage all family profiles">
      <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4">
        {familyMembers.map((member, i) => (
          <motion.button
            key={member.id}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveMember(i)}
            className="flex flex-col items-center gap-1.5 p-3 rounded-2xl shrink-0 transition-all"
            style={{ background: activeMember === i ? `${member.color}20` : 'rgba(255,255,255,0.06)', border: `1px solid ${activeMember === i ? member.color + '60' : 'rgba(255,255,255,0.1)'}`, minWidth: 80 }}
          >
            <span className="text-3xl">{member.avatar}</span>
            <span style={{ fontSize: '11px', color: activeMember === i ? member.color : 'rgba(255,255,255,0.5)', fontWeight: 600 }}>{member.name.split(' ')[0]}</span>
          </motion.button>
        ))}
        <motion.button whileTap={{ scale: 0.95 }} className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl shrink-0" style={{ background: 'rgba(255,255,255,0.04)', border: '1px dashed rgba(255,255,255,0.2)', minWidth: 80 }}>
          <Plus className="w-6 h-6 text-white/30" />
          <span className="text-white/30" style={{ fontSize: '11px' }}>Add</span>
        </motion.button>
      </div>
      {(() => {
        const m = familyMembers[activeMember];
        return (
          <GlassCard className="p-5" style={{ border: `1px solid ${m.color}30` }}>
            <div className="flex items-center gap-4 mb-4">
              <span className="text-5xl">{m.avatar}</span>
              <div>
                <h3 className="text-white" style={{ fontSize: '18px', fontWeight: 700 }}>{m.name}</h3>
                <p className="text-white/50" style={{ fontSize: '13px' }}>Age {m.age}</p>
                <div className="mt-1 px-2.5 py-1 rounded-full inline-block" style={{ background: `${m.color}20`, border: `1px solid ${m.color}40` }}>
                  <span style={{ color: m.color, fontSize: '11px', fontWeight: 600 }}>{m.status}</span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[['Last Checkup', 'Jan 15, 2026'], ['Blood Type', 'O+'], ['Conditions', m.status === 'Healthy' ? 'None' : m.status], ['Allergies', 'Penicillin']].map(([k, v]) => (
                <div key={k} className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)' }}>
                  <p className="text-white/40" style={{ fontSize: '10px' }}>{k}</p>
                  <p className="text-white" style={{ fontSize: '12px', fontWeight: 500 }}>{v}</p>
                </div>
              ))}
            </div>
          </GlassCard>
        );
      })()}
      <div className="flex gap-3">
        <ActionBtn color="#00C897" icon={FileText}>View Records</ActionBtn>
        <ActionBtn color="#4A9EFF" variant="outline" icon={Calendar}>Schedule Checkup</ActionBtn>
      </div>
    </ScreenWrapper>
  );
}

// ======================== REPORT MANAGEMENT SCREEN ========================
function ReportManagementScreen({ onBack }: { onBack: () => void }) {
  const reports = [
    { name: 'Blood Test Report', date: 'Apr 28, 2026', type: 'Lab', size: '2.4 MB', color: '#EF4444' },
    { name: 'Chest X-Ray', date: 'Apr 15, 2026', type: 'Radiology', size: '8.1 MB', color: '#4A9EFF' },
    { name: 'ECG Report', date: 'Mar 30, 2026', type: 'Cardiology', size: '1.2 MB', color: '#F59E0B' },
    { name: 'Annual Health Checkup', date: 'Feb 10, 2026', type: 'General', size: '5.7 MB', color: '#00C897' },
    { name: 'MRI Brain Scan', date: 'Jan 20, 2026', type: 'Radiology', size: '32.5 MB', color: '#A78BFA' },
  ];

  return (
    <ScreenWrapper onBack={onBack} title="Report Management" subtitle="All your medical records">
      <GlassCard className="p-4 flex flex-col items-center" style={{ border: '2px dashed rgba(0,200,151,0.3)', background: 'rgba(0,200,151,0.05)' }}>
        <Upload className="w-10 h-10 mb-2" style={{ color: '#00C897' }} />
        <p className="text-white" style={{ fontSize: '14px', fontWeight: 500 }}>Upload New Report</p>
        <p className="text-white/40 text-center mt-1 mb-3" style={{ fontSize: '12px' }}>PDF, JPG, PNG — Max 50MB</p>
        <ActionBtn color="#00C897" icon={Plus}>Browse Files</ActionBtn>
      </GlassCard>
      {reports.map((r, i) => (
        <GlassCard key={i} className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${r.color}20` }}>
            <FileText className="w-5 h-5" style={{ color: r.color }} />
          </div>
          <div className="flex-1">
            <p className="text-white" style={{ fontSize: '13px', fontWeight: 500 }}>{r.name}</p>
            <p className="text-white/40" style={{ fontSize: '11px' }}>{r.type} • {r.date} • {r.size}</p>
          </div>
          <div className="flex gap-2">
            <motion.button whileTap={{ scale: 0.9 }} className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.06)' }}>
              <Eye className="w-4 h-4 text-white/50" />
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.06)' }}>
              <Download className="w-4 h-4 text-white/50" />
            </motion.button>
          </div>
        </GlassCard>
      ))}
    </ScreenWrapper>
  );
}

// ======================== HEALTHCARE FINDER SCREEN ========================
function HealthcareFinderScreen({ onBack }: { onBack: () => void }) {
  const [filter, setFilter] = useState('All');

  return (
    <ScreenWrapper onBack={onBack} title="Nearby Healthcare" subtitle="Facilities near you">
      <GlassCard className="p-4" style={{ background: 'linear-gradient(135deg, rgba(74,158,255,0.15), rgba(0,200,151,0.15))', border: '1px solid rgba(74,158,255,0.3)' }}>
        <div className="flex items-center gap-2 mb-3">
          <MapPin className="w-5 h-5" style={{ color: '#4A9EFF' }} />
          <span className="text-white" style={{ fontSize: '14px', fontWeight: 500 }}>📍 New York, NY — Updating...</span>
        </div>
        <div className="w-full h-40 rounded-xl overflow-hidden relative" style={{ background: 'rgba(74,158,255,0.1)', border: '1px solid rgba(74,158,255,0.2)' }}>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Map className="w-12 h-12 mx-auto mb-2 text-blue-400 opacity-60" />
              <p className="text-white/40" style={{ fontSize: '12px' }}>Map View</p>
            </div>
          </div>
          {[{ x: '30%', y: '40%', color: '#EF4444' }, { x: '55%', y: '55%', color: '#00C897' }, { x: '70%', y: '30%', color: '#F59E0B' }, { x: '45%', y: '70%', color: '#4A9EFF' }].map((pin, i) => (
            <motion.div key={i} animate={{ y: [0, -4, 0] }} transition={{ repeat: Infinity, duration: 2, delay: i * 0.5 }} className="absolute w-5 h-5" style={{ left: pin.x, top: pin.y }}>
              <MapPin className="w-5 h-5" style={{ color: pin.color }} />
            </motion.div>
          ))}
        </div>
      </GlassCard>
      <div className="flex gap-2">
        {['All', 'Hospital', 'Clinic', 'Pharmacy'].map(f => (
          <button key={f} onClick={() => setFilter(f)} className="px-3 py-1.5 rounded-full flex-1 text-center" style={{ background: filter === f ? '#4A9EFF20' : 'rgba(255,255,255,0.06)', border: `1px solid ${filter === f ? '#4A9EFF60' : 'rgba(255,255,255,0.1)'}`, color: filter === f ? '#4A9EFF' : 'rgba(255,255,255,0.5)', fontSize: '12px' }}>
            {f}
          </button>
        ))}
      </div>
      {nearbyPlaces.filter(p => filter === 'All' || p.type === filter).map((place, i) => (
        <GlassCard key={i} className="p-4 flex items-center gap-3" onClick={() => {}}>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: place.open ? '#00C89720' : 'rgba(255,255,255,0.06)' }}>
            <MapPin className="w-5 h-5" style={{ color: place.open ? '#00C897' : 'rgba(255,255,255,0.3)' }} />
          </div>
          <div className="flex-1">
            <p className="text-white" style={{ fontSize: '13px', fontWeight: 500 }}>{place.name}</p>
            <p className="text-white/40" style={{ fontSize: '11px' }}>{place.type} • {place.distance} away</p>
            <div className="flex items-center gap-1 mt-0.5">
              <Star className="w-3 h-3" style={{ color: '#F59E0B' }} />
              <span style={{ color: '#F59E0B', fontSize: '10px' }}>{place.rating}</span>
            </div>
          </div>
          <div className="px-2 py-1 rounded-full" style={{ background: place.open ? '#00C89720' : 'rgba(239,68,68,0.15)', border: `1px solid ${place.open ? '#00C89740' : 'rgba(239,68,68,0.3)'}` }}>
            <span style={{ color: place.open ? '#00C897' : '#EF4444', fontSize: '10px', fontWeight: 600 }}>{place.open ? 'Open' : 'Closed'}</span>
          </div>
        </GlassCard>
      ))}
    </ScreenWrapper>
  );
}

// ======================== SPECIALIST NAVIGATOR SCREEN ========================
function SpecialistScreen({ onBack }: { onBack: () => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  return (
    <ScreenWrapper onBack={onBack} title="Specialist Navigator" subtitle="Find doctors by specialty">
      <GlassCard className="p-4">
        <div className="flex gap-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
          <Search className="w-5 h-5 text-white/40 ml-3 my-3 shrink-0" />
          <input placeholder="Search specialists..." className="flex-1 bg-transparent text-white outline-none py-3" style={{ fontSize: '14px' }} />
        </div>
      </GlassCard>
      <div className="grid grid-cols-2 gap-3">
        {specialists.map((spec) => {
          const Icon = spec.icon;
          return (
            <GlassCard key={spec.type} className="p-4" onClick={() => setSelected(spec.type)} style={{ border: `1px solid ${selected === spec.type ? spec.color + '60' : 'rgba(255,255,255,0.1)'}`, background: selected === spec.type ? `${spec.color}12` : CARD_BG }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: `${spec.color}20` }}>
                <Icon className="w-5 h-5" style={{ color: spec.color }} />
              </div>
              <p className="text-white" style={{ fontSize: '13px', fontWeight: 600 }}>{spec.type}</p>
              <p className="text-white/40" style={{ fontSize: '11px' }}>{spec.count} doctors nearby</p>
              <div className="mt-2 px-2 py-0.5 rounded-full inline-block" style={{ background: spec.available ? '#00C89715' : 'rgba(239,68,68,0.12)', border: `1px solid ${spec.available ? '#00C89740' : 'rgba(239,68,68,0.3)'}` }}>
                <span style={{ color: spec.available ? '#00C897' : '#EF4444', fontSize: '9px', fontWeight: 600 }}>{spec.available ? '✓ Available' : 'Waitlist'}</span>
              </div>
            </GlassCard>
          );
        })}
      </div>
      {selected && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <ActionBtn color="#00C897" icon={Calendar}>Book Appointment with {selected}</ActionBtn>
        </motion.div>
      )}
    </ScreenWrapper>
  );
}

// ======================== OUTBREAK ALERTS SCREEN ========================
function OutbreakAlertsScreen({ onBack }: { onBack: () => void }) {
  const [notifOn, setNotifOn] = useState(true);
  return (
    <ScreenWrapper onBack={onBack} title="Outbreak Alerts" subtitle="Location-based health alerts" accentColor="#F59E0B">
      <GlassCard className="p-4" style={{ background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.3)' }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5" style={{ color: '#F59E0B' }} />
            <span className="text-white" style={{ fontSize: '14px', fontWeight: 600 }}>Live Monitoring Active</span>
          </div>
          <motion.button onClick={() => setNotifOn(!notifOn)} className="w-12 h-6 rounded-full relative" style={{ background: notifOn ? '#F59E0B' : 'rgba(255,255,255,0.15)' }}>
            <motion.div animate={{ x: notifOn ? 24 : 2 }} className="absolute top-0.5 w-5 h-5 rounded-full bg-white" />
          </motion.button>
        </div>
        <p className="text-white/50 mt-2" style={{ fontSize: '12px' }}>📍 Monitoring 10 km radius • New York, NY</p>
      </GlassCard>
      {outbreakAlerts.map((alert, i) => (
        <GlassCard key={i} className="p-4" style={{ border: `1px solid ${alert.color}30` }}>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${alert.color}20` }}>
              <AlertTriangle className="w-5 h-5" style={{ color: alert.color }} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <p className="text-white" style={{ fontSize: '14px', fontWeight: 600 }}>{alert.disease}</p>
                <span className="px-2 py-0.5 rounded-full" style={{ background: `${alert.color}20`, color: alert.color, fontSize: '9px', fontWeight: 700 }}>{alert.level}</span>
              </div>
              <p className="text-white/50" style={{ fontSize: '12px' }}>📍 {alert.area} • {alert.cases} reported cases</p>
              <ProgressBar value={alert.level === 'High' ? 75 : alert.level === 'Medium' ? 45 : 15} color={alert.color} height={4} />
            </div>
          </div>
        </GlassCard>
      ))}
      <ActionBtn color="#F59E0B" icon={Bell}>Subscribe to Alerts</ActionBtn>
    </ScreenWrapper>
  );
}

// ======================== EXPENSE TRACKER SCREEN ========================
function ExpenseTrackerScreen({ onBack }: { onBack: () => void }) {
  const [newExpense, setNewExpense] = useState('');
  const total = expenseData.reduce((a, b) => a + b.amount, 0);

  return (
    <ScreenWrapper onBack={onBack} title="Health Expense Tracker" subtitle="Monitor your health spending">
      <div className="grid grid-cols-2 gap-3">
        <GlassCard className="p-4" style={{ background: 'linear-gradient(135deg, rgba(0,200,151,0.15), rgba(74,158,255,0.15))', border: '1px solid rgba(0,200,151,0.3)' }}>
          <DollarSign className="w-6 h-6 mb-1" style={{ color: '#00C897' }} />
          <p className="text-white/60" style={{ fontSize: '11px' }}>This Month</p>
          <p className="text-white font-bold" style={{ fontSize: '26px' }}>${total}</p>
        </GlassCard>
        <GlassCard className="p-4" style={{ border: '1px solid rgba(245,158,11,0.3)' }}>
          <TrendingUp className="w-6 h-6 mb-1" style={{ color: '#F59E0B' }} />
          <p className="text-white/60" style={{ fontSize: '11px' }}>vs Last Month</p>
          <p className="font-bold" style={{ fontSize: '26px', color: '#F59E0B' }}>+9.8%</p>
        </GlassCard>
      </div>
      <GlassCard className="p-4">
        <h3 className="text-white mb-3" style={{ fontSize: '14px', fontWeight: 600 }}>Spending Breakdown</h3>
        <div className="flex gap-4 items-center">
          <div style={{ width: 120, height: 120 }}>
            <PieChart width={120} height={120}>
              <Pie data={expenseData} dataKey="amount" cx="50%" cy="50%" innerRadius={35} outerRadius={55} strokeWidth={0}>
                {expenseData.map((entry) => (
                  <Cell key={entry.category} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </div>
          <div className="flex-1 space-y-2">
            {expenseData.map((item) => (
              <div key={item.category} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: item.color }} />
                  <span className="text-white/60" style={{ fontSize: '12px' }}>{item.category}</span>
                </div>
                <span className="text-white" style={{ fontSize: '12px', fontWeight: 600 }}>${item.amount}</span>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>
    </ScreenWrapper>
  );
}

// ======================== PROFILE SCREEN ========================
function ProfileScreen({ onBack, onHomeClick }: { onBack: () => void; onHomeClick: () => void }) {
  return (
    <ScreenWrapper onBack={onBack} title="My Profile" subtitle="Health overview">
      <GlassCard className="p-5" style={{ background: 'linear-gradient(135deg, rgba(0,200,151,0.15), rgba(74,158,255,0.1))' }}>
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl" style={{ background: 'linear-gradient(135deg, #00C897, #4A9EFF)' }}>👨</div>
          <div>
            <h3 className="text-white" style={{ fontSize: '18px', fontWeight: 700 }}>Alex Johnson</h3>
            <p className="text-white/50" style={{ fontSize: '13px' }}>28 years • Male • O+</p>
            <div className="px-2.5 py-1 rounded-full inline-block mt-1" style={{ background: '#00C89720', border: '1px solid #00C89740' }}>
              <span style={{ color: '#00C897', fontSize: '11px', fontWeight: 600 }}>⭐ Premium Member</span>
            </div>
          </div>
        </div>
      </GlassCard>
      <div className="grid grid-cols-3 gap-3">
        {[['Height', '5\'11"', '#4A9EFF'], ['Weight', '75 kg', '#F59E0B'], ['BMI', '23.1', '#00C897']].map(([k, v, c]) => (
          <GlassCard key={k as string} className="p-3 text-center">
            <p className="font-bold" style={{ color: c as string, fontSize: '18px' }}>{v}</p>
            <p className="text-white/50" style={{ fontSize: '11px' }}>{k}</p>
          </GlassCard>
        ))}
      </div>
      {[['Health Goals', '4 Active'], ['Medical History', 'View All'], ['Settings', 'Account & Notifications']].map(([label, sub]) => (
        <GlassCard key={label as string} className="p-4 flex items-center justify-between" onClick={() => {}}>
          <div>
            <p className="text-white" style={{ fontSize: '14px' }}>{label as string}</p>
            <p className="text-white/40" style={{ fontSize: '11px' }}>{sub as string}</p>
          </div>
          <ChevronRight className="w-4 h-4 text-white/30" />
        </GlassCard>
      ))}
      <ActionBtn color="#EF4444" variant="outline" onClick={onHomeClick}>← Return to VitaPulse Home</ActionBtn>
    </ScreenWrapper>
  );
}

// ======================== DESKTOP SECTION LABEL ========================
function DesktopSectionLabel({ title, color, inline = false }: { title: string; color: string; inline?: boolean }) {
  return (
    <div className={`flex items-center gap-3 ${inline ? '' : 'mb-5'}`}>
      <div style={{ width: '3px', height: '18px', borderRadius: '99px', background: color, flexShrink: 0 }} />
      <span style={{ color, fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.12em' }}>{title}</span>
    </div>
  );
}

// ======================== DESKTOP DASHBOARD CARD ========================
function DashboardCard({ children, onClick, icon: Icon, iconBg, iconColor, title, subtitle, badge, badgeColor }: {
  children?: React.ReactNode;
  onClick?: () => void;
  icon: React.ElementType;
  iconBg: string;
  iconColor: string;
  title: string;
  subtitle: string;
  badge?: string;
  badgeColor?: string;
}) {
  return (
    <motion.div
      whileHover={onClick ? { y: -3, boxShadow: '0 12px 36px rgba(0,0,0,0.45)' } : undefined}
      whileTap={onClick ? { scale: 0.99 } : undefined}
      onClick={onClick}
      className={`rounded-2xl p-6 ${onClick ? 'cursor-pointer' : ''}`}
      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', boxShadow: '0 4px 20px rgba(0,0,0,0.3)' }}
    >
      <div className="flex items-start justify-between">
        <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: iconBg }}>
          <Icon className="w-5 h-5" style={{ color: iconColor }} />
        </div>
        {badge && badgeColor && (
          <span style={{ color: badgeColor, fontSize: '11px', fontWeight: 600, background: `${badgeColor}15`, border: `1px solid ${badgeColor}30`, borderRadius: '20px', padding: '4px 10px' }}>{badge}</span>
        )}
      </div>
      <h3 style={{ color: '#ffffff', fontSize: '16px', fontWeight: 600, marginBottom: '4px', marginTop: '16px' }}>{title}</h3>
      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px' }}>{subtitle}</p>
      {children}
    </motion.div>
  );
}

// ======================== DESKTOP MAIN DASHBOARD ========================
function DesktopMainDashboard({ onCardClick, showMoreAI, setShowMoreAI, bmi, bmiCategory, calorieRec, proteinRec }: {
  onCardClick: (id: ScreenId) => void;
  showMoreAI: boolean;
  setShowMoreAI: (v: boolean) => void;
  bmi: number;
  bmiCategory: { status: string; color: string; textColor: string };
  calorieRec: { calories: number; goal: string; range: string };
  proteinRec: { protein: number; note: string };
}) {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div style={{ padding: '48px 48px 64px', minHeight: '100%' }}>

      {/* ── TOP SECTION ── */}
      <div style={{ marginBottom: '32px' }}>
        <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: '13px', marginBottom: '8px' }}>Thursday, April 30, 2026</p>
        <h1 style={{ fontSize: '40px', fontWeight: 700, color: '#ffffff', lineHeight: 1.15, marginBottom: '10px' }}>
          Health Dashboard
        </h1>
        <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '15px', marginBottom: '28px' }}>
          Track, monitor, and improve your personal wellness journey.
        </p>
        {/* Search Bar */}
        <div className="flex items-center gap-4" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: '16px', padding: '14px 20px' }}>
          <Search style={{ color: 'rgba(255,255,255,0.3)', width: 20, height: 20, flexShrink: 0 }} />
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search symptoms, medicines, health reports, AI tools…"
            className="flex-1 bg-transparent text-white outline-none placeholder:text-white/30"
            style={{ fontSize: '15px' }}
          />
          <span style={{ color: 'rgba(255,255,255,0.2)', fontSize: '11px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', padding: '4px 8px' }}>⌘K</span>
        </div>
      </div>

      {/* ── STATS ROW – 3 large cards ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px', marginBottom: '40px' }}>

        {/* Steps */}
        <motion.div
          whileHover={{ y: -3, boxShadow: '0 12px 36px rgba(0,0,0,0.45)' }}
          onClick={() => onCardClick('weekly')}
          className="rounded-2xl p-6 cursor-pointer"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', boxShadow: '0 4px 20px rgba(0,0,0,0.3)' }}
        >
          <div className="flex items-start justify-between" style={{ marginBottom: '20px' }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(0,200,151,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Activity style={{ width: 20, height: 20, color: '#00C897' }} />
            </div>
            <span style={{ color: '#00C897', fontSize: '12px', fontWeight: 600, background: 'rgba(0,200,151,0.1)', border: '1px solid rgba(0,200,151,0.22)', borderRadius: 20, padding: '4px 10px' }}>+12% ↑</span>
          </div>
          <div style={{ marginBottom: '8px' }}>
            <span style={{ fontSize: '44px', fontWeight: 700, color: '#ffffff', lineHeight: 1 }}>8,432</span>
            <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '14px', marginLeft: '8px' }}>steps</span>
          </div>
          <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', marginBottom: '18px' }}>Goal: 10,000 steps today</p>
          <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 99, height: 6, overflow: 'hidden' }}>
            <motion.div
              initial={{ width: '0%' }}
              animate={{ width: '84%' }}
              transition={{ duration: 1.2, ease: 'easeOut', delay: 0.4 }}
              style={{ height: '100%', background: 'linear-gradient(90deg, #00C897, #00C89766)', borderRadius: 99 }}
            />
          </div>
          <div className="flex justify-between" style={{ marginTop: 8 }}>
            <span style={{ color: 'rgba(255,255,255,0.25)', fontSize: '11px' }}>0</span>
            <span style={{ color: '#00C897', fontSize: '11px', fontWeight: 600 }}>84% of goal</span>
            <span style={{ color: 'rgba(255,255,255,0.25)', fontSize: '11px' }}>10k</span>
          </div>
        </motion.div>

        {/* Heart Rate */}
        <motion.div
          whileHover={{ y: -3, boxShadow: '0 12px 36px rgba(0,0,0,0.45)' }}
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', boxShadow: '0 4px 20px rgba(0,0,0,0.3)' }}
        >
          <div className="flex items-start justify-between" style={{ marginBottom: '20px' }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(239,68,68,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <HeartPulse style={{ width: 20, height: 20, color: '#EF4444' }} />
            </div>
            <span style={{ color: '#10B981', fontSize: '12px', fontWeight: 600, background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.22)', borderRadius: 20, padding: '4px 10px' }}>Optimal</span>
          </div>
          <div style={{ marginBottom: '8px' }}>
            <span style={{ fontSize: '44px', fontWeight: 700, color: '#ffffff', lineHeight: 1 }}>72</span>
            <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '14px', marginLeft: '8px' }}>BPM</span>
          </div>
          <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', marginBottom: '18px' }}>Resting heart rate · ↓ from 74 BPM</p>
          <div className="flex items-end gap-1" style={{ height: '36px' }}>
            {[65, 68, 72, 70, 74, 71, 72, 70, 72].map((v, i) => (
              <div key={i} style={{ flex: 1, height: `${((v - 60) / 20) * 100}%`, background: i === 8 ? 'rgba(239,68,68,0.7)' : 'rgba(239,68,68,0.25)', borderRadius: '3px 3px 0 0', minHeight: 4 }} />
            ))}
          </div>
        </motion.div>

        {/* Sleep */}
        <motion.div
          whileHover={{ y: -3, boxShadow: '0 12px 36px rgba(0,0,0,0.45)' }}
          onClick={() => onCardClick('sleep')}
          className="rounded-2xl p-6 cursor-pointer"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', boxShadow: '0 4px 20px rgba(0,0,0,0.3)' }}
        >
          <div className="flex items-start justify-between" style={{ marginBottom: '20px' }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(74,158,255,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Moon style={{ width: 20, height: 20, color: '#4A9EFF' }} />
            </div>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'conic-gradient(#4A9EFF 65%, rgba(255,255,255,0.07) 65%)', padding: 3 }}>
              <div style={{ width: '100%', height: '100%', borderRadius: '50%', background: '#0D0D0D', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ color: '#4A9EFF', fontSize: '12px', fontWeight: 700, lineHeight: 1 }}>72</span>
                <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: '8px' }}>score</span>
              </div>
            </div>
          </div>
          <div style={{ marginBottom: '8px' }}>
            <span style={{ fontSize: '44px', fontWeight: 700, color: '#ffffff', lineHeight: 1 }}>6.5</span>
            <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '14px', marginLeft: '8px' }}>hrs</span>
          </div>
          <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', marginBottom: '14px' }}>Last night · 1.5h below goal</p>
          <div className="flex items-center gap-2">
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#F59E0B' }} />
            <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '12px' }}>Below 8-hour target</span>
          </div>
        </motion.div>
      </div>

      {/* ── AI INSIGHT ── */}
      <div style={{ marginBottom: '40px' }}>
        <motion.div
          whileHover={{ y: -1 }}
          className="rounded-2xl p-6 flex items-center gap-5"
          style={{ background: 'linear-gradient(135deg, rgba(0,200,151,0.07), rgba(74,158,255,0.07))', border: '1px solid rgba(0,200,151,0.14)', boxShadow: '0 4px 20px rgba(0,0,0,0.25)' }}
        >
          <div style={{ width: 52, height: 52, borderRadius: 16, background: 'linear-gradient(135deg, rgba(0,200,151,0.2), rgba(74,158,255,0.2))', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Bot style={{ width: 26, height: 26, color: '#00C897' }} />
          </div>
          <div style={{ flex: 1 }}>
            <div className="flex items-center gap-2" style={{ marginBottom: 8 }}>
              <span style={{ color: '#00C897', fontSize: '10px', fontWeight: 700, background: 'rgba(0,200,151,0.12)', borderRadius: 20, padding: '3px 8px', letterSpacing: '0.08em' }}>AI INSIGHT</span>
              <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: '12px' }}>VitaPulse AI · Just now</span>
            </div>
            <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '14px', lineHeight: 1.65, margin: 0 }}>
              You've completed <strong style={{ color: '#00C897' }}>3 of 4</strong> daily goals today. Sleep was 1.5h below your 8-hour target.
              Try a short 15-min walk after dinner and lights off by <strong style={{ color: '#4A9EFF' }}>10:30 PM</strong> tonight.
            </p>
          </div>
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => onCardClick('ai-chat')}
            className="flex items-center gap-2 rounded-xl"
            style={{ background: 'rgba(0,200,151,0.12)', border: '1px solid rgba(0,200,151,0.25)', color: '#00C897', padding: '10px 18px', flexShrink: 0 }}
          >
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Ask AI</span>
            <ArrowRight style={{ width: 15, height: 15 }} />
          </motion.button>
        </motion.div>
      </div>

      {/* ── BODY ANALYSIS ── */}
      <DesktopSectionLabel title="Body Analysis" color="#F59E0B" />
      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '14px', marginBottom: '24px', marginTop: '-12px' }}>
        Understand your body and get personalised fitness targets
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px', marginBottom: '40px' }}>

        {/* BMI Card with Scale */}
        <motion.div
          whileHover={{ y: -3, boxShadow: '0 12px 36px rgba(245,158,11,0.2)' }}
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: `2px solid ${bmiCategory.color}30`, boxShadow: `0 4px 20px ${bmiCategory.color}18` }}
        >
          <div className="flex items-center gap-2" style={{ marginBottom: '20px' }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: `${bmiCategory.color}14`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Target style={{ width: 20, height: 20, color: bmiCategory.color }} />
            </div>
            <div>
              <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '11px', margin: 0 }}>Your BMI</p>
              <p style={{ color: bmiCategory.textColor, fontSize: '12px', fontWeight: 600, margin: 0 }}>{bmiCategory.status}</p>
            </div>
          </div>

          {/* Large BMI Number */}
          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <span style={{ fontSize: '56px', fontWeight: 700, color: '#ffffff', lineHeight: 1 }}>
                {bmi.toFixed(1)}
              </span>
            </motion.div>
            <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: '12px', marginTop: '6px' }}>Body Mass Index</p>
          </div>

          {/* BMI Scale Bar */}
          <div style={{ marginTop: '20px' }}>
            <div style={{ position: 'relative', height: '8px', borderRadius: '99px', background: 'linear-gradient(90deg, #4A9EFF 0%, #10B981 25%, #F59E0B 50%, #EF4444 75%)', marginBottom: '12px' }}>
              <motion.div
                initial={{ left: '0%' }}
                animate={{ left: `${Math.min((bmi / 40) * 100, 100)}%` }}
                transition={{ duration: 1, delay: 0.5, type: 'spring', damping: 20 }}
                style={{
                  position: 'absolute',
                  top: '-6px',
                  transform: 'translateX(-50%)',
                  width: '20px',
                  height: '20px',
                  borderRadius: '50%',
                  background: '#ffffff',
                  border: `3px solid ${bmiCategory.color}`,
                  boxShadow: `0 0 12px ${bmiCategory.color}88`
                }}
              />
            </div>
            <div className="flex justify-between" style={{ fontSize: '9px', color: 'rgba(255,255,255,0.3)' }}>
              <span>18.5</span>
              <span>25</span>
              <span>30</span>
              <span>40</span>
            </div>
          </div>
        </motion.div>

        {/* Calorie Target Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          whileHover={{ y: -3, boxShadow: '0 12px 36px rgba(245,158,11,0.2)' }}
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '2px solid rgba(245,158,11,0.22)', boxShadow: '0 4px 20px rgba(245,158,11,0.12)' }}
        >
          <div className="flex items-center gap-2" style={{ marginBottom: '20px' }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(245,158,11,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Flame style={{ width: 20, height: 20, color: '#F59E0B' }} />
            </div>
            <div>
              <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '11px', margin: 0 }}>Daily Target</p>
              <p style={{ color: '#F59E0B', fontSize: '12px', fontWeight: 600, margin: 0 }}>Calories</p>
            </div>
          </div>

          <div style={{ marginBottom: '16px' }}>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <span style={{ fontSize: '48px', fontWeight: 700, color: '#ffffff', lineHeight: 1 }}>
                {calorieRec.calories.toLocaleString()}
              </span>
              <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '16px', marginLeft: '6px' }}>kcal</span>
            </motion.div>
          </div>

          <div style={{ padding: '12px 14px', borderRadius: 12, background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.18)' }}>
            <p style={{ color: '#F59E0B', fontSize: '12px', fontWeight: 600, margin: 0, marginBottom: 4 }}>{calorieRec.goal}</p>
            <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: '11px', margin: 0 }}>{calorieRec.range}</p>
          </div>
        </motion.div>

        {/* Protein Target Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          whileHover={{ y: -3, boxShadow: '0 12px 36px rgba(245,158,11,0.2)' }}
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '2px solid rgba(245,158,11,0.22)', boxShadow: '0 4px 20px rgba(245,158,11,0.12)' }}
        >
          <div className="flex items-center gap-2" style={{ marginBottom: '20px' }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(245,158,11,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Dumbbell style={{ width: 20, height: 20, color: '#F59E0B' }} />
            </div>
            <div>
              <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '11px', margin: 0 }}>Daily Target</p>
              <p style={{ color: '#F59E0B', fontSize: '12px', fontWeight: 600, margin: 0 }}>Protein</p>
            </div>
          </div>

          <div style={{ marginBottom: '16px' }}>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <span style={{ fontSize: '48px', fontWeight: 700, color: '#ffffff', lineHeight: 1 }}>
                {proteinRec.protein}
              </span>
              <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '16px', marginLeft: '6px' }}>g</span>
            </motion.div>
          </div>

          <div style={{ padding: '12px 14px', borderRadius: 12, background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.18)' }}>
            <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '11px', margin: 0 }}>{proteinRec.note}</p>
            <div className="flex items-center gap-1" style={{ marginTop: 6 }}>
              <div style={{ flex: 1, height: 4, background: 'rgba(255,255,255,0.1)', borderRadius: 99, overflow: 'hidden' }}>
                <motion.div
                  initial={{ width: '0%' }}
                  animate={{ width: '65%' }}
                  transition={{ duration: 1, delay: 0.8 }}
                  style={{ height: '100%', background: '#F59E0B', borderRadius: 99 }}
                />
              </div>
              <span style={{ color: '#F59E0B', fontSize: '10px', fontWeight: 600 }}>65%</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* ── DAILY HEALTH ── */}
      <DesktopSectionLabel title="Daily Health" color="#00C897" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '24px', marginBottom: '40px' }}>

        {/* Sleep Quality */}
        <DashboardCard
          onClick={() => onCardClick('sleep')}
          icon={Moon} iconBg="rgba(74,158,255,0.12)" iconColor="#4A9EFF"
          title="Sleep Quality" subtitle="Last night · Apr 30"
          badge="72/100" badgeColor="#4A9EFF"
        >
          <div className="flex gap-1 items-end" style={{ height: 52, marginTop: 20 }}>
            {sleepWeekData.map((d, i) => (
              <div key={d.day} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                <div style={{ flex: 1, width: '100%', display: 'flex', alignItems: 'flex-end' }}>
                  <div style={{ width: '100%', height: `${(d.hours / 10) * 100}%`, background: i === 3 ? 'rgba(74,158,255,0.55)' : 'rgba(255,255,255,0.07)', borderRadius: '4px 4px 0 0', minHeight: 4, transition: 'background 0.2s' }} />
                </div>
                <span style={{ fontSize: '9px', color: 'rgba(255,255,255,0.22)' }}>{d.day}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-2" style={{ marginTop: 16 }}>
            {[['Deep', '2.1h', '#6366F1'], ['REM', '1.8h', '#8B5CF6'], ['Light', '2.6h', '#4A9EFF']].map(([label, val, color]) => (
              <div key={label} style={{ flex: 1, textAlign: 'center', background: `${color}10`, borderRadius: 10, padding: '8px 4px', border: `1px solid ${color}22` }}>
                <div style={{ color, fontSize: '13px', fontWeight: 700 }}>{val}</div>
                <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: '10px' }}>{label}</div>
              </div>
            ))}
          </div>
        </DashboardCard>

        {/* Health Timeline */}
        <DashboardCard
          onClick={() => onCardClick('timeline')}
          icon={Activity} iconBg="rgba(0,200,151,0.12)" iconColor="#00C897"
          title="Health Timeline" subtitle="Today · 8 events logged"
          badge="Live" badgeColor="#00C897"
        >
          <div style={{ marginTop: 20, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {timelineEvents.slice(4, 7).map((event, i) => (
              <div key={i} className="flex items-center gap-3">
                <div style={{ width: 34, height: 34, borderRadius: 10, background: `${event.color}14`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', flexShrink: 0 }}>
                  {event.icon}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '13px', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{event.event}</p>
                  <p style={{ color: 'rgba(255,255,255,0.3)', fontSize: '11px', margin: 0 }}>{event.time}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-1" style={{ marginTop: 16 }}>
            <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: '12px' }}>+5 more events today</span>
            <ArrowRight style={{ width: 13, height: 13, color: 'rgba(255,255,255,0.35)' }} />
          </div>
        </DashboardCard>
      </div>

      {/* ── AI TOOLS ── */}
      <div className="flex items-center justify-between" style={{ marginBottom: 20 }}>
        <DesktopSectionLabel title="AI Tools" color="#A78BFA" inline />
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => setShowMoreAI(!showMoreAI)}
          className="flex items-center gap-2 rounded-xl"
          style={{ background: 'rgba(167,139,250,0.08)', border: '1px solid rgba(167,139,250,0.22)', color: '#A78BFA', padding: '8px 16px' }}
        >
          <span style={{ fontSize: '13px', fontWeight: 600 }}>{showMoreAI ? 'Show Less' : 'View More'}</span>
          <motion.div animate={{ rotate: showMoreAI ? 180 : 0 }} transition={{ duration: 0.2 }}>
            <ChevronDown style={{ width: 15, height: 15 }} />
          </motion.div>
        </motion.button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '24px', marginBottom: showMoreAI ? 16 : 40 }}>

        {/* AI Assistant */}
        <DashboardCard
          onClick={() => onCardClick('ai-chat')}
          icon={Bot} iconBg="rgba(0,200,151,0.12)" iconColor="#00C897"
          title="AI Health Assistant" subtitle="Chat-based health guidance"
          badge="AI" badgeColor="#00C897"
        >
          <div style={{ marginTop: 16, padding: '12px 14px', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px', lineHeight: 1.55, margin: 0 }}>
              💬 "Based on your data, your cardiovascular health looks great this week. Keep up the 8k+ steps!"
            </p>
          </div>
          <div className="flex items-center gap-2" style={{ marginTop: 10, padding: '10px 14px', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <span style={{ color: 'rgba(255,255,255,0.22)', fontSize: '13px', flex: 1 }}>Ask about your health...</span>
            <Send style={{ width: 15, height: 15, color: '#00C897' }} />
          </div>
        </DashboardCard>

        {/* Risk Predictor */}
        <DashboardCard
          onClick={() => onCardClick('risk')}
          icon={Shield} iconBg="rgba(74,158,255,0.12)" iconColor="#4A9EFF"
          title="Health Risk Predictor" subtitle="AI-powered risk analysis"
          badge="Low Risk" badgeColor="#10B981"
        >
          <div className="flex items-center gap-5" style={{ marginTop: 16 }}>
            <div className="relative" style={{ width: 80, height: 80, flexShrink: 0 }}>
              <svg viewBox="0 0 80 80" style={{ width: '100%', height: '100%', transform: 'rotate(-90deg)' }}>
                <circle cx="40" cy="40" r="32" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="8" />
                <circle cx="40" cy="40" r="32" fill="none" stroke="#10B981" strokeWidth="8" strokeDasharray={`${2 * Math.PI * 32 * 0.22} ${2 * Math.PI * 32}`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span style={{ color: '#fff', fontSize: '18px', fontWeight: 700, lineHeight: 1 }}>22%</span>
                <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '9px' }}>risk</span>
              </div>
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {riskFactors.slice(0, 3).map(rf => (
                <div key={rf.factor}>
                  <div className="flex justify-between" style={{ marginBottom: 3 }}>
                    <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '11px' }}>{rf.factor}</span>
                    <span style={{ color: rf.color, fontSize: '11px', fontWeight: 600 }}>{rf.risk}%</span>
                  </div>
                  <div style={{ height: 4, background: 'rgba(255,255,255,0.07)', borderRadius: 99, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${rf.risk}%`, background: rf.color, borderRadius: 99 }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DashboardCard>
      </div>

      {/* Expandable AI Tools */}
      <AnimatePresence>
        {showMoreAI && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            style={{ overflow: 'hidden', marginBottom: 40 }}
          >
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '24px', paddingTop: 4 }}>
              <DashboardCard
                onClick={() => onCardClick('multimodal')}
                icon={Mic} iconBg="rgba(167,139,250,0.12)" iconColor="#A78BFA"
                title="Multimodal Input" subtitle="Text · Voice · Image analysis"
              >
                <div className="flex gap-3" style={{ marginTop: 16 }}>
                  {[['💬', 'Text'], ['🎙️', 'Voice'], ['🖼️', 'Image']].map(([emoji, label]) => (
                    <div key={label} style={{ flex: 1, textAlign: 'center', padding: '12px 8px', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
                      <div style={{ fontSize: '20px', marginBottom: 4 }}>{emoji}</div>
                      <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: '11px' }}>{label}</div>
                    </div>
                  ))}
                </div>
              </DashboardCard>
              <DashboardCard
                onClick={() => onCardClick('image-scan')}
                icon={Scan} iconBg="rgba(245,158,11,0.12)" iconColor="#F59E0B"
                title="Medical Image Scanner" subtitle="Upload & analyze medical scans"
              >
                <div className="flex items-center gap-3" style={{ marginTop: 16, padding: '14px', borderRadius: 12, background: 'rgba(245,158,11,0.07)', border: '1px solid rgba(245,158,11,0.18)' }}>
                  <Camera style={{ width: 28, height: 28, color: '#F59E0B' }} />
                  <div>
                    <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: '13px', fontWeight: 500, margin: 0 }}>Upload Image</p>
                    <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: '11px', margin: 0 }}>X-Rays, MRI, ECG, Skin</p>
                  </div>
                </div>
              </DashboardCard>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── MEDICAL SUPPORT ── */}
      <DesktopSectionLabel title="Medical Support" color="#EF4444" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '24px', marginBottom: '40px' }}>

        {/* Medicine Checker */}
        <DashboardCard
          onClick={() => onCardClick('symptom')}
          icon={Pill} iconBg="rgba(239,68,68,0.12)" iconColor="#EF4444"
          title="Medicine Checker" subtitle="Symptoms & drug interactions"
        >
          <div className="flex items-center gap-2" style={{ marginTop: 16, padding: '11px 14px', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
            <Search style={{ width: 15, height: 15, color: 'rgba(255,255,255,0.22)' }} />
            <span style={{ color: 'rgba(255,255,255,0.22)', fontSize: '13px' }}>Search symptoms or medicine...</span>
          </div>
          <div className="flex flex-wrap gap-2" style={{ marginTop: 12 }}>
            {['Headache', 'Fatigue', 'Aspirin'].map(tag => (
              <span key={tag} style={{ background: 'rgba(239,68,68,0.09)', border: '1px solid rgba(239,68,68,0.2)', color: '#EF4444', borderRadius: 20, padding: '3px 10px', fontSize: '11px' }}>{tag}</span>
            ))}
          </div>
        </DashboardCard>

        {/* First Aid Guide */}
        <DashboardCard
          onClick={() => onCardClick('first-aid')}
          icon={HeartPulse} iconBg="rgba(249,115,22,0.12)" iconColor="#F97316"
          title="AI First Aid Guide" subtitle="Emergency step-by-step instructions"
          badge="Emergency" badgeColor="#EF4444"
        >
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 16 }}>
            {[['❤️‍🔥', 'CPR'], ['🔥', 'Burns'], ['🩸', 'Bleeding'], ['🫁', 'Choking'], ['🦴', 'Fracture'], ['⚡', 'Seizure']].map(([emoji, label]) => (
              <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '10px 4px', borderRadius: 10, background: 'rgba(249,115,22,0.07)', border: '1px solid rgba(249,115,22,0.14)' }}>
                <span style={{ fontSize: '18px' }}>{emoji}</span>
                <span style={{ color: 'rgba(255,255,255,0.45)', fontSize: '10px' }}>{label}</span>
              </div>
            ))}
          </div>
        </DashboardCard>
      </div>

      {/* ── RECORDS & FAMILY ── */}
      <DesktopSectionLabel title="Records & Family" color="#F59E0B" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '24px', marginBottom: '40px' }}>

        {/* Report Management */}
        <DashboardCard
          onClick={() => onCardClick('reports')}
          icon={FileText} iconBg="rgba(74,158,255,0.12)" iconColor="#4A9EFF"
          title="Report Management" subtitle="5 documents stored"
        >
          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              { name: 'Blood Test Report', date: 'Apr 28', color: '#EF4444' },
              { name: 'Chest X-Ray', date: 'Apr 15', color: '#4A9EFF' },
              { name: 'ECG Report', date: 'Mar 30', color: '#F59E0B' },
            ].map(r => (
              <div key={r.name} className="flex items-center gap-3" style={{ borderRadius: 10, padding: '9px 12px', background: 'rgba(255,255,255,0.04)' }}>
                <div style={{ width: 7, height: 7, borderRadius: '50%', background: r.color, flexShrink: 0 }} />
                <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: '12px', flex: 1 }}>{r.name}</span>
                <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: '11px' }}>{r.date}</span>
              </div>
            ))}
          </div>
        </DashboardCard>

        {/* Family Profiles */}
        <DashboardCard
          onClick={() => onCardClick('family')}
          icon={Users} iconBg="rgba(245,158,11,0.12)" iconColor="#F59E0B"
          title="Family Profiles" subtitle="4 profiles managed"
        >
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10, marginTop: 16 }}>
            {familyMembers.map(m => (
              <div key={m.id} className="flex items-center gap-3" style={{ padding: '10px 12px', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: `1px solid ${m.color}18` }}>
                <span style={{ fontSize: '22px' }}>{m.avatar}</span>
                <div>
                  <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '12px', fontWeight: 500, margin: 0 }}>{m.name.split(' ')[0]}</p>
                  <p style={{ color: m.color, fontSize: '10px', margin: 0 }}>{m.status}</p>
                </div>
              </div>
            ))}
          </div>
        </DashboardCard>
      </div>

      {/* ── HEALTHCARE ACCESS ── */}
      <DesktopSectionLabel title="Healthcare Access" color="#4A9EFF" />
      <div style={{ marginBottom: '40px' }}>
        <motion.div
          whileHover={{ y: -2, boxShadow: '0 12px 36px rgba(0,0,0,0.4)' }}
          onClick={() => onCardClick('healthcare')}
          className="rounded-2xl p-6 cursor-pointer"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', boxShadow: '0 4px 20px rgba(0,0,0,0.3)' }}
        >
          <div className="flex items-center justify-between" style={{ marginBottom: 20 }}>
            <div className="flex items-center gap-3">
              <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(74,158,255,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <MapPin style={{ width: 20, height: 20, color: '#4A9EFF' }} />
              </div>
              <div>
                <h3 style={{ color: '#fff', fontSize: '16px', fontWeight: 600, margin: 0 }}>Nearby Healthcare</h3>
                <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', margin: 0 }}>📍 New York, NY — 4 facilities found</p>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.03 }}
              className="flex items-center gap-2 rounded-xl"
              style={{ background: 'rgba(74,158,255,0.1)', border: '1px solid rgba(74,158,255,0.22)', color: '#4A9EFF', padding: '9px 16px' }}
              onClick={e => { e.stopPropagation(); }}
            >
              <span style={{ fontSize: '13px', fontWeight: 600 }}>View Map</span>
              <Navigation style={{ width: 14, height: 14 }} />
            </motion.button>
          </div>

          {/* Fake map preview */}
          <div className="relative rounded-2xl overflow-hidden" style={{ height: 160, background: 'rgba(74,158,255,0.05)', border: '1px solid rgba(74,158,255,0.1)', marginBottom: 20 }}>
            <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle, rgba(74,158,255,0.06) 1px, transparent 1px)', backgroundSize: '22px 22px' }} />
            <div className="absolute inset-0" style={{ backgroundImage: 'linear-gradient(rgba(74,158,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(74,158,255,0.04) 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
            {[
              { x: '22%', y: '38%', c: '#EF4444', icon: '🏥', label: 'City Medical' },
              { x: '56%', y: '58%', c: '#00C897', icon: '💊', label: 'Apollo Pharmacy' },
              { x: '72%', y: '25%', c: '#F59E0B', icon: '🏥', label: 'LifeCare Clinic' },
              { x: '40%', y: '72%', c: '#4A9EFF', icon: '🔬', label: 'WellnessFirst' },
            ].map((pin, i) => (
              <motion.div key={i} animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 2.5, delay: i * 0.65 }} style={{ position: 'absolute', left: pin.x, top: pin.y, transform: 'translate(-50%, -100%)' }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: `${pin.c}22`, border: `2px solid ${pin.c}55`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px' }}>{pin.icon}</div>
              </motion.div>
            ))}
            <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)', width: 12, height: 12, borderRadius: '50%', background: '#4A9EFF', boxShadow: '0 0 0 4px rgba(74,158,255,0.25)' }} />
          </div>

          {/* Places grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
            {nearbyPlaces.map((place, i) => (
              <div key={i} className="flex items-center gap-3" style={{ padding: '10px 14px', borderRadius: 12, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: place.open ? '#00C897' : '#EF4444', flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '12px', fontWeight: 500, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{place.name}</p>
                  <p style={{ color: 'rgba(255,255,255,0.3)', fontSize: '11px', margin: 0 }}>{place.distance} · {place.type}</p>
                </div>
                <span style={{ color: place.open ? '#00C897' : '#EF4444', fontSize: '10px', fontWeight: 600, flexShrink: 0 }}>{place.open ? 'Open' : 'Closed'}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

    </div>
  );
}

// ======================== MAIN EXPORT ========================
export function HealthDashboard({ onBack }: { onBack: () => void }) {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('main');
  const [activeNav, setActiveNav] = useState('dashboard');
  const [showMoreAI, setShowMoreAI] = useState(false);

  // User body metrics for BMI calculations
  const [userWeight] = useState(78); // kg
  const [userHeight] = useState(175); // cm

  // BMI calculations and recommendations
  const calculateBMI = () => {
    const heightInMeters = userHeight / 100;
    return userWeight / (heightInMeters * heightInMeters);
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { status: 'Underweight', color: '#4A9EFF', textColor: '#4A9EFF' };
    if (bmi < 25) return { status: 'Normal Weight', color: '#10B981', textColor: '#10B981' };
    if (bmi < 30) return { status: 'Overweight', color: '#F59E0B', textColor: '#F59E0B' };
    return { status: 'Obese', color: '#EF4444', textColor: '#EF4444' };
  };

  const getCalorieRecommendation = (bmi: number) => {
    const bmr = 10 * userWeight + 6.25 * userHeight - 5 * 28 + 5; // Mifflin-St Jeor for males, age 28
    const tdee = bmr * 1.55; // Moderate activity

    if (bmi < 18.5) {
      return { calories: Math.round(tdee + 400), goal: 'For healthy weight gain', range: '+300 to +500 surplus' };
    } else if (bmi < 25) {
      return { calories: Math.round(tdee), goal: 'For maintenance', range: 'Balanced maintenance' };
    } else if (bmi < 30) {
      return { calories: Math.round(tdee - 400), goal: 'For fat loss', range: '-300 to -500 deficit' };
    } else {
      return { calories: Math.round(tdee - 600), goal: 'For aggressive fat loss', range: '-500 to -700 deficit' };
    }
  };

  const getProteinRecommendation = (bmi: number) => {
    let multiplier = 1.6;
    if (bmi < 18.5) multiplier = 1.8;
    else if (bmi >= 25 && bmi < 30) multiplier = 2.2;
    else if (bmi >= 30) multiplier = 2.4;

    return {
      protein: Math.round(userWeight * multiplier),
      note: 'Based on your body weight & goal'
    };
  };

  const bmi = calculateBMI();
  const bmiCategory = getBMICategory(bmi);
  const calorieRec = getCalorieRecommendation(bmi);
  const proteinRec = getProteinRecommendation(bmi);

  const goTo = (id: ScreenId) => { setActiveScreen(id); };
  const goBack = () => { setActiveScreen('main'); setActiveNav('dashboard'); };

  const screenMap: Record<string, JSX.Element> = {
    sleep: <SleepScreen onBack={goBack} />,
    timeline: <TimelineScreen onBack={goBack} />,
    weekly: <WeeklyReportScreen onBack={goBack} />,
    goals: <GoalsScreen onBack={goBack} />,
    motivation: <MotivationScreen onBack={goBack} />,
    'sleep-planner': <SleepPlannerScreen onBack={goBack} />,
    'ai-chat': <AIAssistantScreen onBack={goBack} />,
    risk: <HealthRiskScreen onBack={goBack} />,
    multimodal: <MultimodalScreen onBack={goBack} />,
    'image-scan': <MedicalImageScreen onBack={goBack} />,
    symptom: <SymptomCheckerScreen onBack={goBack} />,
    'first-aid': <FirstAidScreen onBack={goBack} />,
    emergency: <EmergencyScreen onBack={goBack} />,
    family: <FamilyHealthScreen onBack={goBack} />,
    reports: <ReportManagementScreen onBack={goBack} />,
    healthcare: <HealthcareFinderScreen onBack={goBack} />,
    specialist: <SpecialistScreen onBack={goBack} />,
    outbreak: <OutbreakAlertsScreen onBack={goBack} />,
    expense: <ExpenseTrackerScreen onBack={goBack} />,
    profile: <ProfileScreen onBack={goBack} onHomeClick={onBack} />,
  };

  type NavItem = { id: string; icon: React.ElementType; label: string; screen?: ScreenId };

  const overviewNav: NavItem[] = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'health', icon: Activity, label: 'Health Metrics', screen: 'sleep' },
    { id: 'ai', icon: Bot, label: 'AI Tools', screen: 'ai-chat' },
  ];
  const toolsNav: NavItem[] = [
    { id: 'medical', icon: Stethoscope, label: 'Medical', screen: 'symptom' },
    { id: 'records', icon: FileText, label: 'Records', screen: 'reports' },
    { id: 'family', icon: Users, label: 'Family', screen: 'family' },
  ];
  const systemNav: NavItem[] = [
    { id: 'settings', icon: Settings, label: 'Settings', screen: 'profile' },
  ];

  const renderNavItems = (items: NavItem[]) =>
    items.map(item => {
      const Icon = item.icon;
      const isActive = activeNav === item.id;
      return (
        <button
          key={item.id}
          onClick={() => { setActiveNav(item.id); if (item.screen) goTo(item.screen); }}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 10,
            padding: '10px 12px', borderRadius: 12, marginBottom: 2,
            background: isActive ? 'rgba(0,200,151,0.1)' : 'transparent',
            border: 'none', cursor: 'pointer', textAlign: 'left',
            color: isActive ? '#00C897' : 'rgba(255,255,255,0.5)',
            transition: 'background 0.15s, color 0.15s',
          }}
        >
          <Icon style={{ width: 16, height: 16, flexShrink: 0 }} />
          <span style={{ fontSize: '14px', fontWeight: isActive ? 600 : 400, flex: 1 }}>{item.label}</span>
          {isActive && <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#00C897' }} />}
        </button>
      );
    });

  return (
    <div className="w-full h-screen flex relative overflow-hidden" style={{ background: '#0D0D0D' }}>

      {/* ── SUB-SCREEN OVERLAY ── */}
      <AnimatePresence mode="wait">
        {activeScreen !== 'main' && (
          <motion.div
            key={activeScreen}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="absolute inset-0 z-50"
            style={{ background: BG }}
          >
            {screenMap[activeScreen] ?? null}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── SIDEBAR ── */}
      <aside
        className="flex flex-col h-full"
        style={{ width: 260, flexShrink: 0, background: '#111111', borderRight: '1px solid rgba(255,255,255,0.06)' }}
      >
        {/* Logo */}
        <div style={{ padding: '28px 24px 20px' }}>
          <div className="flex items-center gap-3">
            <div style={{ width: 38, height: 38, borderRadius: 12, background: 'linear-gradient(135deg, #00C897, #00A8FF)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <HeartPulse style={{ width: 20, height: 20, color: '#fff' }} />
            </div>
            <div>
              <span style={{ color: '#ffffff', fontSize: '17px', fontWeight: 700 }}>VitaPulse</span>
              <div style={{ color: '#00C897', fontSize: '10px', fontWeight: 600, letterSpacing: '0.06em' }}>HEALTH</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '0 12px', overflowY: 'auto' }}>
          <p style={{ color: 'rgba(255,255,255,0.22)', fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.12em', padding: '0 12px', marginBottom: 8, marginTop: 4 }}>Overview</p>
          {renderNavItems(overviewNav)}

          <p style={{ color: 'rgba(255,255,255,0.22)', fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.12em', padding: '0 12px', marginBottom: 8, marginTop: 20 }}>Tools</p>
          {renderNavItems(toolsNav)}

          <p style={{ color: 'rgba(255,255,255,0.22)', fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.12em', padding: '0 12px', marginBottom: 8, marginTop: 20 }}>System</p>
          {renderNavItems(systemNav)}

          {/* Extra shortcuts */}
          <div style={{ marginTop: 20, padding: '14px', borderRadius: 14, background: 'rgba(0,200,151,0.07)', border: '1px solid rgba(0,200,151,0.14)' }}>
            <div className="flex items-center gap-2" style={{ marginBottom: 8 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#00C897' }} />
              <span style={{ color: '#00C897', fontSize: '11px', fontWeight: 600 }}>Today's Summary</span>
            </div>
            {[['Steps', '8,432', '#00C897'], ['Sleep', '6.5 hrs', '#4A9EFF'], ['Heart Rate', '72 BPM', '#EF4444']].map(([label, val, color]) => (
              <div key={label} className="flex justify-between items-center" style={{ marginBottom: 4 }}>
                <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '11px' }}>{label}</span>
                <span style={{ color, fontSize: '11px', fontWeight: 600 }}>{val}</span>
              </div>
            ))}
          </div>
        </nav>

        {/* User + Back */}
        <div style={{ padding: '16px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <div className="flex items-center gap-3" style={{ marginBottom: 12 }}>
            <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(0,200,151,0.14)', border: '1px solid rgba(0,200,151,0.28)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px' }}>👨</div>
            <div>
              <p style={{ color: '#ffffff', fontSize: '13px', fontWeight: 600, margin: 0 }}>Alex Johnson</p>
              <p style={{ color: '#00C897', fontSize: '10px', margin: 0 }}>⭐ Premium Member</p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={onBack}
            className="w-full flex items-center gap-2 rounded-xl"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.45)', padding: '10px 14px', cursor: 'pointer' }}
          >
            <ChevronLeft style={{ width: 15, height: 15 }} />
            <span style={{ fontSize: '13px' }}>Back to Home</span>
          </motion.button>
        </div>
      </aside>

      {/* ── MAIN CONTENT ── */}
      <main
        className="flex-1 h-full overflow-y-auto"
        style={{ scrollbarWidth: 'thin', scrollbarColor: 'rgba(255,255,255,0.08) transparent' }}
      >
        <DesktopMainDashboard
          onCardClick={(id) => { goTo(id); }}
          showMoreAI={showMoreAI}
          setShowMoreAI={setShowMoreAI}
          bmi={bmi}
          bmiCategory={bmiCategory}
          calorieRec={calorieRec}
          proteinRec={proteinRec}
        />
      </main>

    </div>
  );
}
