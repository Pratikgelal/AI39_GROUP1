import { motion } from 'motion/react';
import { Check, X, Heart, Activity, Brain, Users, Sparkles, Clock, Shield, Zap, TrendingUp, Star } from 'lucide-react';
import { ModernNavbar } from './ModernNavbar';
import { Footer } from './Footer';

interface LearnMorePageProps {
  onLoginClick: () => void;
  onRegisterClick: () => void;
  onGetStarted: () => void;
  onPrivacyClick: () => void;
  onHomeClick?: () => void;
}

export function LearnMorePage({ onLoginClick, onRegisterClick, onGetStarted, onPrivacyClick, onHomeClick }: LearnMorePageProps) {
  const plans = [
    {
      name: 'VitaPulse Basic',
      price: 'Free',
      popular: false,
      features: [
        { text: 'Basic health tracking (steps, sleep, water)', included: true },
        { text: 'AI symptom checker', included: true },
        { text: 'Weekly health tips', included: true },
        { text: 'Limited chat support', included: true },
        { text: '1 consultation per month', included: true },
        { text: 'Personalized diet & fitness plan', included: false },
        { text: 'Mental wellness support', included: false },
        { text: 'Priority support (24/7)', included: false },
      ],
      buttonText: 'Start Free',
      buttonStyle: 'border-2 border-emerald-500 text-emerald-600 hover:bg-emerald-50',
    },
    {
      name: 'VitaPulse Plus',
      price: '$9.99',
      period: '/month',
      popular: true,
      features: [
        { text: 'Everything in Basic', included: true },
        { text: 'Unlimited AI health assistant chat', included: true },
        { text: 'Personalized diet & fitness plan', included: true },
        { text: '4 doctor consultations/month', included: true },
        { text: 'Mental wellness support', included: true },
        { text: 'Health reports & insights', included: true },
        { text: 'Family health profiles (up to 4)', included: false },
        { text: 'Advanced AI health predictions', included: false },
      ],
      buttonText: 'Upgrade Now',
      buttonStyle: 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white hover:shadow-xl',
    },
    {
      name: 'VitaPulse Premium',
      price: '$19.99',
      period: '/month',
      popular: false,
      features: [
        { text: 'Everything in Plus', included: true },
        { text: 'Unlimited doctor consultations', included: true },
        { text: 'Family health profiles (up to 4 members)', included: true },
        { text: 'Advanced AI health predictions', included: true },
        { text: 'Priority support (24/7)', included: true },
        { text: 'Monthly full health analysis report', included: true },
        { text: 'Personalized supplement recommendations', included: true },
        { text: 'Direct specialist referrals', included: true },
      ],
      buttonText: 'Go Premium',
      buttonStyle: 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white hover:shadow-xl',
    },
  ];

  const comparisonFeatures = [
    { name: 'Health Tracking', basic: true, plus: true, premium: true },
    { name: 'AI Symptom Checker', basic: true, plus: true, premium: true },
    { name: 'Weekly Health Tips', basic: true, plus: true, premium: true },
    { name: 'Chat Support', basic: 'Limited', plus: 'Unlimited', premium: 'Unlimited' },
    { name: 'Doctor Consultations', basic: '1/month', plus: '4/month', premium: 'Unlimited' },
    { name: 'Personalized Plans', basic: false, plus: true, premium: true },
    { name: 'Mental Wellness', basic: false, plus: true, premium: true },
    { name: 'Health Reports', basic: false, plus: true, premium: true },
    { name: 'Family Profiles', basic: false, plus: false, premium: true },
    { name: 'AI Predictions', basic: false, plus: false, premium: true },
    { name: 'Priority Support', basic: false, plus: false, premium: true },
    { name: 'Full Health Analysis', basic: false, plus: false, premium: true },
  ];

  const steps = [
    {
      icon: Users,
      title: 'Sign Up',
      description: 'Create your account in under 2 minutes and complete your health profile',
    },
    {
      icon: Activity,
      title: 'Track Your Health',
      description: 'Monitor daily activities, sleep, nutrition, and vital signs with our smart tracker',
    },
    {
      icon: Brain,
      title: 'Get AI Insights & Doctor Support',
      description: 'Receive personalized recommendations and connect with healthcare professionals',
    },
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Fitness Enthusiast',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
      text: 'VitaPulse transformed how I approach my health. The AI insights are incredibly accurate, and having access to doctors anytime gives me peace of mind.',
      rating: 5,
    },
    {
      name: 'Michael Chen',
      role: 'Busy Professional',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
      text: 'As someone with a hectic schedule, VitaPulse Plus is perfect. The personalized diet plan and unlimited AI chat help me stay on track without visiting a clinic.',
      rating: 5,
    },
    {
      name: 'Emily Rodriguez',
      role: 'Mother of Two',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
      text: 'The Premium plan is worth every penny. Managing my whole family\'s health in one place is a game-changer. The health predictions caught an issue early!',
      rating: 5,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      <ModernNavbar onLoginClick={onLoginClick} onRegisterClick={onRegisterClick} onHomeClick={onHomeClick} />

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-br from-emerald-50 via-white to-blue-50">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full mb-6 shadow-lg">
              <Heart className="w-10 h-10 text-white" fill="white" />
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl mb-6 text-gray-900 leading-tight">
              Choose Your Health Journey<br />with <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-teal-600">VitaPulse</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-10 max-w-3xl mx-auto">
              Personalized care, smarter insights, and better health — all in one platform.
            </p>
            <motion.button
              onClick={onGetStarted}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-10 py-5 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-full shadow-xl hover:shadow-2xl transition-all text-lg"
            >
              Get Started Free
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-16 px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto text-center"
        >
          <p className="text-lg text-gray-700 leading-relaxed">
            <strong className="text-emerald-600">VitaPulse</strong> is your digital health assistant that provides{' '}
            <strong>AI-powered health insights</strong>, expert consultations, and personalized wellness plans.
            Whether you're tracking fitness goals, managing chronic conditions, or simply staying healthy,
            VitaPulse adapts to your unique needs and helps you make informed decisions about your wellbeing.
          </p>
        </motion.div>
      </section>

      {/* Subscription Plans */}
      <section className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4 text-gray-900">Choose Your Plan</h2>
            <p className="text-xl text-gray-600">Start free, upgrade anytime</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className={`relative bg-white rounded-3xl shadow-lg p-8 ${
                  plan.popular ? 'border-4 border-emerald-500 shadow-2xl' : 'border border-gray-200'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-6 py-2 rounded-full text-sm font-semibold shadow-lg flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      Most Popular
                    </div>
                  </div>
                )}

                <div className="text-center mb-8">
                  <h3 className="text-2xl mb-3 text-gray-900">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-5xl text-gray-900">{plan.price}</span>
                    {plan.period && <span className="text-gray-500 text-lg">{plan.period}</span>}
                  </div>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      {feature.included ? (
                        <Check className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                      ) : (
                        <X className="w-5 h-5 text-gray-300 flex-shrink-0 mt-0.5" />
                      )}
                      <span className={`text-sm ${feature.included ? 'text-gray-700' : 'text-gray-400'}`}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={onGetStarted}
                  className={`w-full py-4 rounded-full font-semibold transition-all ${plan.buttonStyle}`}
                >
                  {plan.buttonText}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4 text-gray-900">Feature Comparison</h2>
            <p className="text-xl text-gray-600">See what's included in each plan</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white rounded-3xl shadow-xl overflow-hidden"
          >
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="text-left py-6 px-6 text-gray-900">Feature</th>
                    <th className="text-center py-6 px-6 text-gray-900">Basic</th>
                    <th className="text-center py-6 px-6 text-emerald-600 bg-emerald-50">Plus</th>
                    <th className="text-center py-6 px-6 text-gray-900">Premium</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonFeatures.map((feature, idx) => (
                    <tr key={feature.name} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="py-5 px-6 text-gray-700">{feature.name}</td>
                      <td className="py-5 px-6 text-center">
                        {typeof feature.basic === 'boolean' ? (
                          feature.basic ? (
                            <Check className="w-5 h-5 text-emerald-500 mx-auto" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 mx-auto" />
                          )
                        ) : (
                          <span className="text-gray-700">{feature.basic}</span>
                        )}
                      </td>
                      <td className="py-5 px-6 text-center bg-emerald-50">
                        {typeof feature.plus === 'boolean' ? (
                          feature.plus ? (
                            <Check className="w-5 h-5 text-emerald-500 mx-auto" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 mx-auto" />
                          )
                        ) : (
                          <span className="text-gray-700">{feature.plus}</span>
                        )}
                      </td>
                      <td className="py-5 px-6 text-center">
                        {typeof feature.premium === 'boolean' ? (
                          feature.premium ? (
                            <Check className="w-5 h-5 text-emerald-500 mx-auto" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 mx-auto" />
                          )
                        ) : (
                          <span className="text-gray-700">{feature.premium}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-6 bg-gradient-to-br from-emerald-50 to-blue-50">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4 text-gray-900">How It Works</h2>
            <p className="text-xl text-gray-600">Get started in 3 simple steps</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-12">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="relative text-center"
              >
                <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full mb-6 shadow-lg">
                  <step.icon className="w-10 h-10 text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white shadow-lg">
                  {index + 1}
                </div>
                <h3 className="text-2xl mb-3 text-gray-900">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4 text-gray-900">What Our Users Say</h2>
            <p className="text-xl text-gray-600">Join thousands of satisfied members</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="bg-white rounded-3xl shadow-lg p-8"
              >
                <div className="flex items-center gap-4 mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400" fill="currentColor" />
                  ))}
                </div>
                <p className="text-gray-700 leading-relaxed">{testimonial.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 px-6 bg-gradient-to-br from-emerald-600 via-teal-600 to-green-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto text-center relative z-10"
        >
          <h2 className="text-4xl md:text-5xl lg:text-6xl text-white mb-6">
            Start Improving Your Health Today
          </h2>
          <p className="text-xl md:text-2xl text-white/90 mb-10">
            Join VitaPulse and take control of your wellness journey
          </p>
          <motion.button
            onClick={onGetStarted}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-12 py-5 bg-white text-emerald-600 rounded-full shadow-2xl hover:shadow-3xl transition-all text-lg"
          >
            Join Now - It's Free
          </motion.button>
        </motion.div>
      </section>

      <Footer onPrivacyClick={onPrivacyClick} />
    </div>
  );
}
