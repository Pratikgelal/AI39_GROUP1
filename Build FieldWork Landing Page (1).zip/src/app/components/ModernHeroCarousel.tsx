import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import useEmblaCarousel from 'embla-carousel-react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

interface ModernHeroCarouselProps {
  onGetStarted: () => void;
  onLearnMore: () => void;
}

const carouselCards = [
  {
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&h=800&fit=crop',
    title: 'Develop Healthy Habits',
    gradient: 'from-emerald-500/80 to-teal-600/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=1200&h=800&fit=crop',
    title: 'Track Your Fitness',
    gradient: 'from-blue-500/80 to-cyan-600/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=1200&h=800&fit=crop',
    title: 'Eat Clean, Live Strong',
    gradient: 'from-orange-500/80 to-amber-600/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=1200&h=800&fit=crop',
    title: 'Consult Health Experts',
    gradient: 'from-teal-500/80 to-emerald-600/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&h=800&fit=crop',
    title: 'Transform Your Body',
    gradient: 'from-purple-500/80 to-pink-600/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=1200&h=800&fit=crop',
    title: 'Stay Mentally Fit',
    gradient: 'from-indigo-500/80 to-purple-600/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=1200&h=800&fit=crop',
    title: 'Build Strength & Power',
    gradient: 'from-red-500/80 to-orange-600/80',
  },
  {
    image: 'https://images.unsplash.com/photo-1599058917212-d750089bc07e?w=1200&h=800&fit=crop',
    title: 'Find Your Balance',
    gradient: 'from-green-500/80 to-teal-600/80',
  },
];

export function ModernHeroCarousel({ onGetStarted, onLearnMore }: ModernHeroCarouselProps) {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    loop: true,
    align: 'center',
    skipSnaps: false,
    dragFree: false,
  });
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);

    // Auto-play
    const autoplay = setInterval(() => {
      emblaApi.scrollNext();
    }, 4000);

    return () => {
      clearInterval(autoplay);
      emblaApi.off('select', onSelect);
      emblaApi.off('reInit', onSelect);
    };
  }, [emblaApi, onSelect]);

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-gray-50 via-emerald-50/30 to-teal-50/30 overflow-hidden" id="home">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 left-10 w-72 h-72 bg-emerald-400/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-orange-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-teal-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Content Container */}
      <div className="relative pt-32 pb-20 px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-6xl lg:text-7xl mb-4 text-gray-900 leading-tight">
            Your Journey to <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-teal-600">Wellness</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto">
            Transform your health with AI-powered insights and personalized care
          </p>
        </motion.div>

        {/* Carousel Container */}
        <div className="relative max-w-7xl mx-auto">
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex gap-6 py-12">
              {carouselCards.map((card, index) => {
                const isCenter = index === selectedIndex;
                const distance = Math.abs(index - selectedIndex);

                return (
                  <motion.div
                    key={index}
                    className="flex-shrink-0 w-[85%] sm:w-[70%] md:w-[60%] lg:w-[50%] xl:w-[45%]"
                    animate={{
                      scale: isCenter ? 1 : 0.85,
                      opacity: isCenter ? 1 : 0.6,
                      rotateY: isCenter ? 0 : distance > 0 ? -12 : 12,
                      filter: isCenter ? 'blur(0px)' : 'blur(2px)',
                    }}
                    transition={{ duration: 0.5, ease: 'easeOut' }}
                    whileHover={{
                      scale: 1.02,
                      y: -8,
                    }}
                    style={{
                      transformStyle: 'preserve-3d',
                      perspective: '1000px',
                    }}
                  >
                    <div className="relative h-[400px] md:h-[500px] rounded-3xl overflow-hidden shadow-2xl group cursor-pointer">
                      {/* Image */}
                      <img
                        src={card.image}
                        alt={card.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />

                      {/* Gradient Overlay */}
                      <div className={`absolute inset-0 bg-gradient-to-br ${card.gradient} opacity-60 group-hover:opacity-70 transition-opacity duration-300`} />

                      {/* Glassmorphism Text */}
                      <div className="absolute inset-0 flex items-end p-8">
                        <div className="w-full bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 transform transition-all duration-300 group-hover:bg-white/20">
                          <h3 className="text-3xl md:text-4xl text-white mb-2 drop-shadow-lg">
                            {card.title}
                          </h3>
                          <div className="h-1 w-20 bg-white/60 rounded-full" />
                        </div>
                      </div>

                      {/* Glow Effect */}
                      {isCenter && (
                        <div className="absolute inset-0 rounded-3xl shadow-[0_0_60px_rgba(0,200,151,0.4)] pointer-events-none" />
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={scrollPrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/90 backdrop-blur-md rounded-full shadow-xl flex items-center justify-center text-gray-900 hover:bg-white hover:scale-110 transition-all z-10"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={scrollNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/90 backdrop-blur-md rounded-full shadow-xl flex items-center justify-center text-gray-900 hover:bg-white hover:scale-110 transition-all z-10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* CTA Buttons Below Center Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-6 justify-center items-center mt-16"
        >
          <motion.button
            onClick={onGetStarted}
            whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(0, 200, 151, 0.6)' }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-10 py-5 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-full shadow-xl flex items-center gap-3 overflow-hidden"
            animate={{
              y: [0, -8, 0],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          >
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-300" />

            {/* Ripple Effect */}
            <div className="absolute inset-0 rounded-full bg-white/20 scale-0 group-hover:scale-100 transition-transform duration-500" />

            <span className="relative text-lg z-10">Get Started Free</span>
            <ArrowRight className="relative w-5 h-5 z-10 group-hover:translate-x-1 transition-transform" />
          </motion.button>

          <motion.button
            onClick={onLearnMore}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-10 py-5 bg-white/40 backdrop-blur-xl text-gray-900 rounded-full border-2 border-gray-300/50 shadow-lg hover:bg-white/60 hover:border-emerald-500/50 transition-all"
            animate={{
              y: [0, -8, 0],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 0.5,
            }}
          >
            <span className="text-lg">Learn More</span>
          </motion.button>
        </motion.div>

        {/* Carousel Indicators */}
        <div className="flex justify-center gap-2 mt-12">
          {carouselCards.map((_, index) => (
            <button
              key={index}
              onClick={() => emblaApi?.scrollTo(index)}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === selectedIndex
                  ? 'w-12 bg-gradient-to-r from-emerald-500 to-teal-500 shadow-lg'
                  : 'w-2 bg-gray-300 hover:bg-gray-400'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
