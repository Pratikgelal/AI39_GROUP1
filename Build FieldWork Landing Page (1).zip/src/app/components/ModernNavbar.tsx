import { Search, User, Menu, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface ModernNavbarProps {
  onLoginClick?: () => void;
  onRegisterClick?: () => void;
  onHomeClick?: () => void;
}

export function ModernNavbar({ onLoginClick, onRegisterClick, onHomeClick }: ModernNavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Home', href: '#home' },
    { label: 'BMI Calculator', href: '#bmi' },
    { label: 'Wellness', href: '#wellness' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/80 backdrop-blur-2xl shadow-lg border-b border-gray-200/50'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button onClick={onHomeClick} className="flex items-center space-x-2 group cursor-pointer">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow">
              <div className="w-6 h-6 border-3 border-white rounded-full relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                </div>
              </div>
            </div>
            <span className={`text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent transition-opacity ${
              isScrolled ? 'opacity-100' : 'opacity-0 md:opacity-100'
            }`}>
              VITAPULSE
            </span>
          </button>

          {/* Center Navigation - Desktop */}
          <div className="hidden lg:flex items-center space-x-1">
            {menuItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className={`relative px-4 py-2 rounded-lg transition-colors group ${
                  isScrolled ? 'text-gray-700 hover:text-emerald-600' : 'text-gray-700 hover:text-emerald-600'
                }`}
              >
                <span className="relative z-10">{item.label}</span>
                {/* Hover underline animation */}
                <span className="absolute bottom-1 left-1/2 w-0 h-0.5 bg-gradient-to-r from-emerald-500 to-teal-500 group-hover:w-3/4 group-hover:left-1/8 transition-all duration-300 rounded-full" />
                {/* Hover background */}
                <span className="absolute inset-0 bg-emerald-50 opacity-0 group-hover:opacity-100 rounded-lg transition-opacity duration-300" />
              </a>
            ))}
          </div>

          {/* Right Side - Search & Auth */}
          <div className="flex items-center space-x-3">
            {/* Search Box - Desktop */}
            <div className={`hidden md:flex items-center space-x-2 px-4 py-2.5 rounded-full transition-all ${
              isScrolled
                ? 'bg-gray-100 border border-gray-200'
                : 'bg-white/90 backdrop-blur-md border border-white/50 shadow-lg'
            }`}>
              <Search className="w-4 h-4 text-gray-500" />
              <input
                type="text"
                placeholder="Search..."
                className="bg-transparent outline-none w-32 xl:w-40 placeholder:text-sm text-gray-700 placeholder:text-gray-500"
              />
            </div>

            {/* Login Button */}
            <button
              onClick={onLoginClick}
              className={`hidden sm:flex items-center space-x-2 px-5 py-2.5 rounded-full border-2 transition-all hover:scale-105 ${
                isScrolled
                  ? 'border-emerald-500 text-emerald-600 hover:bg-emerald-50'
                  : 'border-white/80 text-gray-700 hover:bg-white/20 backdrop-blur-md bg-white/50'
              }`}
            >
              <User className="w-4 h-4" />
              <span>Login</span>
            </button>

            {/* Register Button */}
            <button
              onClick={onRegisterClick}
              className="hidden sm:flex items-center space-x-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-orange-500 to-amber-500 text-white hover:shadow-xl hover:scale-105 transition-all shadow-lg"
            >
              <span>Register</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`lg:hidden w-10 h-10 rounded-full flex items-center justify-center ${
                isScrolled ? 'bg-gray-100' : 'bg-white/80 backdrop-blur-md'
              }`}
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 text-gray-700" />
              ) : (
                <Menu className="w-5 h-5 text-gray-700" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="lg:hidden bg-white/95 backdrop-blur-2xl border-t border-gray-200"
          >
            <div className="px-6 py-4 space-y-2">
              {menuItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-4 py-3 rounded-xl text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors"
                >
                  {item.label}
                </a>
              ))}
              <div className="pt-4 space-y-2 border-t border-gray-200">
                <button
                  onClick={onLoginClick}
                  className="w-full px-4 py-3 rounded-xl border-2 border-emerald-500 text-emerald-600 hover:bg-emerald-50 transition-colors flex items-center justify-center gap-2"
                >
                  <User className="w-4 h-4" />
                  Login
                </button>
                <button
                  onClick={onRegisterClick}
                  className="w-full px-4 py-3 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-white hover:shadow-xl transition-all"
                >
                  Register
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
