import { Search, User } from 'lucide-react';
import { useEffect, useState } from 'react';

interface NavbarProps {
  onLoginClick?: () => void;
  onRegisterClick?: () => void;
  onHomeClick?: () => void;
}

export function Navbar({ onLoginClick, onRegisterClick, onHomeClick }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/90 backdrop-blur-lg shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button onClick={onHomeClick} className="flex items-center space-x-2 cursor-pointer">
            <div className={`text-2xl font-bold transition-colors ${isScrolled ? 'text-emerald-600' : 'text-white'}`}>
              VITAPULSE
            </div>
          </button>

          {/* Center Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a
              href="#home"
              className={`transition-colors hover:text-emerald-500 ${
                isScrolled ? 'text-gray-800' : 'text-white'
              }`}
            >
              Home
            </a>
            <a
              href="#bmi"
              className={`transition-colors hover:text-emerald-500 ${
                isScrolled ? 'text-gray-800' : 'text-white'
              }`}
            >
              BMI Calculator
            </a>
            <a
              href="#wellness"
              className={`transition-colors hover:text-emerald-500 ${
                isScrolled ? 'text-gray-800' : 'text-white'
              }`}
            >
              Wellness
            </a>
            <a
              href="#about"
              className={`transition-colors hover:text-emerald-500 ${
                isScrolled ? 'text-gray-800' : 'text-white'
              }`}
            >
              About
            </a>
            <a
              href="#contact"
              className={`transition-colors hover:text-emerald-500 ${
                isScrolled ? 'text-gray-800' : 'text-white'
              }`}
            >
              Contact
            </a>
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* Search Box */}
            <div className={`hidden lg:flex items-center space-x-2 px-4 py-2 rounded-full transition-all ${
              isScrolled ? 'bg-gray-100' : 'bg-white/20 backdrop-blur-md'
            }`}>
              <Search className={`w-4 h-4 ${isScrolled ? 'text-gray-600' : 'text-white'}`} />
              <input
                type="text"
                placeholder="Search..."
                className={`bg-transparent outline-none w-32 placeholder:text-sm ${
                  isScrolled ? 'text-gray-800 placeholder:text-gray-500' : 'text-white placeholder:text-white/70'
                }`}
              />
            </div>

            {/* Login/Register Button */}
            <button
              onClick={onLoginClick}
              className="flex items-center space-x-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white hover:shadow-lg transition-all hover:scale-105"
            >
              <User className="w-4 h-4" />
              <span className="hidden sm:inline">Login</span>
            </button>
            <button
              onClick={onRegisterClick}
              className="hidden sm:flex items-center space-x-2 px-5 py-2.5 rounded-full text-white hover:shadow-lg transition-all hover:scale-105"
              style={{ background: 'linear-gradient(135deg, #ff6b35, #f7931e)' }}
            >
              <span>Register</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}