import { useState } from 'react';
import { Activity, Heart, Droplet, Target, User, Apple, Dumbbell, Calendar, Award } from 'lucide-react';

interface OnboardingPageProps {
  onBack: () => void;
  onComplete: () => void;
}

type Goal = 'weight-loss' | 'muscle-gain' | 'maintain' | 'wellness';

export function OnboardingPage({ onBack, onComplete }: OnboardingPageProps) {
  const [currentSection, setCurrentSection] = useState(1);
  const totalSections = 6;

  // Form state
  const [formData, setFormData] = useState({
    // Basic Profile
    fullName: '',
    age: '',
    gender: 'male',
    height: '',
    currentWeight: '',
    targetWeight: '',
    country: '',

    // Health Information
    medicalConditions: [] as string[],
    injuries: '',
    allergies: '',
    dietaryRestrictions: [] as string[],
    sleepDuration: '7',

    // Fitness Profile
    goal: 'wellness' as Goal,
    activityLevel: 'moderate',
    workoutPreference: [] as string[],

    // Nutrition & Lifestyle
    mealsPerDay: '3',
    waterIntake: '2',
    foodPreference: '',
    calorieTracking: false,
    smoking: false,
    alcohol: false,

    // Personalization
    workoutDays: 3,
    timePerWorkout: '30',
    mainChallenges: [] as string[],

    // Features
    customMealPlans: true,
    workoutPlans: true,
    progressTracking: true,
  });

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayValue = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: (prev[field as keyof typeof prev] as string[]).includes(value)
        ? (prev[field as keyof typeof prev] as string[]).filter(v => v !== value)
        : [...(prev[field as keyof typeof prev] as string[]), value]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    onComplete();
  };

  const goalCards = [
    { id: 'weight-loss', label: 'Weight Loss', icon: Target },
    { id: 'muscle-gain', label: 'Muscle Gain', icon: Dumbbell },
    { id: 'maintain', label: 'Maintain', icon: Activity },
    { id: 'wellness', label: 'Wellness', icon: Heart },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-green-50 py-12 px-4">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="absolute top-6 left-6 text-gray-600 hover:text-gray-900 transition-colors"
      >
        ← Back
      </button>

      {/* Main Card Container */}
      <div className="max-w-2xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl mb-4 shadow-lg">
            <Heart className="w-8 h-8 text-white" fill="white" />
          </div>
          <h1 className="text-4xl mb-2 text-gray-900">Start Your Health Journey</h1>
          <p className="text-gray-600">Tell us about yourself to get your personalized plan</p>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            {Array.from({ length: totalSections }, (_, i) => (
              <div key={i} className="flex items-center flex-1">
                <div
                  className={`w-full h-2 rounded-full transition-all duration-300 ${
                    i + 1 <= currentSection
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600'
                      : 'bg-gray-200'
                  }`}
                />
                {i < totalSections - 1 && <div className="w-2" />}
              </div>
            ))}
          </div>
          <div className="text-center text-sm text-gray-600">
            Step {currentSection} of {totalSections}
          </div>
        </div>

        {/* Form Card */}
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-8 space-y-8">
          {/* Section 1: Basic Profile */}
          {currentSection === 1 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <User className="w-6 h-6 text-emerald-600" />
                </div>
                <h2 className="text-2xl text-gray-900">Basic Profile</h2>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Full Name</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => updateField('fullName', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                  placeholder="Enter your full name"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 mb-2">Age</label>
                  <input
                    type="number"
                    value={formData.age}
                    onChange={(e) => updateField('age', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                    placeholder="25"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Country</label>
                  <select
                    value={formData.country}
                    onChange={(e) => updateField('country', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                  >
                    <option value="">Select</option>
                    <option value="us">United States</option>
                    <option value="uk">United Kingdom</option>
                    <option value="ca">Canada</option>
                    <option value="au">Australia</option>
                    <option value="in">India</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Gender</label>
                <div className="flex gap-4">
                  {['male', 'female', 'other'].map((gender) => (
                    <label key={gender} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="gender"
                        value={gender}
                        checked={formData.gender === gender}
                        onChange={(e) => updateField('gender', e.target.value)}
                        className="w-4 h-4 text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="text-gray-700 capitalize">{gender}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-gray-700 mb-2">Height (cm)</label>
                  <input
                    type="number"
                    value={formData.height}
                    onChange={(e) => updateField('height', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                    placeholder="170"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Weight (kg)</label>
                  <input
                    type="number"
                    value={formData.currentWeight}
                    onChange={(e) => updateField('currentWeight', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                    placeholder="70"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Target (kg)</label>
                  <input
                    type="number"
                    value={formData.targetWeight}
                    onChange={(e) => updateField('targetWeight', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                    placeholder="65"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Section 2: Health Information */}
          {currentSection === 2 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                  <Heart className="w-6 h-6 text-red-600" />
                </div>
                <h2 className="text-2xl text-gray-900">Health Information</h2>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Medical Conditions</label>
                <div className="grid grid-cols-2 gap-3">
                  {['Diabetes', 'Hypertension', 'Asthma', 'None'].map((condition) => (
                    <label key={condition} className="flex items-center gap-2 cursor-pointer p-3 border border-gray-200 rounded-xl hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={formData.medicalConditions.includes(condition)}
                        onChange={() => toggleArrayValue('medicalConditions', condition)}
                        className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                      />
                      <span className="text-gray-700">{condition}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Injuries / Limitations</label>
                <textarea
                  value={formData.injuries}
                  onChange={(e) => updateField('injuries', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50 resize-none"
                  rows={3}
                  placeholder="Any physical limitations or injuries we should know about?"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Allergies</label>
                <input
                  type="text"
                  value={formData.allergies}
                  onChange={(e) => updateField('allergies', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                  placeholder="E.g., peanuts, shellfish, dairy"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Dietary Restrictions</label>
                <div className="grid grid-cols-2 gap-3">
                  {['Vegan', 'Vegetarian', 'Lactose-Free', 'None'].map((diet) => (
                    <label key={diet} className="flex items-center gap-2 cursor-pointer p-3 border border-gray-200 rounded-xl hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={formData.dietaryRestrictions.includes(diet)}
                        onChange={() => toggleArrayValue('dietaryRestrictions', diet)}
                        className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                      />
                      <span className="text-gray-700">{diet}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Average Sleep Duration</label>
                <select
                  value={formData.sleepDuration}
                  onChange={(e) => updateField('sleepDuration', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                >
                  {Array.from({ length: 7 }, (_, i) => i + 4).map(hours => (
                    <option key={hours} value={hours}>{hours} hours</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Section 3: Fitness Profile */}
          {currentSection === 3 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Dumbbell className="w-6 h-6 text-blue-600" />
                </div>
                <h2 className="text-2xl text-gray-900">Fitness Profile</h2>
              </div>

              <div>
                <label className="block text-gray-700 mb-3">Your Primary Goal</label>
                <div className="grid grid-cols-2 gap-4">
                  {goalCards.map(({ id, label, icon: Icon }) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => updateField('goal', id)}
                      className={`p-6 rounded-xl border-2 transition-all ${
                        formData.goal === id
                          ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                    >
                      <Icon className={`w-8 h-8 mx-auto mb-3 ${
                        formData.goal === id ? 'text-emerald-600' : 'text-gray-400'
                      }`} />
                      <div className={`${
                        formData.goal === id ? 'text-emerald-700' : 'text-gray-700'
                      }`}>
                        {label}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Activity Level</label>
                <div className="space-y-2">
                  {[
                    { value: 'sedentary', label: 'Sedentary (little to no exercise)' },
                    { value: 'light', label: 'Light (1-2 days/week)' },
                    { value: 'moderate', label: 'Moderate (3-5 days/week)' },
                    { value: 'active', label: 'Active (6-7 days/week)' },
                  ].map(({ value, label }) => (
                    <label key={value} className="flex items-center gap-3 cursor-pointer p-3 border border-gray-200 rounded-xl hover:bg-gray-50">
                      <input
                        type="radio"
                        name="activityLevel"
                        value={value}
                        checked={formData.activityLevel === value}
                        onChange={(e) => updateField('activityLevel', e.target.value)}
                        className="w-4 h-4 text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="text-gray-700">{label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Workout Preferences</label>
                <div className="grid grid-cols-2 gap-3">
                  {['Gym', 'Home', 'Yoga', 'Running', 'Swimming', 'Cycling'].map((workout) => (
                    <label key={workout} className="flex items-center gap-2 cursor-pointer p-3 border border-gray-200 rounded-xl hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={formData.workoutPreference.includes(workout)}
                        onChange={() => toggleArrayValue('workoutPreference', workout)}
                        className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                      />
                      <span className="text-gray-700">{workout}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Section 4: Nutrition & Lifestyle */}
          {currentSection === 4 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <Apple className="w-6 h-6 text-orange-600" />
                </div>
                <h2 className="text-2xl text-gray-900">Nutrition & Lifestyle</h2>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 mb-2">Meals per Day</label>
                  <select
                    value={formData.mealsPerDay}
                    onChange={(e) => updateField('mealsPerDay', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                  >
                    {['1', '2', '3', '4', '5', '6+'].map(num => (
                      <option key={num} value={num}>{num} {num === '6+' ? '' : num === '1' ? 'meal' : 'meals'}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">Daily Water Intake</label>
                  <select
                    value={formData.waterIntake}
                    onChange={(e) => updateField('waterIntake', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                  >
                    {['<1L', '1-2L', '2-3L', '3-4L', '4L+'].map(amount => (
                      <option key={amount} value={amount}>{amount}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Food Preferences</label>
                <input
                  type="text"
                  value={formData.foodPreference}
                  onChange={(e) => updateField('foodPreference', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                  placeholder="E.g., Mediterranean, Asian, Low-carb"
                />
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-emerald-600" />
                    <span className="text-gray-700">Interested in Calorie Tracking</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.calorieTracking}
                      onChange={(e) => updateField('calorieTracking', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                  <div className="flex items-center gap-3">
                    <span className="text-gray-700">Smoking</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.smoking}
                      onChange={(e) => updateField('smoking', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                  <div className="flex items-center gap-3">
                    <span className="text-gray-700">Alcohol Consumption</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.alcohol}
                      onChange={(e) => updateField('alcohol', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Section 5: Personalization */}
          {currentSection === 5 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
                <h2 className="text-2xl text-gray-900">Personalization</h2>
              </div>

              <div>
                <label className="block text-gray-700 mb-3">
                  Workout Days per Week: <span className="text-emerald-600">{formData.workoutDays} days</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="7"
                  value={formData.workoutDays}
                  onChange={(e) => updateField('workoutDays', parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1</span>
                  <span>7</span>
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Time per Workout</label>
                <select
                  value={formData.timePerWorkout}
                  onChange={(e) => updateField('timePerWorkout', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
                >
                  {['15', '30', '45', '60', '90', '120+'].map(time => (
                    <option key={time} value={time}>{time} {time === '120+' ? '' : 'minutes'}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Main Challenges</label>
                <div className="grid grid-cols-2 gap-3">
                  {['Motivation', 'Time', 'Diet', 'Stress', 'Weight', 'Consistency'].map((challenge) => (
                    <label key={challenge} className="flex items-center gap-2 cursor-pointer p-3 border border-gray-200 rounded-xl hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={formData.mainChallenges.includes(challenge)}
                        onChange={() => toggleArrayValue('mainChallenges', challenge)}
                        className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                      />
                      <span className="text-gray-700">{challenge}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Section 6: Features Selection */}
          {currentSection === 6 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
                  <Award className="w-6 h-6 text-teal-600" />
                </div>
                <h2 className="text-2xl text-gray-900">Features Selection</h2>
              </div>

              <p className="text-gray-600">Choose the features you'd like to include in your plan:</p>

              <div className="space-y-4">
                {[
                  { key: 'customMealPlans', label: 'Custom Meal Plans', icon: Apple, desc: 'Personalized nutrition plans tailored to your goals' },
                  { key: 'workoutPlans', label: 'Workout Plans', icon: Dumbbell, desc: 'Structured exercise routines designed for you' },
                  { key: 'progressTracking', label: 'Progress Tracking', icon: Activity, desc: 'Monitor your journey with detailed analytics' },
                ].map(({ key, label, icon: Icon, desc }) => (
                  <div
                    key={key}
                    className={`p-5 border-2 rounded-xl transition-all cursor-pointer ${
                      formData[key as keyof typeof formData]
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => updateField(key, !formData[key as keyof typeof formData])}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                        formData[key as keyof typeof formData] ? 'bg-emerald-200' : 'bg-gray-100'
                      }`}>
                        <Icon className={`w-6 h-6 ${
                          formData[key as keyof typeof formData] ? 'text-emerald-700' : 'text-gray-500'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className={`${
                            formData[key as keyof typeof formData] ? 'text-emerald-700' : 'text-gray-900'
                          }`}>
                            {label}
                          </h3>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formData[key as keyof typeof formData] as boolean}
                              onChange={(e) => updateField(key, e.target.checked)}
                              onClick={(e) => e.stopPropagation()}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                          </label>
                        </div>
                        <p className="text-sm text-gray-600">{desc}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex gap-4 pt-6">
            {currentSection > 1 && (
              <button
                type="button"
                onClick={() => setCurrentSection(prev => prev - 1)}
                className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
              >
                Previous
              </button>
            )}
            {currentSection < totalSections ? (
              <button
                type="button"
                onClick={() => setCurrentSection(prev => prev + 1)}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl hover:from-emerald-600 hover:to-teal-700 transition-all shadow-lg"
              >
                Next
              </button>
            ) : (
              <button
                type="submit"
                className="flex-1 px-6 py-3 bg-gradient-to-r from-orange-500 to-amber-600 text-white rounded-xl hover:from-orange-600 hover:to-amber-700 transition-all shadow-lg"
              >
                Get My Personalized Plan
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
