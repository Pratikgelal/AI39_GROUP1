import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Shield, Database, Users, Lock, Bot, Cookie, Bell, Mail, ChevronRight, ArrowUp } from 'lucide-react';
import { ModernNavbar } from './ModernNavbar';
import { Footer } from './Footer';

interface PrivacyPolicyPageProps {
  onLoginClick: () => void;
  onRegisterClick: () => void;
  onBackHome?: () => void;
}

export function PrivacyPolicyPage({ onLoginClick, onRegisterClick, onBackHome }: PrivacyPolicyPageProps) {
  const [activeSection, setActiveSection] = useState('information');
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);

      // Update active section based on scroll position
      const sections = ['information', 'usage', 'protection', 'sharing', 'rights', 'ai', 'cookies', 'updates', 'contact'];
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 150 && rect.bottom >= 150) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  const sections = [
    { id: 'information', title: 'Information We Collect', icon: Database },
    { id: 'usage', title: 'How We Use Your Data', icon: Users },
    { id: 'protection', title: 'Data Protection', icon: Shield },
    { id: 'sharing', title: 'Data Sharing', icon: Lock },
    { id: 'rights', title: 'User Rights', icon: Bell },
    { id: 'ai', title: 'AI Usage', icon: Bot },
    { id: 'cookies', title: 'Cookies', icon: Cookie },
    { id: 'updates', title: 'Updates', icon: Bell },
    { id: 'contact', title: 'Contact Information', icon: Mail },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800">
      <ModernNavbar onLoginClick={onLoginClick} onRegisterClick={onRegisterClick} onHomeClick={onBackHome} />

      <div className="relative">
        {/* Hero Section */}
        <div className="pt-32 pb-16 px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-500/20 rounded-full mb-6">
              <Shield className="w-8 h-8 text-emerald-400" />
            </div>
            <h1 className="text-5xl md:text-6xl text-white mb-4">Privacy Policy</h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Your privacy and data security are important to us
            </p>
            <p className="text-sm text-gray-500 mt-4">Last updated: April 28, 2026</p>
          </motion.div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-6 pb-20">
          <div className="flex gap-12">
            {/* Sticky Side Navigation - Desktop Only */}
            <motion.aside
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="hidden lg:block w-72 flex-shrink-0"
            >
              <div className="sticky top-32">
                <h3 className="text-sm text-gray-500 mb-4 px-4">TABLE OF CONTENTS</h3>
                <nav className="space-y-1">
                  {sections.map(({ id, title, icon: Icon }) => (
                    <button
                      key={id}
                      onClick={() => scrollToSection(id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all ${
                        activeSection === id
                          ? 'bg-emerald-500/10 text-emerald-400 border-l-2 border-emerald-500'
                          : 'text-gray-400 hover:text-gray-300 hover:bg-white/5'
                      }`}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" />
                      <span className="text-sm">{title}</span>
                      {activeSection === id && <ChevronRight className="w-4 h-4 ml-auto" />}
                    </button>
                  ))}
                </nav>
              </div>
            </motion.aside>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex-1 max-w-3xl"
            >
              {/* Information We Collect */}
              <section id="information" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Database className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">Information We Collect</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>
                    VitaPulse collects various types of information to provide you with personalized health and fitness services:
                  </p>
                  <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-6 space-y-3">
                    <h4 className="text-white">Personal Information:</h4>
                    <ul className="space-y-2 ml-6">
                      <li className="list-disc">Name, email address, and contact details</li>
                      <li className="list-disc">Age, gender, height, and weight</li>
                      <li className="list-disc">Health goals and fitness preferences</li>
                    </ul>
                  </div>
                  <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-6 space-y-3">
                    <h4 className="text-white">Health Data:</h4>
                    <ul className="space-y-2 ml-6">
                      <li className="list-disc">Workout routines and activity levels</li>
                      <li className="list-disc">Sleep patterns and quality</li>
                      <li className="list-disc">Dietary preferences and restrictions</li>
                      <li className="list-disc">Medical conditions and allergies (optional)</li>
                    </ul>
                  </div>
                  <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-6 space-y-3">
                    <h4 className="text-white">Usage Data:</h4>
                    <ul className="space-y-2 ml-6">
                      <li className="list-disc">Device information and IP address</li>
                      <li className="list-disc">Browser type and operating system</li>
                      <li className="list-disc">Pages visited and time spent on the platform</li>
                    </ul>
                  </div>
                </div>
              </section>

              {/* How We Use Your Data */}
              <section id="usage" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">How We Use Your Data</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>We use your information to:</p>
                  <ul className="space-y-3 ml-6">
                    <li className="list-disc">Create and maintain your personalized fitness and health plans</li>
                    <li className="list-disc">Track your progress and provide insights</li>
                    <li className="list-disc">Send you important updates and notifications</li>
                    <li className="list-disc">Improve our services and user experience</li>
                    <li className="list-disc">Ensure platform security and prevent fraud</li>
                    <li className="list-disc">Comply with legal obligations</li>
                  </ul>
                  <div className="bg-emerald-500/10 border-l-4 border-emerald-500 p-6 rounded-r-xl mt-6">
                    <p className="text-emerald-300 flex items-start gap-3">
                      <Lock className="w-5 h-5 flex-shrink-0 mt-0.5" />
                      <span><strong>Important:</strong> We will never use your health data for advertising purposes or sell it to third parties.</span>
                    </p>
                  </div>
                </div>
              </section>

              {/* Data Protection */}
              <section id="protection" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Shield className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">Data Protection</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>
                    Your data security is our top priority. We implement industry-standard security measures to protect your information:
                  </p>
                  <div className="grid md:grid-cols-2 gap-4 mt-6">
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2 flex items-center gap-2">
                        <Lock className="w-5 h-5 text-emerald-400" />
                        Encryption
                      </h4>
                      <p className="text-sm text-gray-400">End-to-end encryption for all sensitive data transmission</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2 flex items-center gap-2">
                        <Shield className="w-5 h-5 text-emerald-400" />
                        Secure Storage
                      </h4>
                      <p className="text-sm text-gray-400">Data stored on secure, encrypted servers with regular backups</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2 flex items-center gap-2">
                        <Users className="w-5 h-5 text-emerald-400" />
                        Access Control
                      </h4>
                      <p className="text-sm text-gray-400">Strict access controls limiting who can view your data</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2 flex items-center gap-2">
                        <Bell className="w-5 h-5 text-emerald-400" />
                        Monitoring
                      </h4>
                      <p className="text-sm text-gray-400">24/7 security monitoring and threat detection</p>
                    </div>
                  </div>
                </div>
              </section>

              {/* Data Sharing */}
              <section id="sharing" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Lock className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">Data Sharing</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <div className="bg-emerald-500/10 border-l-4 border-emerald-500 p-6 rounded-r-xl">
                    <p className="text-emerald-300 flex items-start gap-3">
                      <Shield className="w-5 h-5 flex-shrink-0 mt-0.5" />
                      <span><strong>We do not sell your personal data.</strong> Your trust is paramount to us.</span>
                    </p>
                  </div>
                  <p className="mt-6">
                    We may share your information only in the following limited circumstances:
                  </p>
                  <ul className="space-y-3 ml-6">
                    <li className="list-disc"><strong>Service Providers:</strong> Trusted third-party services that help us operate (e.g., cloud hosting, analytics)</li>
                    <li className="list-disc"><strong>Legal Requirements:</strong> When required by law or to protect our legal rights</li>
                    <li className="list-disc"><strong>With Your Consent:</strong> When you explicitly authorize us to share your data</li>
                    <li className="list-disc"><strong>Aggregated Data:</strong> Anonymous, aggregated data for research and improvement purposes</li>
                  </ul>
                </div>
              </section>

              {/* User Rights */}
              <section id="rights" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Bell className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">Your Rights</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>You have the following rights regarding your personal data:</p>
                  <div className="space-y-3 mt-4">
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Access & Download</h4>
                      <p className="text-sm text-gray-400">Request a copy of all your personal data we hold</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Correction</h4>
                      <p className="text-sm text-gray-400">Update or correct any inaccurate information</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Deletion</h4>
                      <p className="text-sm text-gray-400">Request deletion of your account and associated data</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Data Portability</h4>
                      <p className="text-sm text-gray-400">Transfer your data to another service</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Opt-Out</h4>
                      <p className="text-sm text-gray-400">Unsubscribe from marketing communications at any time</p>
                    </div>
                  </div>
                </div>
              </section>

              {/* AI Usage */}
              <section id="ai" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Bot className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">AI Usage (Future Feature)</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>
                    VitaPulse plans to incorporate AI-powered features to enhance your experience:
                  </p>
                  <ul className="space-y-3 ml-6">
                    <li className="list-disc">Personalized workout and meal plan recommendations</li>
                    <li className="list-disc">Progress tracking and predictive analytics</li>
                    <li className="list-disc">AI chatbot for health and fitness guidance</li>
                    <li className="list-disc">Smart goal setting based on your patterns</li>
                  </ul>
                  <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-6 mt-4">
                    <p className="text-gray-300">
                      <strong className="text-white">Transparency:</strong> All AI features will be clearly labeled, and you'll have control over how AI uses your data. Your data will never be used to train third-party AI models without your explicit consent.
                    </p>
                  </div>
                </div>
              </section>

              {/* Cookies */}
              <section id="cookies" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Cookie className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">Cookies & Tracking</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>
                    We use cookies and similar technologies to improve your experience:
                  </p>
                  <div className="grid md:grid-cols-2 gap-4 mt-6">
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Essential Cookies</h4>
                      <p className="text-sm text-gray-400">Required for basic site functionality and security</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Performance Cookies</h4>
                      <p className="text-sm text-gray-400">Help us understand how you use our platform</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Functional Cookies</h4>
                      <p className="text-sm text-gray-400">Remember your preferences and settings</p>
                    </div>
                    <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-5">
                      <h4 className="text-white mb-2">Analytics Cookies</h4>
                      <p className="text-sm text-gray-400">Anonymous data to improve our services</p>
                    </div>
                  </div>
                  <p className="mt-4">
                    You can control cookie preferences through your browser settings.
                  </p>
                </div>
              </section>

              {/* Updates */}
              <section id="updates" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Bell className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">Policy Updates</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>
                    We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements.
                  </p>
                  <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-6">
                    <p className="text-gray-300">
                      <strong className="text-white">Notification:</strong> We will notify you of any material changes via email or a prominent notice on our platform at least 30 days before the changes take effect.
                    </p>
                  </div>
                  <p>
                    Continued use of VitaPulse after changes become effective constitutes acceptance of the updated policy.
                  </p>
                </div>
              </section>

              {/* Contact Information */}
              <section id="contact" className="mb-16 scroll-mt-32">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                    <Mail className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h2 className="text-3xl text-emerald-400">Contact Us</h2>
                </div>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>
                    If you have any questions or concerns about this Privacy Policy or how we handle your data, please contact us:
                  </p>
                  <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-6 space-y-4">
                    <div>
                      <h4 className="text-white mb-1">Email</h4>
                      <a href="mailto:privacy@vitapulse.com" className="text-emerald-400 hover:text-emerald-300 transition-colors">
                        privacy@vitapulse.com
                      </a>
                    </div>
                    <div>
                      <h4 className="text-white mb-1">Address</h4>
                      <p className="text-gray-400">
                        VitaPulse Inc.<br />
                        123 Wellness Avenue<br />
                        San Francisco, CA 94102<br />
                        United States
                      </p>
                    </div>
                    <div>
                      <h4 className="text-white mb-1">Response Time</h4>
                      <p className="text-gray-400">
                        We aim to respond to all privacy inquiries within 48 hours.
                      </p>
                    </div>
                  </div>
                </div>
              </section>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 w-12 h-12 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full shadow-lg flex items-center justify-center transition-colors z-40"
        >
          <ArrowUp className="w-5 h-5" />
        </motion.button>
      )}

      <Footer onPrivacyClick={onBackHome} />
    </div>
  );
}
