import { motion, AnimatePresence } from 'motion/react';
import { X, Mail, Phone, User, Target, Calendar, Ruler, Weight, Edit2, Check, Crown } from 'lucide-react';
import { useState } from 'react';

interface ProfilePanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProfilePanel({ isOpen, onClose }: ProfilePanelProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: 'John Doe',
    email: 'vitaapulsee@gmail.com',
    phone: '+977 9812345678',
    age: '28',
    height: '175',
    weight: '78',
    goal: 'muscle gain',
    plan: 'premium'
  });

  const handleSave = () => {
    setIsEditing(false);
  };

  const fitnessGoals = [
    { value: 'fat loss', label: 'Fat Loss' },
    { value: 'muscle gain', label: 'Muscle Gain' },
    { value: 'maintenance', label: 'Maintenance' }
  ];

  const premiumBenefits = [
    'AI-powered meal planning',
    'Personalized workout routines',
    'Advanced health analytics',
    'Priority support 24/7',
    'Unlimited health reports'
  ];

  const freeBenefits = [
    'Basic BMI calculator',
    'Weekly fitness tracking',
    'Standard health metrics',
    'Community support'
  ];

  const benefits = profileData.plan === 'premium' ? premiumBenefits : freeBenefits;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Profile Panel */}
          <motion.div
            initial={{ opacity: 0, x: 100, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 100, scale: 0.95 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="fixed top-6 right-6 z-50 w-full max-w-md rounded-2xl overflow-hidden"
            style={{
              backdropFilter: 'blur(24px)',
              border: '2px solid transparent',
              backgroundImage: 'linear-gradient(145deg, rgba(13,13,13,0.95), rgba(18,18,18,0.95)), linear-gradient(135deg, rgba(255,214,0,0.3), rgba(255,122,0,0.2))',
              backgroundOrigin: 'border-box',
              backgroundClip: 'padding-box, border-box',
              boxShadow: '0 20px 60px rgba(0,0,0,0.8), 0 0 80px rgba(255,214,0,0.15)',
              maxHeight: 'calc(100vh - 48px)',
              overflowY: 'auto'
            }}
          >
            {/* Header */}
            <div className="p-6 pb-4" style={{ borderBottom: '1px solid rgba(255,214,0,0.1)' }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white text-2xl font-bold">Profile</h2>
                <button
                  onClick={onClose}
                  className="w-10 h-10 rounded-full flex items-center justify-center transition-all hover:bg-white/10"
                >
                  <X className="w-5 h-5 text-white/70 hover:text-white" />
                </button>
              </div>

              {/* Profile Image + Name */}
              <div className="flex items-center gap-4 mb-4">
                <div className="relative">
                  <div
                    className="w-20 h-20 rounded-full flex items-center justify-center"
                    style={{
                      background: 'linear-gradient(135deg, #FFD600, #FF7A00)',
                      boxShadow: '0 0 30px rgba(255,214,0,0.4)'
                    }}
                  >
                    <User className="w-10 h-10 text-black" />
                  </div>
                  {profileData.plan === 'premium' && (
                    <div
                      className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center"
                      style={{ background: 'linear-gradient(135deg, #FFD600, #FF7A00)' }}
                    >
                      <Crown className="w-4 h-4 text-black" />
                    </div>
                  )}
                </div>
                <div>
                  {isEditing ? (
                    <input
                      type="text"
                      value={profileData.name}
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                      className="bg-white/5 text-white px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-[#FFD600] transition-all"
                      style={{ fontSize: '18px', fontWeight: 600 }}
                    />
                  ) : (
                    <h3 className="text-white text-xl font-bold">{profileData.name}</h3>
                  )}
                  <p
                    className="text-xs px-3 py-1 rounded-full inline-block mt-1"
                    style={{
                      background: profileData.plan === 'premium' ? 'linear-gradient(135deg, #FFD600, #FF7A00)' : 'rgba(255,255,255,0.1)',
                      color: profileData.plan === 'premium' ? '#000' : '#fff',
                      fontWeight: 600
                    }}
                  >
                    {profileData.plan === 'premium' ? '⭐ Premium' : 'Free Plan'}
                  </p>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              {/* Email */}
              <div className="flex items-center gap-3 p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,214,0,0.1)' }}>
                  <Mail className="w-5 h-5 text-[#FFD600]" />
                </div>
                <div className="flex-1">
                  <p className="text-white/50 text-xs mb-1">Email</p>
                  <p className="text-white text-sm font-medium">{profileData.email}</p>
                </div>
              </div>

              {/* Phone */}
              <div className="flex items-center gap-3 p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,214,0,0.1)' }}>
                  <Phone className="w-5 h-5 text-[#FFD600]" />
                </div>
                <div className="flex-1">
                  <p className="text-white/50 text-xs mb-1">Phone</p>
                  {isEditing ? (
                    <input
                      type="text"
                      value={profileData.phone}
                      onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                      className="bg-white/5 text-white px-2 py-1 rounded-lg outline-none border border-white/10 focus:border-[#FFD600] transition-all w-full text-sm"
                    />
                  ) : (
                    <p className="text-white text-sm font-medium">{profileData.phone}</p>
                  )}
                </div>
              </div>

              {/* Body Metrics */}
              <div className="grid grid-cols-3 gap-3">
                {/* Age */}
                <div className="p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div className="flex items-center justify-center mb-2">
                    <Calendar className="w-4 h-4 text-[#FFD600]" />
                  </div>
                  <p className="text-white/50 text-xs text-center mb-1">Age</p>
                  {isEditing ? (
                    <input
                      type="number"
                      value={profileData.age}
                      onChange={(e) => setProfileData({ ...profileData, age: e.target.value })}
                      className="bg-white/5 text-white px-2 py-1 rounded-lg outline-none border border-white/10 focus:border-[#FFD600] transition-all w-full text-center text-sm font-bold"
                    />
                  ) : (
                    <p className="text-white text-sm font-bold text-center">{profileData.age} yrs</p>
                  )}
                </div>

                {/* Height */}
                <div className="p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div className="flex items-center justify-center mb-2">
                    <Ruler className="w-4 h-4 text-[#FFD600]" />
                  </div>
                  <p className="text-white/50 text-xs text-center mb-1">Height</p>
                  {isEditing ? (
                    <input
                      type="number"
                      value={profileData.height}
                      onChange={(e) => setProfileData({ ...profileData, height: e.target.value })}
                      className="bg-white/5 text-white px-2 py-1 rounded-lg outline-none border border-white/10 focus:border-[#FFD600] transition-all w-full text-center text-sm font-bold"
                    />
                  ) : (
                    <p className="text-white text-sm font-bold text-center">{profileData.height} cm</p>
                  )}
                </div>

                {/* Weight */}
                <div className="p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div className="flex items-center justify-center mb-2">
                    <Weight className="w-4 h-4 text-[#FFD600]" />
                  </div>
                  <p className="text-white/50 text-xs text-center mb-1">Weight</p>
                  {isEditing ? (
                    <input
                      type="number"
                      value={profileData.weight}
                      onChange={(e) => setProfileData({ ...profileData, weight: e.target.value })}
                      className="bg-white/5 text-white px-2 py-1 rounded-lg outline-none border border-white/10 focus:border-[#FFD600] transition-all w-full text-center text-sm font-bold"
                    />
                  ) : (
                    <p className="text-white text-sm font-bold text-center">{profileData.weight} kg</p>
                  )}
                </div>
              </div>

              {/* Fitness Goal */}
              <div className="flex items-center gap-3 p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,214,0,0.1)' }}>
                  <Target className="w-5 h-5 text-[#FFD600]" />
                </div>
                <div className="flex-1">
                  <p className="text-white/50 text-xs mb-1">Fitness Goal</p>
                  {isEditing ? (
                    <select
                      value={profileData.goal}
                      onChange={(e) => setProfileData({ ...profileData, goal: e.target.value })}
                      className="bg-white/5 text-white px-2 py-1 rounded-lg outline-none border border-white/10 focus:border-[#FFD600] transition-all w-full text-sm font-medium"
                    >
                      {fitnessGoals.map((goal) => (
                        <option key={goal.value} value={goal.value} className="bg-[#1A1A1A]">
                          {goal.label}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <p className="text-white text-sm font-medium capitalize">{profileData.goal}</p>
                  )}
                </div>
              </div>

              {/* Plan Benefits */}
              <div className="mt-6">
                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <Crown className="w-4 h-4 text-[#FFD600]" />
                  Your Plan Benefits
                </h4>
                <div className="space-y-2">
                  {benefits.map((benefit, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-3 p-3 rounded-lg transition-all hover:bg-white/5"
                      style={{ background: 'rgba(255,255,255,0.02)' }}
                    >
                      <div className="w-5 h-5 rounded-full flex items-center justify-center mt-0.5" style={{ background: 'rgba(255,214,0,0.15)' }}>
                        <Check className="w-3 h-3 text-[#FFD600]" />
                      </div>
                      <p className="text-white/70 text-sm">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                {isEditing ? (
                  <>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setIsEditing(false)}
                      className="flex-1 py-3 rounded-xl font-semibold transition-all"
                      style={{
                        background: 'rgba(255,255,255,0.05)',
                        border: '1px solid rgba(255,255,255,0.1)',
                        color: '#fff'
                      }}
                    >
                      Cancel
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(255,214,0,0.4)' }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleSave}
                      className="flex-1 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
                      style={{ background: 'linear-gradient(135deg, #FFD600, #FF7A00)', color: '#000' }}
                    >
                      <Check className="w-5 h-5" />
                      Save Changes
                    </motion.button>
                  </>
                ) : (
                  <motion.button
                    whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(255,214,0,0.3)' }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setIsEditing(true)}
                    className="w-full py-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2"
                    style={{
                      border: '2px solid transparent',
                      backgroundImage: 'linear-gradient(#0D0D0D, #0D0D0D), linear-gradient(135deg, #FFD600, #FF7A00)',
                      backgroundOrigin: 'border-box',
                      backgroundClip: 'padding-box, border-box',
                      color: '#FFD600'
                    }}
                  >
                    <Edit2 className="w-5 h-5" />
                    Edit Profile
                  </motion.button>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
