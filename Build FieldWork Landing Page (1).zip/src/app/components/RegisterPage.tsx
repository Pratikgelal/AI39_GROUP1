import { useState } from 'react';
import { motion } from 'motion/react';
import {
  Mail, Lock, User, Eye, EyeOff, ArrowLeft,
  Activity, Dumbbell, Heart, Zap, Check,
  TrendingUp, BarChart3, Timer, Flame, Leaf,
  ChevronRight, Star
} from 'lucide-react';

interface RegisterPageProps {
  onBack?: () => void;
  onSignIn?: () => void;
}

/* ── Animated ECG Heartbeat Line ─────────────────────────────── */
function HeartbeatLine() {
  return (
    <div className="relative w-full h-16 overflow-hidden">
      <svg
        viewBox="0 0 900 60"
        className="w-full h-full"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="ecgGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#10b981" stopOpacity="0" />
            <stop offset="20%" stopColor="#10b981" stopOpacity="0.9" />
            <stop offset="55%" stopColor="#34d399" stopOpacity="1" />
            <stop offset="80%" stopColor="#f97316" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#f97316" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="ecgGlow" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#10b981" stopOpacity="0" />
            <stop offset="50%" stopColor="#10b981" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#f97316" stopOpacity="0" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        {/* Glow line behind */}
        <path
          d="M0,30 L80,30 L90,30 L94,25 L98,35 L100,30 L104,30 L108,3 L111,57 L115,30 L122,27 L130,20 L135,30 L150,30
             L260,30 L270,30 L274,25 L278,35 L280,30 L284,30 L288,3 L291,57 L295,30 L302,27 L310,20 L315,30 L330,30
             L440,30 L450,30 L454,25 L458,35 L460,30 L464,30 L468,3 L471,57 L475,30 L482,27 L490,20 L495,30 L510,30
             L620,30 L630,30 L634,25 L638,35 L640,30 L644,30 L648,3 L651,57 L655,30 L662,27 L670,20 L675,30 L690,30 L900,30"
          fill="none"
          stroke="url(#ecgGlow)"
          strokeWidth="6"
          filter="url(#glow)"
        />
        {/* Main crisp line */}
        <path
          d="M0,30 L80,30 L90,30 L94,25 L98,35 L100,30 L104,30 L108,3 L111,57 L115,30 L122,27 L130,20 L135,30 L150,30
             L260,30 L270,30 L274,25 L278,35 L280,30 L284,30 L288,3 L291,57 L295,30 L302,27 L310,20 L315,30 L330,30
             L440,30 L450,30 L454,25 L458,35 L460,30 L464,30 L468,3 L471,57 L475,30 L482,27 L490,20 L495,30 L510,30
             L620,30 L630,30 L634,25 L638,35 L640,30 L644,30 L648,3 L651,57 L655,30 L662,27 L670,20 L675,30 L690,30 L900,30"
          fill="none"
          stroke="url(#ecgGrad)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Animated scanning dot */}
        <circle r="3" fill="#10b981" filter="url(#glow)">
          <animateMotion dur="3s" repeatCount="indefinite">
            <mpath href="#ecgPath2" />
          </animateMotion>
        </circle>
        <path
          id="ecgPath2"
          d="M0,30 L80,30 L90,30 L94,25 L98,35 L100,30 L104,30 L108,3 L111,57 L115,30 L122,27 L130,20 L135,30 L150,30 L260,30 L270,30 L274,25 L278,35 L280,30 L284,30 L288,3 L291,57 L295,30 L302,27 L310,20 L315,30 L330,30 L440,30 L450,30 L454,25 L458,35 L460,30 L464,30 L468,3 L471,57 L475,30 L482,27 L490,20 L495,30 L510,30 L620,30 L630,30 L634,25 L638,35 L640,30 L644,30 L648,3 L651,57 L655,30 L662,27 L670,20 L675,30 L690,30 L900,30"
          fill="none"
          opacity="0"
        />
      </svg>
    </div>
  );
}

/* ── Password Strength ───────────────────────────────────────── */
function getPasswordStrength(pwd: string): number {
  let s = 0;
  if (pwd.length >= 8) s++;
  if (/[A-Z]/.test(pwd)) s++;
  if (/[0-9]/.test(pwd)) s++;
  if (/[^A-Za-z0-9]/.test(pwd)) s++;
  return s;
}
const strengthMeta = [
  { label: '', color: '#374151' },
  { label: 'Weak', color: '#ef4444' },
  { label: 'Fair', color: '#f97316' },
  { label: 'Good', color: '#eab308' },
  { label: 'Strong', color: '#10b981' },
];

/* ── Input Field ─────────────────────────────────────────────── */
function InputField({
  id, label, type = 'text', placeholder, icon: Icon, rightEl, onChange,
}: {
  id: string; label: string; type?: string; placeholder: string;
  icon: React.ElementType; rightEl?: React.ReactNode;
  onChange?: (v: string) => void;
}) {
  return (
    <div className="group">
      <label htmlFor={id} className="block text-xs font-semibold text-gray-400 mb-1.5 tracking-wide uppercase">
        {label}
      </label>
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-500/70 group-focus-within:text-emerald-400 transition-colors">
          <Icon className="w-4 h-4" />
        </div>
        <input
          id={id}
          type={type}
          placeholder={placeholder}
          onChange={e => onChange?.(e.target.value)}
          className="w-full pl-11 pr-12 py-3.5 rounded-xl text-white placeholder:text-gray-600 text-sm
                     outline-none transition-all duration-200
                     border border-white/[0.07] focus:border-emerald-500/50
                     focus:ring-1 focus:ring-emerald-500/30"
          style={{ background: 'rgba(255,255,255,0.04)' }}
        />
        {rightEl && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">{rightEl}</div>
        )}
      </div>
    </div>
  );
}

/* ── Main Register Page ──────────────────────────────────────── */
export function RegisterPage({ onBack, onSignIn }: RegisterPageProps) {
  const [showPwd, setShowPwd] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [password, setPassword] = useState('');

  const strength = getPasswordStrength(password);
  const strengthInfo = strengthMeta[strength] ?? strengthMeta[0];

  const features = [
    {
      icon: Dumbbell,
      label: 'Track Fitness',
      desc: 'AI-powered workout logs & PRs',
      color: '#10b981',
      glow: 'rgba(16,185,129,0.15)',
    },
    {
      icon: Leaf,
      label: 'Nutrition Plans',
      desc: 'Personalised meal & macro insights',
      color: '#f97316',
      glow: 'rgba(249,115,22,0.15)',
    },
    {
      icon: BarChart3,
      label: 'Wellness Monitor',
      desc: 'Real-time biometric dashboards',
      color: '#6366f1',
      glow: 'rgba(99,102,241,0.15)',
    },
  ];

  const metrics = [
    { icon: Heart, label: 'Heart Rate', value: '72', unit: 'BPM', color: '#ef4444', bg: 'rgba(239,68,68,0.08)', border: 'rgba(239,68,68,0.2)' },
    { icon: Flame, label: 'Calories', value: '2,340', unit: 'kcal', color: '#f97316', bg: 'rgba(249,115,22,0.08)', border: 'rgba(249,115,22,0.2)' },
    { icon: TrendingUp, label: 'Steps', value: '8,420', unit: 'today', color: '#10b981', bg: 'rgba(16,185,129,0.08)', border: 'rgba(16,185,129,0.2)' },
    { icon: Timer, label: 'Sleep', value: '7.5', unit: 'hrs', color: '#8b5cf6', bg: 'rgba(139,92,246,0.08)', border: 'rgba(139,92,246,0.2)' },
  ];

  const benefits = [
    'Personalised AI fitness coach',
    '500,000+ active wellness members',
    '300+ expert nutrition programmes',
  ];

  return (
    <div className="min-h-screen flex overflow-hidden" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>

      {/* ════════ LEFT VISUAL PANEL ════════ */}
      <div className="hidden lg:flex lg:w-[56%] relative flex-col overflow-hidden">

        {/* Background image + overlays */}
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1737697978452-08371ed4f405?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwZml0bmVzcyUyMGd5bSUyMG5lb24lMjBhZXN0aGV0aWN8ZW58MXx8fHwxNzc3MzY0Nzc4fDA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Fitness Background"
            className="w-full h-full object-cover"
          />
          {/* Primary overlay */}
          <div
            className="absolute inset-0"
            style={{
              background:
                'linear-gradient(135deg, rgba(2,6,12,0.97) 0%, rgba(4,34,18,0.92) 40%, rgba(60,20,5,0.65) 100%)',
            }}
          />
          {/* Emerald glow blob top-left */}
          <div
            className="absolute -top-20 -left-20 w-[500px] h-[500px] rounded-full blur-[100px] pointer-events-none"
            style={{ background: 'radial-gradient(circle, rgba(16,185,129,0.18) 0%, transparent 70%)' }}
          />
          {/* Orange glow blob bottom-right */}
          <div
            className="absolute -bottom-10 right-0 w-[380px] h-[380px] rounded-full blur-[90px] pointer-events-none"
            style={{ background: 'radial-gradient(circle, rgba(249,115,22,0.16) 0%, transparent 70%)' }}
          />
          {/* Indigo accent blob */}
          <div
            className="absolute top-1/2 right-1/4 w-[240px] h-[240px] rounded-full blur-[80px] pointer-events-none"
            style={{ background: 'radial-gradient(circle, rgba(99,102,241,0.10) 0%, transparent 70%)' }}
          />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col h-full px-14 py-12">

          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className="flex items-center gap-3"
          >
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center shadow-lg"
              style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', boxShadow: '0 0 20px rgba(16,185,129,0.4)' }}
            >
              <Activity className="w-6 h-6 text-white" />
            </div>
            <span
              className="text-white text-2xl tracking-tight"
              style={{ fontFamily: 'Playfair Display, Georgia, serif', fontWeight: 700 }}
            >
              VitaPulse
            </span>
          </motion.div>

          {/* Hero text block */}
          <motion.div
            className="mt-14"
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15 }}
          >
            <div className="flex items-center gap-2 mb-5">
              <span
                className="text-xs tracking-[0.22em] uppercase px-3 py-1 rounded-full border"
                style={{ color: '#10b981', borderColor: 'rgba(16,185,129,0.35)', background: 'rgba(16,185,129,0.08)' }}
              >
                ✦ Premium Health Platform
              </span>
            </div>

            <h1
              className="mb-5 leading-[1.08]"
              style={{
                fontFamily: 'Playfair Display, Georgia, serif',
                fontSize: '50px',
                fontWeight: 800,
                color: '#fff',
              }}
            >
              Transform Your<br />
              <span
                style={{
                  background: 'linear-gradient(90deg, #10b981 0%, #34d399 45%, #f97316 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}
              >
                Health Journey
              </span>
            </h1>

            <p className="text-gray-400 text-base leading-relaxed max-w-[420px]">
              Join over 500,000 members achieving peak wellness with AI-driven fitness plans,
              real-time biometrics, and expert nutrition guidance.
            </p>

            {/* Benefit list */}
            <ul className="mt-5 space-y-2">
              {benefits.map(b => (
                <li key={b} className="flex items-center gap-2.5 text-sm text-gray-300">
                  <span
                    className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.3)' }}
                  >
                    <Check className="w-3 h-3" style={{ color: '#10b981' }} />
                  </span>
                  {b}
                </li>
              ))}
            </ul>
          </motion.div>

          {/* ECG heartbeat line */}
          <motion.div
            className="mt-8 mb-6"
            initial={{ opacity: 0, scaleX: 0.6 }}
            animate={{ opacity: 1, scaleX: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
          >
            <HeartbeatLine />
          </motion.div>

          {/* Feature Cards */}
          <motion.div
            className="grid grid-cols-3 gap-3 mb-6"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.55 }}
          >
            {features.map((f, i) => (
              <motion.div
                key={f.label}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + i * 0.1 }}
                whileHover={{ y: -3, transition: { duration: 0.2 } }}
                className="rounded-2xl p-4 cursor-default"
                style={{
                  background: f.glow,
                  border: `1px solid ${f.color}25`,
                  backdropFilter: 'blur(12px)',
                }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center mb-3"
                  style={{ background: `${f.color}22`, border: `1px solid ${f.color}30` }}
                >
                  <f.icon className="w-4.5 h-4.5" style={{ color: f.color, width: 18, height: 18 }} />
                </div>
                <p className="text-white text-sm font-semibold mb-1">{f.label}</p>
                <p className="text-gray-500 text-xs leading-snug">{f.desc}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Health Metric Mockups */}
          <motion.div
            className="grid grid-cols-4 gap-2.5"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.85 }}
          >
            {metrics.map(m => (
              <div
                key={m.label}
                className="rounded-xl p-3 flex flex-col"
                style={{
                  background: m.bg,
                  border: `1px solid ${m.border}`,
                  backdropFilter: 'blur(10px)',
                }}
              >
                <div className="flex items-center gap-1.5 mb-2">
                  <m.icon style={{ color: m.color, width: 13, height: 13 }} />
                  <span className="text-gray-500 text-[10px] leading-none">{m.label}</span>
                </div>
                <span className="text-white text-sm font-bold">{m.value}</span>
                <span className="text-gray-600 text-[10px] mt-0.5">{m.unit}</span>
                {/* Mini bar indicator */}
                <div className="mt-2 h-[3px] rounded-full" style={{ background: 'rgba(255,255,255,0.06)' }}>
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: m.label === 'Heart Rate' ? '60%' : m.label === 'Calories' ? '78%' : m.label === 'Steps' ? '84%' : '75%',
                      background: m.color,
                      boxShadow: `0 0 6px ${m.color}80`,
                    }}
                  />
                </div>
              </div>
            ))}
          </motion.div>

          {/* Footer tagline */}
          <div className="mt-auto pt-8 text-gray-700 text-xs">
            © 2026 VitaPulse · Premium Health & Fitness Platform
          </div>
        </div>
      </div>

      {/* ════════ RIGHT FORM PANEL ════════ */}
      <div className="w-full lg:w-[44%] relative flex items-center justify-center overflow-y-auto min-h-screen">

        {/* Panel background */}
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(160deg, #05080f 0%, #060d08 55%, #0c0800 100%)' }}
        />

        {/* Faint grid texture */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)`,
            backgroundSize: '32px 32px',
          }}
        />

        {/* Mobile background */}
        <div className="absolute inset-0 lg:hidden">
          <img
            src="https://images.unsplash.com/photo-1775225218513-4395fef99aea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWxsbmVzcyUyMGhlYWx0aCUyMHJ1bm5lciUyMHNpbGhvdWV0dGUlMjBkYXJrfGVufDF8fHx8MTc3NzM2NDc3OHww&ixlib=rb-4.1.0&q=80&w=1080"
            alt=""
            className="w-full h-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-black/80" />
        </div>

        {/* Glow accent top right */}
        <div
          className="absolute top-0 right-0 w-64 h-64 rounded-full blur-[80px] pointer-events-none"
          style={{ background: 'radial-gradient(circle, rgba(16,185,129,0.07) 0%, transparent 70%)' }}
        />

        {/* Back button */}
        {onBack && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            onClick={onBack}
            className="absolute top-7 left-7 z-20 flex items-center gap-2 px-4 py-2 rounded-full text-sm text-gray-400 hover:text-white transition-colors"
            style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </motion.button>
        )}

        {/* Form card */}
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="relative z-10 w-full max-w-[430px] mx-auto px-8 py-10 my-16"
        >
          {/* Mobile logo */}
          <div className="flex items-center gap-2.5 mb-8 lg:hidden">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #10b981, #059669)' }}
            >
              <Activity className="w-5 h-5 text-white" />
            </div>
            <span
              className="text-white text-xl"
              style={{ fontFamily: 'Playfair Display, Georgia, serif', fontWeight: 700 }}
            >
              VitaPulse
            </span>
          </div>

          {/* Heading */}
          <div className="mb-7">
            <div className="flex items-center gap-2 mb-3">
              <span
                className="text-[10px] tracking-[0.22em] uppercase px-2.5 py-1 rounded-full"
                style={{ color: '#10b981', background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.25)' }}
              >
                Free Forever Plan
              </span>
            </div>
            <h2
              className="text-white mb-2"
              style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: '34px', fontWeight: 700, lineHeight: 1.15 }}
            >
              Join VitaPulse
            </h2>
            <p className="text-gray-500 text-sm leading-relaxed">
              Start Your Journey to Better Health Today
            </p>
          </div>

          {/* ── Registration Form ── */}
          <form className="space-y-4" onSubmit={e => e.preventDefault()}>

            {/* First + Last Name */}
            <div className="grid grid-cols-2 gap-3">
              <div className="group">
                <label htmlFor="firstName" className="block text-[10px] font-semibold text-gray-500 mb-1.5 tracking-widest uppercase">
                  First Name
                </label>
                <div className="relative">
                  <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-600 group-focus-within:text-emerald-400 transition-colors">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="firstName"
                    type="text"
                    placeholder="Alex"
                    className="w-full pl-10 pr-3 py-3.5 rounded-xl text-white text-sm placeholder:text-gray-600 outline-none transition-all border border-white/[0.07] focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/25"
                    style={{ background: 'rgba(255,255,255,0.04)' }}
                  />
                </div>
              </div>
              <div className="group">
                <label htmlFor="lastName" className="block text-[10px] font-semibold text-gray-500 mb-1.5 tracking-widest uppercase">
                  Last Name
                </label>
                <div className="relative">
                  <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-600 group-focus-within:text-emerald-400 transition-colors">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="lastName"
                    type="text"
                    placeholder="Rivera"
                    className="w-full pl-10 pr-3 py-3.5 rounded-xl text-white text-sm placeholder:text-gray-600 outline-none transition-all border border-white/[0.07] focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/25"
                    style={{ background: 'rgba(255,255,255,0.04)' }}
                  />
                </div>
              </div>
            </div>

            {/* Email */}
            <div className="group">
              <label htmlFor="email" className="block text-[10px] font-semibold text-gray-500 mb-1.5 tracking-widest uppercase">
                Email Address
              </label>
              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-600 group-focus-within:text-emerald-400 transition-colors">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  id="email"
                  type="email"
                  placeholder="alex@example.com"
                  className="w-full pl-10 pr-4 py-3.5 rounded-xl text-white text-sm placeholder:text-gray-600 outline-none transition-all border border-white/[0.07] focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/25"
                  style={{ background: 'rgba(255,255,255,0.04)' }}
                />
              </div>
            </div>

            {/* Password */}
            <div className="group">
              <label htmlFor="password" className="block text-[10px] font-semibold text-gray-500 mb-1.5 tracking-widest uppercase">
                Password
              </label>
              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-600 group-focus-within:text-emerald-400 transition-colors">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="password"
                  type={showPwd ? 'text' : 'password'}
                  placeholder="Create a strong password"
                  onChange={e => setPassword(e.target.value)}
                  className="w-full pl-10 pr-11 py-3.5 rounded-xl text-white text-sm placeholder:text-gray-600 outline-none transition-all border border-white/[0.07] focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/25"
                  style={{ background: 'rgba(255,255,255,0.04)' }}
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(!showPwd)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-300 transition-colors"
                >
                  {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {/* Strength indicator */}
              {password.length > 0 && (
                <div className="mt-2">
                  <div className="flex gap-1.5 mb-1">
                    {[1, 2, 3, 4].map(lvl => (
                      <div
                        key={lvl}
                        className="h-[3px] flex-1 rounded-full transition-all duration-300"
                        style={{
                          background: strength >= lvl ? strengthInfo.color : 'rgba(255,255,255,0.08)',
                          boxShadow: strength >= lvl ? `0 0 6px ${strengthInfo.color}60` : 'none',
                        }}
                      />
                    ))}
                  </div>
                  <p className="text-[10px]" style={{ color: strengthInfo.color }}>
                    {strengthInfo.label} password
                  </p>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div className="group">
              <label htmlFor="confirmPassword" className="block text-[10px] font-semibold text-gray-500 mb-1.5 tracking-widest uppercase">
                Confirm Password
              </label>
              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-600 group-focus-within:text-emerald-400 transition-colors">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="confirmPassword"
                  type={showConfirm ? 'text' : 'password'}
                  placeholder="Repeat your password"
                  className="w-full pl-10 pr-11 py-3.5 rounded-xl text-white text-sm placeholder:text-gray-600 outline-none transition-all border border-white/[0.07] focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/25"
                  style={{ background: 'rgba(255,255,255,0.04)' }}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-300 transition-colors"
                >
                  {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Terms checkbox */}
            <label className="flex items-start gap-3 cursor-pointer group mt-1">
              <div className="relative mt-0.5 flex-shrink-0">
                <input
                  type="checkbox"
                  checked={agreedToTerms}
                  onChange={e => setAgreedToTerms(e.target.checked)}
                  className="sr-only"
                />
                <div
                  className="w-5 h-5 rounded-md flex items-center justify-center transition-all duration-200"
                  style={{
                    background: agreedToTerms ? 'linear-gradient(135deg, #10b981, #059669)' : 'rgba(255,255,255,0.04)',
                    border: agreedToTerms ? '1px solid #10b981' : '1px solid rgba(255,255,255,0.12)',
                    boxShadow: agreedToTerms ? '0 0 10px rgba(16,185,129,0.4)' : 'none',
                  }}
                >
                  {agreedToTerms && <Check className="w-3 h-3 text-white" />}
                </div>
              </div>
              <span className="text-xs text-gray-500 leading-relaxed group-hover:text-gray-300 transition-colors">
                I agree to VitaPulse's{' '}
                <a href="#" className="text-emerald-400 hover:text-emerald-300 underline underline-offset-2">
                  Terms of Service
                </a>{' '}
                and{' '}
                <a href="#" className="text-emerald-400 hover:text-emerald-300 underline underline-offset-2">
                  Privacy Policy
                </a>
              </span>
            </label>

            {/* CTA Button */}
            <motion.button
              type="submit"
              whileHover={{ scale: 1.015 }}
              whileTap={{ scale: 0.985 }}
              className="relative w-full py-4 rounded-xl text-white font-semibold text-sm tracking-wide overflow-hidden group mt-2"
              style={{
                background: 'linear-gradient(135deg, #ff6b35 0%, #f7931e 50%, #ffb347 100%)',
                boxShadow: '0 4px 30px rgba(249,115,22,0.35)',
              }}
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                <Zap className="w-4 h-4" />
                Create Account
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-amber-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </motion.button>
          </form>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/[0.07]" />
            </div>
            <div className="relative flex justify-center">
              <span className="px-4 text-xs text-gray-600" style={{ background: '#05080f' }}>
                or continue with
              </span>
            </div>
          </div>

          {/* Social Login */}
          <div className="grid grid-cols-2 gap-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              className="flex items-center justify-center gap-2.5 py-3 rounded-xl text-sm text-gray-300 hover:text-white transition-all"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
              <span>Google</span>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              className="flex items-center justify-center gap-2.5 py-3 rounded-xl text-sm text-gray-300 hover:text-white transition-all"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
            >
              <svg className="w-4 h-4" fill="#1877F2" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              <span>Facebook</span>
            </motion.button>
          </div>

          {/* Sign In link */}
          <p className="text-center text-sm text-gray-600 mt-7">
            Already have an account?{' '}
            <button
              type="button"
              onClick={onSignIn}
              className="font-semibold transition-colors"
              style={{ color: '#f97316' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#fb923c')}
              onMouseLeave={e => (e.currentTarget.style.color = '#f97316')}
            >
              Sign In
            </button>
          </p>

          {/* Trust badges */}
          <div className="flex items-center justify-center gap-5 mt-8 pt-6" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
            {['SSL Secured', '500K+ Members', 'HIPAA Ready'].map(badge => (
              <div key={badge} className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#10b981', boxShadow: '0 0 4px #10b981' }} />
                <span className="text-[10px] text-gray-600">{badge}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
