import { motion } from 'motion/react';
import { Users, Code, Brain, Zap } from 'lucide-react';

const teamMembers = [
  {
    name: 'Yasif Ansari',
    role: 'Scrum Master',
    icon: Brain,
    gradient: 'from-purple-500 to-pink-500',
    delay: 0,
  },
  {
    name: 'Pratik Gelal',
    role: 'Developer',
    icon: Code,
    gradient: 'from-[#FFD600] to-[#FF7A00]',
    delay: 0.1,
  },
  {
    name: 'Shreeyaas Maharjan',
    role: 'Developer',
    icon: Code,
    gradient: 'from-blue-500 to-cyan-500',
    delay: 0.2,
  },
  {
    name: 'Princess Bhandari',
    role: 'Developer',
    icon: Code,
    gradient: 'from-pink-500 to-rose-500',
    delay: 0.3,
  },
  {
    name: 'Saksham Shrestha',
    role: 'Developer',
    icon: Code,
    gradient: 'from-orange-500 to-amber-500',
    delay: 0.4,
  },
  {
    name: 'Kritagya Shrestha',
    role: 'Developer',
    icon: Code,
    gradient: 'from-emerald-500 to-green-500',
    delay: 0.5,
  },
];

export function TeamSection() {
  return (
    <section className="relative py-32 px-6 bg-gradient-to-b from-black via-[#0D0D0D] to-black overflow-hidden" id="about">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-20 w-96 h-96 bg-[#FFD600]/30 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-[#FF7A00]/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1.5s' }} />
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:100px_100px]" />

      {/* Floating Particles */}
      <div className="absolute inset-0">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#FFD600]/40 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.6, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#FFD600] to-[#FF7A00] rounded-2xl mb-6 shadow-[0_0_30px_rgba(255,214,0,0.5)]">
            <Users className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-5xl md:text-6xl mb-4 text-white">
            Meet the <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD600] to-[#FF7A00]">Team</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Passionate individuals building the future of health and wellness
          </p>
        </motion.div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div
              key={member.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: member.delay }}
              whileHover={{
                y: -12,
                rotateY: 5,
                rotateX: 5,
              }}
              className="group relative"
              style={{
                transformStyle: 'preserve-3d',
                perspective: '1000px',
              }}
            >
              {/* Card */}
              <div className="relative bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-xl border border-white/10 rounded-3xl p-8 overflow-hidden transition-all duration-500 group-hover:border-[#FFD600]/50 group-hover:shadow-[0_0_40px_rgba(255,214,0,0.3)]">
                {/* Gradient Border Glow */}
                <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl bg-gradient-to-br ${member.gradient} blur-xl -z-10`} />

                {/* Avatar Circle with Icon */}
                <div className="relative mb-6 flex justify-center">
                  <div className={`relative w-32 h-32 rounded-full bg-gradient-to-br ${member.gradient} p-1 shadow-[0_0_30px_rgba(255,214,0,0.3)] group-hover:shadow-[0_0_50px_rgba(255,214,0,0.5)] transition-all duration-500`}>
                    <div className="w-full h-full rounded-full bg-black/90 backdrop-blur-xl flex items-center justify-center border border-white/10">
                      <member.icon className="w-12 h-12 text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]" />
                    </div>
                  </div>

                  {/* Orbital Ring Animation */}
                  <motion.div
                    className={`absolute inset-0 rounded-full border-2 border-dashed opacity-30`}
                    style={{
                      borderImage: `linear-gradient(to right, ${member.gradient}) 1`,
                    }}
                    animate={{
                      rotate: 360,
                    }}
                    transition={{
                      duration: 8,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                  />
                </div>

                {/* Info */}
                <div className="text-center relative z-10">
                  <h3 className="text-2xl text-white mb-2 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-[#FFD600] group-hover:to-[#FF7A00] transition-all duration-300">
                    {member.name}
                  </h3>
                  <p className="text-gray-400 mb-4">{member.role}</p>

                  {/* Decorative Line */}
                  <div className="flex items-center justify-center gap-2">
                    <div className="h-px w-12 bg-gradient-to-r from-transparent via-[#FFD600] to-transparent opacity-60" />
                    <Zap className="w-4 h-4 text-[#FFD600]" />
                    <div className="h-px w-12 bg-gradient-to-r from-transparent via-[#FFD600] to-transparent opacity-60" />
                  </div>
                </div>

                {/* Shimmer Effect on Hover */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -skew-x-12 transform translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-1000" />
                </div>
              </div>

              {/* Connection Lines (Subtle Network Effect) */}
              {index < teamMembers.length - 1 && (
                <svg className="absolute -right-4 top-1/2 w-8 h-2 hidden lg:block opacity-20">
                  <line
                    x1="0"
                    y1="1"
                    x2="32"
                    y2="1"
                    stroke={`url(#gradient-${index})`}
                    strokeWidth="2"
                    strokeDasharray="4 4"
                  />
                  <defs>
                    <linearGradient id={`gradient-${index}`}>
                      <stop offset="0%" stopColor="#FFD600" stopOpacity="0.5" />
                      <stop offset="100%" stopColor="#FFD600" stopOpacity="0.1" />
                    </linearGradient>
                  </defs>
                </svg>
              )}
            </motion.div>
          ))}
        </div>

        {/* Bottom Decorative Element */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <div className="inline-flex items-center gap-4 px-8 py-4 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full">
            <Zap className="w-5 h-5 text-[#FFD600]" />
            <span className="text-gray-300">Empowering wellness, one line of code at a time</span>
            <Zap className="w-5 h-5 text-[#FF7A00]" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
