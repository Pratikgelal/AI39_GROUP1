import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard, Heart, FileText, Users, Bot, Settings,
  Search, Bell, Flame, Footprints, Activity, Droplets,
  Moon, TrendingUp, Target, Zap, MessageSquare, Brain,
  Mic, Image, Pill, ShieldAlert, AlertOctagon, FolderOpen,
  MapPin, Navigation, Radio, Wallet, ChevronRight,
  ArrowRight, Upload, Cpu, Star, RefreshCw, Plus, Check,
  Camera, Send, Clock, Dumbbell, HeartPulse, Scan, Leaf,
  BookOpen, Phone, Shield, AlertTriangle, BarChart2,
  User, LogOut, ChevronDown, Info, Smile, Eye, Timer,
  Download, Calendar, Map, Stethoscope, UserPlus, Sparkles,
  Thermometer, Award, Wind, Coffee, CheckCircle, Circle,
  TrendingDown, BatteryMedium, Siren
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, LineChart, Line, RadialBarChart,
  RadialBar, PieChart, Pie, Cell
} from 'recharts';

// ─── Color tokens ────────────────────────────────────────────────────────────
const C = {
  teal: '#00C897',
  orange: '#FF7A00',
  blue: '#4A9EFF',
  purple: '#8B5CF6',
  pink: '#EC4899',
  yellow: '#F59E0B',
  red: '#EF4444',
  green: '#10B981',
};

// ─── Sample Data ─────────────────────────────────────────────────────────────
const sleepData = [
  { day: 'Mon', hours: 7.5 }, { day: 'Tue', hours: 6.0 },
  { day: 'Wed', hours: 8.2 }, { day: 'Thu', hours: 6.5 },
  { day: 'Fri', hours: 7.8 }, { day: 'Sat', hours: 9.1 },
  { day: 'Sun', hours: 5.5 },
];
const stepsData = [
  { time: '6am', steps: 300 }, { time: '8am', steps: 1800 },
  { time: '10am', steps: 3600 }, { time: '12pm', steps: 5200 },
  { time: '2pm', steps: 6800 }, { time: '4pm', steps: 7900 },
  { time: '6pm', steps: 8432 }, { time: '8pm', steps: 8700 },
];
const weeklyData = [
  { day: 'Mon', steps: 9200, cal: 2100 }, { day: 'Tue', steps: 7400, cal: 1900 },
  { day: 'Wed', steps: 11000, cal: 2400 }, { day: 'Thu', steps: 8432, cal: 2050 },
  { day: 'Fri', steps: 9800, cal: 2200 }, { day: 'Sat', steps: 6200, cal: 1800 },
  { day: 'Sun', steps: 5100, cal: 1700 },
];
const expenseData = [
  { month: 'Jan', amount: 320 }, { month: 'Feb', amount: 410 },
  { month: 'Mar', amount: 380 }, { month: 'Apr', amount: 460 },
  { month: 'May', amount: 290 }, { month: 'Jun', amount: 505 },
];
const pieData = [
  { name: 'Medicine', value: 120, color: C.teal },
  { name: 'Gym', value: 80, color: C.blue },
  { name: 'Supps', value: 65, color: C.yellow },
  { name: 'Doctor', value: 150, color: C.red },
  { name: 'Other', value: 45, color: C.purple },
];
const goals = [
  { id: 1, label: 'Walk 10,000 steps/day', progress: 84, color: C.teal, icon: Footprints },
  { id: 2, label: 'Sleep 8 hours/night', progress: 68, color: C.blue, icon: Moon },
  { id: 3, label: 'Drink 2.5L water/day', progress: 72, color: '#38BDF8', icon: Droplets },
  { id: 4, label: 'Workout 5× per week', progress: 60, color: C.yellow, icon: Dumbbell },
];
const familyMembers = [
  { id: 1, name: 'You', age: 28, status: 'Healthy', color: C.teal, emoji: '🧑' },
  { id: 2, name: 'Sarah', age: 26, status: 'Check-up due', color: C.yellow, emoji: '👩' },
  { id: 3, name: 'Dad', age: 56, status: 'Hypertension', color: C.red, emoji: '👴' },
  { id: 4, name: 'Mom', age: 52, status: 'Healthy', color: C.green, emoji: '👩‍🦳' },
];
const nearbyPlaces = [
  { name: 'City Medical Center', type: 'Hospital', dist: '0.8 km', open: true, rating: 4.5 },
  { name: 'LifeCare Clinic', type: 'Clinic', dist: '1.2 km', open: true, rating: 4.2 },
  { name: 'Apollo Pharmacy', type: 'Pharmacy', dist: '0.3 km', open: true, rating: 4.7 },
];
const specialists = [
  { label: 'Cardiologist', icon: HeartPulse, color: C.red, count: 12 },
  { label: 'Neurologist', icon: Brain, color: C.purple, count: 8 },
  { label: 'Dermatologist', icon: Scan, color: C.yellow, count: 15 },
  { label: 'Dietitian', icon: Leaf, color: C.green, count: 20 },
  { label: 'Psychiatrist', icon: Smile, color: C.pink, count: 7 },
  { label: 'Orthopedist', icon: Activity, color: C.blue, count: 9 },
];
const timelineEvents = [
  { time: '6:30 AM', event: 'Woke up', icon: '🌅', color: C.yellow },
  { time: '7:00 AM', event: 'Morning walk — 2.1 km', icon: '🚶', color: C.teal },
  { time: '8:30 AM', event: 'Breakfast + Supplements', icon: '🥗', color: C.blue },
  { time: '10:15 AM', event: 'Heart rate spike (92 bpm)', icon: '❤️', color: C.red },
  { time: '12:30 PM', event: 'Lunch + Water (0.5L)', icon: '🍱', color: C.blue },
  { time: '3:00 PM', event: 'Gym session — 45 min', icon: '🏋️', color: C.yellow },
  { time: '6:00 PM', event: 'Evening steps target met', icon: '🎯', color: C.teal },
];
const outbreaks = [
  { disease: 'Seasonal Flu', level: 'Medium', area: '5 km', cases: 234, color: C.yellow },
  { disease: 'Dengue', level: 'High', area: '8 km', cases: 67, color: C.red },
  { disease: 'COVID-19', level: 'Low', area: '10 km', cases: 12, color: C.green },
];
const riskFactors = [
  { factor: 'Cardiovascular', risk: 18, color: C.red, level: 'Low' },
  { factor: 'Diabetes', risk: 24, color: C.yellow, level: 'Low-Med' },
  { factor: 'Hypertension', risk: 31, color: C.orange, level: 'Medium' },
  { factor: 'Obesity', risk: 12, color: C.green, level: 'Low' },
];
const motivationQuotes = [
  { quote: 'Every step today is an investment in your future health. Keep moving forward!', author: 'Dr. Sarah Johnson' },
  { quote: 'Your body is your most priceless possession. Take care of it with love.', author: 'VitaPulse AI' },
  { quote: 'Small consistent actions create massive transformations. You\'re doing great!', author: 'Wellness Coach' },
];
const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'health', label: 'Health', icon: Heart },
  { id: 'reports', label: 'Reports', icon: FileText },
  { id: 'family', label: 'Family', icon: Users },
  { id: 'ai', label: 'AI Assistant', icon: Bot },
  { id: 'settings', label: 'Settings', icon: Settings },
];

// ─── Shared styled components ────────────────────────────────────────────────
const BG = 'linear-gradient(160deg,#071623 0%,#080F1E 50%,#060B14 100%)';
const CARD = 'rgba(255,255,255,0.055)';
const BORDER = '1px solid rgba(255,255,255,0.08)';

function Card({
  children, className = '', onClick, glow, style = {}
}: {
  children: React.ReactNode; className?: string;
  onClick?: () => void; glow?: string; style?: React.CSSProperties;
}) {
  return (
    <motion.div
      whileHover={onClick ? { y: -3, scale: 1.01 } : { y: -1 }}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      onClick={onClick}
      className={`rounded-2xl p-4 relative overflow-hidden ${onClick ? 'cursor-pointer' : ''} ${className}`}
      style={{
        background: CARD,
        border: BORDER,
        backdropFilter: 'blur(16px)',
        boxShadow: glow ? `0 0 30px ${glow}22` : '0 4px 24px rgba(0,0,0,0.3)',
        ...style
      }}
    >
      {children}
    </motion.div>
  );
}

function SectionTitle({ title, subtitle, action }: { title: string; subtitle?: string; action?: string }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div>
        <h2 className="text-white" style={{ fontSize: 18, fontWeight: 700 }}>{title}</h2>
        {subtitle && <p className="text-white/40 mt-0.5" style={{ fontSize: 12 }}>{subtitle}</p>}
      </div>
      {action && (
        <button className="flex items-center gap-1 text-sm px-3 py-1.5 rounded-lg transition-all hover:opacity-80"
          style={{ background: 'rgba(0,200,151,0.12)', color: C.teal, border: '1px solid rgba(0,200,151,0.25)' }}>
          {action} <ChevronRight size={14} />
        </button>
      )}
    </div>
  );
}

function Btn({ children, color = C.teal, className = '', onClick }: {
  children: React.ReactNode; color?: string; className?: string; onClick?: () => void;
}) {
  return (
    <motion.button
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${className}`}
      style={{ background: `${color}22`, color, border: `1px solid ${color}44` }}
    >
      {children}
    </motion.button>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export function VitaPulseDashboard({ onBack }: { onBack: () => void }) {
  const [activeNav, setActiveNav] = useState('health');
  const [quoteIdx, setQuoteIdx] = useState(0);
  const [chatInput, setChatInput] = useState('');
  const [activeCards, setActiveCards] = useState<Set<string>>(new Set());

  const toggleCard = (id: string) =>
    setActiveCards(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: BG, fontFamily: 'Inter, system-ui, sans-serif' }}>

      {/* ── Sidebar ── */}
      <aside className="flex flex-col shrink-0 h-full overflow-y-auto"
        style={{ width: 240, background: 'rgba(5,10,22,0.95)', borderRight: '1px solid rgba(255,255,255,0.07)', backdropFilter: 'blur(24px)' }}>

        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-6">
          <div className="flex items-center justify-center w-9 h-9 rounded-xl"
            style={{ background: 'linear-gradient(135deg, #00C897, #00A07A)' }}>
            <HeartPulse size={18} className="text-white" />
          </div>
          <div>
            <span className="text-white font-bold" style={{ fontSize: 16 }}>Vita</span>
            <span style={{ color: C.teal, fontWeight: 700, fontSize: 16 }}>Pulse</span>
          </div>
        </div>

        <div className="px-3 mb-2">
          <p className="text-white/25 px-3 mb-2" style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Main Menu
          </p>
          <nav className="flex flex-col gap-1">
            {navItems.map(item => {
              const active = activeNav === item.id;
              return (
                <motion.button
                  key={item.id}
                  whileHover={{ x: 2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setActiveNav(item.id)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all w-full"
                  style={{
                    background: active ? `${C.teal}18` : 'transparent',
                    color: active ? C.teal : 'rgba(255,255,255,0.5)',
                    border: active ? `1px solid ${C.teal}30` : '1px solid transparent',
                  }}
                >
                  <item.icon size={17} />
                  <span style={{ fontSize: 14, fontWeight: active ? 600 : 400 }}>{item.label}</span>
                  {active && (
                    <div className="ml-auto w-1.5 h-1.5 rounded-full" style={{ background: C.teal }} />
                  )}
                </motion.button>
              );
            })}
          </nav>
        </div>

        <div className="mt-auto px-4 py-5">
          <div className="rounded-xl p-3 mb-4" style={{ background: `${C.teal}12`, border: `1px solid ${C.teal}25` }}>
            <div className="flex items-center gap-2 mb-2">
              <Zap size={14} style={{ color: C.teal }} />
              <span className="text-white/70" style={{ fontSize: 11, fontWeight: 600 }}>Health Score</span>
            </div>
            <div className="text-white" style={{ fontSize: 28, fontWeight: 800, lineHeight: 1 }}>87<span style={{ fontSize: 14, color: C.teal }}>/100</span></div>
            <div className="mt-2 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.1)' }}>
              <div className="h-full rounded-full" style={{ width: '87%', background: `linear-gradient(90deg, ${C.teal}, #00F5BC)` }} />
            </div>
            <p className="mt-1 text-white/40" style={{ fontSize: 10 }}>Excellent — keep it up!</p>
          </div>

          <div className="flex items-center gap-3 px-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-lg"
              style={{ background: 'linear-gradient(135deg,#4A9EFF,#7B5EFF)' }}>
              <span style={{ fontSize: 16 }}>🧑</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white" style={{ fontSize: 13, fontWeight: 600 }}>Alex Morgan</p>
              <p className="text-white/40 truncate" style={{ fontSize: 11 }}>Premium Plan</p>
            </div>
            <motion.button whileTap={{ scale: 0.9 }} onClick={onBack}
              className="text-white/30 hover:text-white/70 transition-colors">
              <LogOut size={15} />
            </motion.button>
          </div>
        </div>
      </aside>

      {/* ── Main Content ── */}
      <div className="flex flex-col flex-1 min-w-0 h-full overflow-hidden">

        {/* ── Top Bar ── */}
        <header className="flex items-center gap-4 px-8 py-4 shrink-0"
          style={{ background: 'rgba(6,9,18,0.9)', borderBottom: '1px solid rgba(255,255,255,0.06)', backdropFilter: 'blur(20px)' }}>
          <div className="flex-1 max-w-md relative">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/25" />
            <input
              placeholder="Search symptoms, medicines, reports…"
              className="w-full py-2.5 pl-10 pr-4 rounded-xl outline-none text-white placeholder-white/25 transition-all focus:ring-1"
              style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, '--tw-ring-color': C.teal } as React.CSSProperties}
            />
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
              className="relative w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.06)', border: BORDER }}>
              <Bell size={17} className="text-white/70" />
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full" style={{ background: C.red }} />
            </motion.button>
            <motion.button whileHover={{ scale: 1.05 }}
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.06)', border: BORDER }}>
              <Settings size={17} className="text-white/70" />
            </motion.button>
            <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl cursor-pointer hover:bg-white/5 transition-colors">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-base"
                style={{ background: 'linear-gradient(135deg,#4A9EFF,#7B5EFF)' }}>🧑</div>
              <div className="hidden lg:block">
                <p className="text-white" style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.2 }}>Alex Morgan</p>
                <p style={{ fontSize: 11, color: C.teal }}>Premium</p>
              </div>
              <ChevronDown size={13} className="text-white/40 hidden lg:block" />
            </div>
          </div>
        </header>

        {/* ── Scrollable Content ── */}
        <main className="flex-1 overflow-y-auto px-8 py-6">
          <div style={{ maxWidth: 1280 }}>

            {/* Page Title */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-white" style={{ fontSize: 24, fontWeight: 800 }}>Health Overview</h1>
                <p className="text-white/40 mt-0.5" style={{ fontSize: 13 }}>Thursday, April 30, 2026 · Good morning, Alex 👋</p>
              </div>
              <Btn color={C.teal} onClick={() => {}}>
                <Plus size={13} /> Add Entry
              </Btn>
            </div>

            {/* ── Top 4 Metric Cards ── */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              {[
                { label: 'Calories', value: '1,842', unit: 'kcal', goal: '2,200', pct: 84, icon: Flame, color: C.orange, trend: '+3.2%' },
                { label: 'Steps', value: '8,432', unit: 'steps', goal: '10,000', pct: 84, icon: Footprints, color: C.teal, trend: '+12.4%' },
                { label: 'Heart Rate', value: '72', unit: 'bpm', goal: 'Normal', pct: 72, icon: HeartPulse, color: C.red, trend: '-1 bpm' },
                { label: 'Water Intake', value: '1.8', unit: 'litres', goal: '2.5L', pct: 72, icon: Droplets, color: C.blue, trend: '+0.3L' },
              ].map((m, i) => (
                <Card key={i} glow={m.color} onClick={() => toggleCard(`metric-${i}`)}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: `${m.color}20` }}>
                      <m.icon size={20} style={{ color: m.color }} />
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full"
                      style={{ background: `${C.teal}18`, color: C.teal }}>
                      {m.trend}
                    </span>
                  </div>
                  <p className="text-white" style={{ fontSize: 28, fontWeight: 800, lineHeight: 1 }}>
                    {m.value}<span className="text-white/40" style={{ fontSize: 13, fontWeight: 400 }}> {m.unit}</span>
                  </p>
                  <p className="text-white/40 mt-1 mb-3" style={{ fontSize: 12 }}>{m.label} · Goal: {m.goal}</p>
                  <div className="h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <motion.div
                      initial={{ width: '0%' }}
                      animate={{ width: `${m.pct}%` }}
                      transition={{ duration: 1, delay: i * 0.15 }}
                      className="h-full rounded-full"
                      style={{ background: `linear-gradient(90deg, ${m.color}, ${m.color}aa)` }}
                    />
                  </div>
                </Card>
              ))}
            </div>

            {/* ── AI Insight Banner ── */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl p-4 mb-6 flex items-center gap-4 cursor-pointer hover:scale-[1.005] transition-transform"
              style={{
                background: 'linear-gradient(135deg, rgba(0,200,151,0.12) 0%, rgba(74,158,255,0.08) 100%)',
                border: `1px solid ${C.teal}30`,
                boxShadow: `0 0 40px ${C.teal}15`
              }}
            >
              <div className="relative flex-shrink-0">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: `linear-gradient(135deg, ${C.teal}, #00A07A)` }}>
                  <Sparkles size={22} className="text-white" />
                </div>
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full animate-pulse"
                  style={{ background: C.teal, boxShadow: `0 0 8px ${C.teal}` }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span style={{ fontSize: 11, color: C.teal, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                    AI Health Insight
                  </span>
                </div>
                <p className="text-white" style={{ fontSize: 15, fontWeight: 500 }}>
                  You slept <strong style={{ color: C.orange }}>1.5 hours less</strong> than your 8-hour goal last night. Try sleeping earlier today to recover your sleep debt.
                </p>
                <p className="text-white/40 mt-0.5" style={{ fontSize: 12 }}>Powered by VitaPulse AI · Updated 2 minutes ago</p>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Btn color={C.teal}>View Plan <ArrowRight size={12} /></Btn>
                <Btn color={C.orange}>Dismiss</Btn>
              </div>
            </motion.div>

            {/* ══════════════════════════════════════════════════
                SECTION 1 — Daily Health
            ══════════════════════════════════════════════════ */}
            <SectionTitle title="Daily Health" subtitle="Today's key health metrics and activity" action="Full Report" />
            <div className="grid grid-cols-3 gap-4 mb-8">

              {/* Sleep Quality */}
              <Card glow={C.blue}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Moon size={16} style={{ color: C.blue }} />
                    <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Sleep Quality</span>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: `${C.blue}20`, color: C.blue }}>
                    Last 7 days
                  </span>
                </div>
                <div className="flex items-end gap-4 mb-3">
                  <div>
                    <p className="text-white" style={{ fontSize: 32, fontWeight: 800, lineHeight: 1 }}>6.5<span className="text-white/40" style={{ fontSize: 14 }}>hrs</span></p>
                    <p className="text-white/40" style={{ fontSize: 12 }}>Last night</p>
                  </div>
                  <div className="pb-1">
                    <div className="flex items-center gap-1.5 mb-1">
                      <div className="w-2 h-2 rounded-full" style={{ background: C.teal }} />
                      <span className="text-white/50" style={{ fontSize: 11 }}>Score: 72/100</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full" style={{ background: C.yellow }} />
                      <span className="text-white/50" style={{ fontSize: 11 }}>REM: 1.8 hrs</span>
                    </div>
                  </div>
                </div>
                <div style={{ height: 70 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={sleepData}>
                      <defs>
                        <linearGradient id="sleepGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={C.blue} stopOpacity={0.3} />
                          <stop offset="95%" stopColor={C.blue} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <Area type="monotone" dataKey="hours" stroke={C.blue} fill="url(#sleepGrad)" strokeWidth={2} dot={false} />
                      <XAxis dataKey="day" tick={{ fill: '#ffffff30', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ background: '#0D1B2A', border: 'none', borderRadius: 8, fontSize: 11, color: '#fff' }}
                        formatter={(v: number) => [`${v}h`, 'Sleep']}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex gap-2 mt-3">
                  <Btn color={C.blue}>Set Goal <Target size={11} /></Btn>
                  <Btn color={C.teal}>History <ArrowRight size={11} /></Btn>
                </div>
              </Card>

              {/* Health Timeline */}
              <Card glow={C.teal}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Clock size={16} style={{ color: C.teal }} />
                    <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Health Timeline</span>
                  </div>
                  <span className="text-xs" style={{ color: C.teal }}>Today</span>
                </div>
                <div className="space-y-2 overflow-y-auto" style={{ maxHeight: 200 }}>
                  {timelineEvents.map((e, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-3"
                    >
                      <div className="flex flex-col items-center" style={{ width: 16 }}>
                        <div className="w-2 h-2 rounded-full" style={{ background: e.color, boxShadow: `0 0 6px ${e.color}` }} />
                        {i < timelineEvents.length - 1 && <div className="w-px flex-1 mt-1" style={{ background: 'rgba(255,255,255,0.06)', height: 16 }} />}
                      </div>
                      <div className="flex items-center gap-2 flex-1 py-1 px-2 rounded-lg hover:bg-white/5 cursor-pointer transition-colors">
                        <span style={{ fontSize: 14 }}>{e.icon}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-white/80 truncate" style={{ fontSize: 11, fontWeight: 500 }}>{e.event}</p>
                        </div>
                        <span className="text-white/30 flex-shrink-0" style={{ fontSize: 10 }}>{e.time}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <Btn color={C.teal} className="mt-3 w-full justify-center">View Full Timeline</Btn>
              </Card>

              {/* Weekly Report */}
              <Card glow={C.orange}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <BarChart2 size={16} style={{ color: C.orange }} />
                    <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Weekly Report</span>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: `${C.orange}20`, color: C.orange }}>
                    Apr 24–30
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  {[
                    { label: 'Avg Steps', value: '8,161', delta: '+5%', c: C.teal },
                    { label: 'Avg Sleep', value: '7.3h', delta: '-0.2h', c: C.blue },
                    { label: 'Workouts', value: '4 / 5', delta: '80%', c: C.orange },
                    { label: 'Water', value: '1.9L', delta: '-0.6L', c: '#38BDF8' },
                  ].map((s, i) => (
                    <div key={i} className="rounded-xl p-2.5" style={{ background: 'rgba(255,255,255,0.04)' }}>
                      <p className="text-white/40" style={{ fontSize: 10 }}>{s.label}</p>
                      <p className="text-white" style={{ fontSize: 16, fontWeight: 700, lineHeight: 1.3 }}>{s.value}</p>
                      <p style={{ fontSize: 10, color: s.c }}>{s.delta}</p>
                    </div>
                  ))}
                </div>
                <div style={{ height: 70 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklyData}>
                      <Bar dataKey="steps" fill={C.orange} opacity={0.7} radius={[3, 3, 0, 0]} />
                      <XAxis dataKey="day" tick={{ fill: '#ffffff30', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ background: '#0D1B2A', border: 'none', borderRadius: 8, fontSize: 11, color: '#fff' }}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <Btn color={C.orange} className="mt-3 w-full justify-center">
                  <Download size={12} /> Download Full Report
                </Btn>
              </Card>
            </div>

            {/* ══════════════════════════════════════════════════
                SECTION 2 — Goals & Planning
            ══════════════════════════════════════════════════ */}
            <SectionTitle title="Goals & Planning" subtitle="Track your personal health targets" action="Manage Goals" />
            <div className="grid grid-cols-3 gap-4 mb-8">

              {/* Goal Setting */}
              <Card glow={C.teal}>
                <div className="flex items-center gap-2 mb-4">
                  <Target size={16} style={{ color: C.teal }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Goal Setting System</span>
                </div>
                <div className="space-y-3">
                  {goals.map(g => (
                    <div key={g.id}>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <g.icon size={13} style={{ color: g.color }} />
                          <span className="text-white/70" style={{ fontSize: 11 }}>{g.label}</span>
                        </div>
                        <span style={{ fontSize: 12, color: g.color, fontWeight: 700 }}>{g.progress}%</span>
                      </div>
                      <div className="h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                        <motion.div
                          initial={{ width: '0%' }}
                          animate={{ width: `${g.progress}%` }}
                          transition={{ duration: 1.2 }}
                          className="h-full rounded-full"
                          style={{ background: g.color }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2 mt-4">
                  <Btn color={C.teal}><Plus size={11} /> New Goal</Btn>
                  <Btn color={C.blue}>View All</Btn>
                </div>
              </Card>

              {/* Sleep Planner */}
              <Card glow={C.blue}>
                <div className="flex items-center gap-2 mb-4">
                  <Moon size={16} style={{ color: C.blue }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Sleep Planner</span>
                </div>
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex-1 rounded-xl p-3 text-center" style={{ background: 'rgba(74,158,255,0.1)', border: `1px solid ${C.blue}30` }}>
                    <p className="text-white/40" style={{ fontSize: 10, marginBottom: 4 }}>Bedtime</p>
                    <p className="text-white" style={{ fontSize: 22, fontWeight: 800 }}>10:30<span className="text-white/40" style={{ fontSize: 12 }}>PM</span></p>
                  </div>
                  <div className="text-white/30" style={{ fontSize: 18 }}>→</div>
                  <div className="flex-1 rounded-xl p-3 text-center" style={{ background: 'rgba(0,200,151,0.1)', border: `1px solid ${C.teal}30` }}>
                    <p className="text-white/40" style={{ fontSize: 10, marginBottom: 4 }}>Wake Up</p>
                    <p className="text-white" style={{ fontSize: 22, fontWeight: 800 }}>6:30<span className="text-white/40" style={{ fontSize: 12 }}>AM</span></p>
                  </div>
                </div>
                <div className="rounded-xl p-3 mb-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
                  <div className="flex justify-between items-center">
                    <span className="text-white/50" style={{ fontSize: 12 }}>Total sleep duration</span>
                    <span style={{ color: C.teal, fontSize: 14, fontWeight: 700 }}>8h 00m</span>
                  </div>
                  <div className="flex justify-between items-center mt-1.5">
                    <span className="text-white/50" style={{ fontSize: 12 }}>Sleep cycles</span>
                    <span className="text-white/70" style={{ fontSize: 12 }}>5.7 cycles</span>
                  </div>
                  <div className="flex justify-between items-center mt-1.5">
                    <span className="text-white/50" style={{ fontSize: 12 }}>Smart alarm window</span>
                    <span className="text-white/70" style={{ fontSize: 12 }}>6:00–6:30 AM</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Btn color={C.blue} className="flex-1 justify-center">Adjust Times</Btn>
                  <Btn color={C.teal} className="flex-1 justify-center"><Check size={11} /> Apply</Btn>
                </div>
              </Card>

              {/* Motivation */}
              <Card glow={C.purple} style={{ background: `linear-gradient(135deg, rgba(139,92,246,0.12), rgba(236,72,153,0.08))` }}>
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles size={16} style={{ color: C.purple }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Motivation Generator</span>
                </div>
                <div className="rounded-xl p-4 mb-4 relative overflow-hidden"
                  style={{ background: 'rgba(139,92,246,0.1)', border: `1px solid ${C.purple}25` }}>
                  <div className="absolute top-2 left-3 text-4xl opacity-10">"</div>
                  <p className="text-white/80 relative z-10" style={{ fontSize: 13, lineHeight: 1.6 }}>
                    {motivationQuotes[quoteIdx].quote}
                  </p>
                  <p className="mt-2 text-right" style={{ fontSize: 11, color: C.purple }}>
                    — {motivationQuotes[quoteIdx].author}
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2 mb-4">
                  {['Exercise', 'Sleep', 'Diet'].map((tag, i) => (
                    <div key={i} className="rounded-lg p-2 text-center cursor-pointer hover:opacity-80 transition-opacity"
                      style={{ background: `${C.purple}15`, border: `1px solid ${C.purple}25` }}>
                      <span style={{ fontSize: 11, color: C.purple }}>{tag}</span>
                    </div>
                  ))}
                </div>
                <Btn color={C.purple} className="w-full justify-center"
                  onClick={() => setQuoteIdx((quoteIdx + 1) % motivationQuotes.length)}>
                  <RefreshCw size={11} /> New Quote
                </Btn>
              </Card>
            </div>

            {/* ══════════════════════════════════════════════════
                SECTION 3 — AI & Smart Tools
            ══════════════════════════════════════════════════ */}
            <SectionTitle title="AI & Smart Tools" subtitle="Intelligent health analysis at your fingertips" action="Open AI Hub" />
            <div className="grid grid-cols-4 gap-4 mb-8">

              {/* AI Health Assistant */}
              <Card glow={C.teal} className="col-span-2">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${C.teal}20` }}>
                    <Bot size={15} style={{ color: C.teal }} />
                  </div>
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>AI Health Assistant</span>
                  <span className="ml-auto text-xs px-2 py-0.5 rounded-full flex items-center gap-1"
                    style={{ background: `${C.teal}18`, color: C.teal }}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" /> Online
                  </span>
                </div>
                <div className="space-y-2 mb-3" style={{ maxHeight: 140, overflowY: 'auto' }}>
                  {[
                    { from: 'ai', text: 'Hello Alex! How can I help with your health today?' },
                    { from: 'user', text: 'I\'ve been feeling tired lately, any suggestions?' },
                    { from: 'ai', text: 'Based on your recent data, your sleep quality has dropped to 72. I recommend a consistent 10:30 PM bedtime and reducing screen time an hour before sleep.' },
                  ].map((m, i) => (
                    <div key={i} className={`flex ${m.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className="max-w-[85%] rounded-xl px-3 py-2"
                        style={{
                          background: m.from === 'ai' ? 'rgba(255,255,255,0.06)' : `${C.teal}25`,
                          color: m.from === 'ai' ? 'rgba(255,255,255,0.75)' : C.teal,
                          fontSize: 11, lineHeight: 1.5
                        }}>
                        {m.text}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    placeholder="Ask a health question…"
                    className="flex-1 rounded-xl px-3 py-2 text-white outline-none placeholder-white/25"
                    style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', fontSize: 12 }}
                  />
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ background: C.teal }}
                    onClick={() => setChatInput('')}
                  >
                    <Send size={14} className="text-white" />
                  </motion.button>
                </div>
                <Btn color={C.teal} className="mt-2 w-full justify-center">Open Full Chat</Btn>
              </Card>

              {/* Health Risk Predictor */}
              <Card glow={C.red} onClick={() => toggleCard('risk')}>
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp size={15} style={{ color: C.red }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Risk Predictor</span>
                </div>
                <div className="space-y-2">
                  {riskFactors.map((r, i) => (
                    <div key={i}>
                      <div className="flex justify-between mb-0.5">
                        <span className="text-white/50" style={{ fontSize: 10 }}>{r.factor}</span>
                        <span style={{ fontSize: 10, color: r.color }}>{r.level}</span>
                      </div>
                      <div className="h-1 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                        <motion.div
                          initial={{ width: '0%' }}
                          animate={{ width: `${r.risk}%` }}
                          transition={{ duration: 1.2, delay: i * 0.1 }}
                          className="h-full rounded-full"
                          style={{ background: r.color }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <Btn color={C.red} className="mt-3 w-full justify-center">Full Analysis</Btn>
              </Card>

              {/* Multimodal + Image Scanner */}
              <div className="flex flex-col gap-4">
                <Card glow={C.purple} onClick={() => toggleCard('multi')} className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Cpu size={15} style={{ color: C.purple }} />
                    <span className="text-white/80" style={{ fontSize: 12, fontWeight: 600 }}>Multimodal Input</span>
                  </div>
                  <p className="text-white/40 mb-3" style={{ fontSize: 11 }}>Enter your symptoms using text, voice, or image.</p>
                  <div className="flex gap-2">
                    {[
                      { icon: MessageSquare, label: 'Text', color: C.teal },
                      { icon: Mic, label: 'Voice', color: C.blue },
                      { icon: Camera, label: 'Image', color: C.purple },
                    ].map((item, i) => (
                      <motion.button
                        key={i}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex-1 flex flex-col items-center gap-1 py-2 rounded-lg transition-colors"
                        style={{ background: `${item.color}15`, border: `1px solid ${item.color}30` }}
                      >
                        <item.icon size={14} style={{ color: item.color }} />
                        <span style={{ fontSize: 9, color: item.color }}>{item.label}</span>
                      </motion.button>
                    ))}
                  </div>
                </Card>
                <Card glow={C.yellow} onClick={() => toggleCard('scan')} className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Scan size={15} style={{ color: C.yellow }} />
                    <span className="text-white/80" style={{ fontSize: 12, fontWeight: 600 }}>Medical Image Scanner</span>
                  </div>
                  <motion.div
                    whileHover={{ borderColor: C.yellow }}
                    className="rounded-lg p-3 flex flex-col items-center gap-2 cursor-pointer transition-all"
                    style={{ border: `2px dashed rgba(245,158,11,0.3)`, background: `${C.yellow}08` }}
                  >
                    <Upload size={18} style={{ color: C.yellow, opacity: 0.7 }} />
                    <span className="text-white/40" style={{ fontSize: 10 }}>Drop X-ray/scan here</span>
                  </motion.div>
                  <Btn color={C.yellow} className="mt-2 w-full justify-center">
                    <Upload size={11} /> Upload Scan
                  </Btn>
                </Card>
              </div>
            </div>

            {/* ══════════════════════════════════════════════════
                SECTION 4 — Medical Support
            ══════════════════════════════════════════════════ */}
            <SectionTitle title="Medical Support" subtitle="Instant access to medical tools and emergency aid" />
            <div className="grid grid-cols-3 gap-4 mb-8">

              {/* Medicine Checker */}
              <Card glow={C.green} onClick={() => toggleCard('med')}>
                <div className="flex items-center gap-2 mb-3">
                  <Pill size={16} style={{ color: C.green }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Medicine Checker</span>
                </div>
                <div className="relative mb-3">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                  <input
                    placeholder="Search medicine name…"
                    className="w-full py-2 pl-8 pr-3 rounded-lg text-white placeholder-white/25 outline-none"
                    style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', fontSize: 12 }}
                  />
                </div>
                <div className="space-y-2">
                  {[
                    { name: 'Metformin 500mg', time: '8:00 AM, 8:00 PM', status: 'Taken', color: C.teal },
                    { name: 'Vitamin D3', time: '12:00 PM', status: 'Pending', color: C.yellow },
                    { name: 'Omega-3', time: '6:00 PM', status: 'Pending', color: C.blue },
                  ].map((m, i) => (
                    <div key={i} className="flex items-center gap-2 p-2 rounded-lg" style={{ background: 'rgba(255,255,255,0.04)' }}>
                      <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: `${m.color}20` }}>
                        <Pill size={10} style={{ color: m.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white/80 truncate" style={{ fontSize: 11, fontWeight: 500 }}>{m.name}</p>
                        <p className="text-white/30" style={{ fontSize: 9 }}>{m.time}</p>
                      </div>
                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: `${m.color}20`, color: m.color, fontSize: 9 }}>
                        {m.status}
                      </span>
                    </div>
                  ))}
                </div>
                <Btn color={C.green} className="mt-3 w-full justify-center">Check Now</Btn>
              </Card>

              {/* First Aid Guide */}
              <Card glow={C.blue} onClick={() => toggleCard('aid')}>
                <div className="flex items-center gap-2 mb-3">
                  <Shield size={16} style={{ color: C.blue }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>AI First Aid Guide</span>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  {[
                    { label: 'Burns', icon: '🔥', color: C.orange },
                    { label: 'Cuts & Wounds', icon: '🩹', color: C.red },
                    { label: 'Fractures', icon: '🦴', color: C.yellow },
                    { label: 'Choking', icon: '🫁', color: C.blue },
                    { label: 'Cardiac Arrest', icon: '💓', color: C.red },
                    { label: 'Poisoning', icon: '☠️', color: C.purple },
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      className="flex items-center gap-2 p-2 rounded-lg cursor-pointer"
                      style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
                    >
                      <span style={{ fontSize: 14 }}>{item.icon}</span>
                      <span className="text-white/60" style={{ fontSize: 10 }}>{item.label}</span>
                    </motion.div>
                  ))}
                </div>
                <Btn color={C.blue} className="w-full justify-center">Open Guide <BookOpen size={11} /></Btn>
              </Card>

              {/* Emergency Detection */}
              <Card
                glow={C.red}
                style={{ background: 'linear-gradient(135deg, rgba(239,68,68,0.12), rgba(220,38,38,0.06))' }}
                onClick={() => toggleCard('emergency')}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center animate-pulse"
                    style={{ background: `${C.red}25` }}>
                    <Siren size={15} style={{ color: C.red }} />
                  </div>
                  <span className="text-white" style={{ fontSize: 13, fontWeight: 700 }}>Emergency Detection</span>
                  <span className="ml-auto text-xs px-2 py-0.5 rounded-full flex items-center gap-1"
                    style={{ background: `${C.red}20`, color: C.red }}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" /> Active
                  </span>
                </div>
                <div className="rounded-xl p-3 mb-3" style={{ background: 'rgba(239,68,68,0.1)', border: `1px solid ${C.red}25` }}>
                  <p className="text-white/60" style={{ fontSize: 11, lineHeight: 1.5 }}>
                    AI monitors your vitals in real-time. In case of abnormal readings, emergency contacts will be notified automatically.
                  </p>
                </div>
                <div className="space-y-2 mb-4">
                  {[
                    { label: 'Heart Rate Anomaly', active: false },
                    { label: 'Fall Detection', active: true },
                    { label: 'SOS Auto-Dial', active: true },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <span className="text-white/60" style={{ fontSize: 12 }}>{item.label}</span>
                      <div className="w-8 h-4 rounded-full relative cursor-pointer"
                        style={{ background: item.active ? C.teal : 'rgba(255,255,255,0.1)' }}>
                        <div className="absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all"
                          style={{ left: item.active ? '18px' : '2px' }} />
                      </div>
                    </div>
                  ))}
                </div>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  className="w-full py-2.5 rounded-xl text-white font-bold flex items-center justify-center gap-2"
                  style={{ background: `linear-gradient(135deg, ${C.red}, #C43030)`, fontSize: 12 }}
                >
                  <Phone size={14} /> Call Emergency (112)
                </motion.button>
              </Card>
            </div>

            {/* ══════════════════════════════════════════════════
                SECTION 5 — Family & Records
            ══════════════════════════════════════════════════ */}
            <SectionTitle title="Family & Records" subtitle="Manage health for everyone in your family" action="Add Member" />
            <div className="grid grid-cols-2 gap-4 mb-8">

              {/* Family Manager */}
              <Card glow={C.teal}>
                <div className="flex items-center gap-2 mb-4">
                  <Users size={16} style={{ color: C.teal }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Family Health Manager</span>
                  <span className="ml-auto text-xs px-2 py-0.5 rounded-full" style={{ background: `${C.teal}18`, color: C.teal }}>
                    4 Members
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-3 mb-4">
                  {familyMembers.map(m => (
                    <motion.div
                      key={m.id}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.96 }}
                      className="flex flex-col items-center gap-2 p-3 rounded-xl cursor-pointer transition-all"
                      style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${m.color}30` }}
                    >
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl"
                        style={{ background: `${m.color}20` }}>
                        {m.emoji}
                      </div>
                      <p className="text-white/80" style={{ fontSize: 11, fontWeight: 600 }}>{m.name}</p>
                      <p className="text-white/40" style={{ fontSize: 10 }}>{m.age}y</p>
                      <span className="text-center px-1.5 py-0.5 rounded-full" style={{ background: `${m.color}20`, color: m.color, fontSize: 8, lineHeight: 1.4 }}>
                        {m.status}
                      </span>
                    </motion.div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Btn color={C.teal}><UserPlus size={11} /> Add Member</Btn>
                  <Btn color={C.blue}>Family History</Btn>
                  <Btn color={C.orange}>Shared Goals</Btn>
                </div>
              </Card>

              {/* Report Management */}
              <Card glow={C.blue}>
                <div className="flex items-center gap-2 mb-4">
                  <FolderOpen size={16} style={{ color: C.blue }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Report Management</span>
                </div>
                <div className="space-y-2 mb-4">
                  {[
                    { name: 'Blood Test Report', date: 'Apr 22, 2026', type: 'PDF', size: '2.4 MB', color: C.red, icon: '🩸' },
                    { name: 'Chest X-Ray Scan', date: 'Apr 15, 2026', type: 'IMG', size: '8.1 MB', color: C.blue, icon: '🫁' },
                    { name: 'ECG Report', date: 'Apr 10, 2026', type: 'PDF', size: '1.1 MB', color: C.teal, icon: '📈' },
                    { name: 'Prescription — Dr. Roy', date: 'Apr 5, 2026', type: 'PDF', size: '0.8 MB', color: C.green, icon: '💊' },
                  ].map((r, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ x: 3 }}
                      className="flex items-center gap-3 p-2.5 rounded-xl cursor-pointer"
                      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}
                    >
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center text-base"
                        style={{ background: `${r.color}15` }}>
                        {r.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white/80 truncate" style={{ fontSize: 12, fontWeight: 500 }}>{r.name}</p>
                        <p className="text-white/30" style={{ fontSize: 10 }}>{r.date} · {r.size}</p>
                      </div>
                      <div className="flex gap-1.5">
                        <span className="px-1.5 py-0.5 rounded text-xs" style={{ background: `${r.color}20`, color: r.color, fontSize: 9 }}>
                          {r.type}
                        </span>
                        <motion.button whileTap={{ scale: 0.9 }} className="text-white/30 hover:text-white/70">
                          <Download size={13} />
                        </motion.button>
                        <motion.button whileTap={{ scale: 0.9 }} className="text-white/30 hover:text-white/70">
                          <Eye size={13} />
                        </motion.button>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Btn color={C.blue}><Upload size={11} /> Upload Report</Btn>
                  <Btn color={C.teal}>View All Files</Btn>
                </div>
              </Card>
            </div>

            {/* ══════════════════════════════════════════════════
                SECTION 6 — Healthcare Access
            ══════════════════════════════════════════════════ */}
            <SectionTitle title="Healthcare Access" subtitle="Find providers and stay informed about local health" />
            <div className="grid grid-cols-3 gap-4 mb-8">

              {/* Nearby Healthcare */}
              <Card glow={C.teal}>
                <div className="flex items-center gap-2 mb-3">
                  <MapPin size={16} style={{ color: C.teal }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Nearby Healthcare</span>
                </div>
                {/* Mock map box */}
                <div className="rounded-xl overflow-hidden mb-3 relative" style={{ height: 110 }}>
                  <div className="w-full h-full" style={{ background: 'linear-gradient(135deg, #0B1E35, #0F2A4A)' }}>
                    {/* Grid lines */}
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="absolute w-full h-px" style={{ top: `${i * 25}%`, background: 'rgba(74,158,255,0.1)' }} />
                    ))}
                    {[...Array(7)].map((_, i) => (
                      <div key={i} className="absolute h-full w-px" style={{ left: `${i * 16}%`, background: 'rgba(74,158,255,0.1)' }} />
                    ))}
                    {/* Map pins */}
                    <div className="absolute" style={{ top: '40%', left: '45%' }}>
                      <div className="w-3 h-3 rounded-full animate-ping" style={{ background: `${C.blue}40` }} />
                      <div className="absolute inset-1 rounded-full" style={{ background: C.blue }} />
                    </div>
                    {[
                      { top: '25%', left: '30%', color: C.red },
                      { top: '60%', left: '65%', color: C.teal },
                      { top: '20%', left: '70%', color: C.yellow },
                    ].map((pin, i) => (
                      <div key={i} className="absolute w-2.5 h-2.5 rounded-full" style={{ top: pin.top, left: pin.left, background: pin.color, boxShadow: `0 0 6px ${pin.color}` }} />
                    ))}
                    <div className="absolute bottom-2 right-2 px-2 py-1 rounded text-white/60" style={{ background: 'rgba(0,0,0,0.5)', fontSize: 9 }}>
                      📍 Mumbai, IN
                    </div>
                  </div>
                </div>
                <div className="space-y-1.5">
                  {nearbyPlaces.map((p, i) => (
                    <div key={i} className="flex items-center gap-2 p-2 rounded-lg cursor-pointer hover:bg-white/5 transition-colors">
                      <div className="w-5 h-5 rounded flex items-center justify-center"
                        style={{ background: p.type === 'Hospital' ? `${C.red}20` : p.type === 'Pharmacy' ? `${C.green}20` : `${C.blue}20` }}>
                        <MapPin size={10} style={{ color: p.type === 'Hospital' ? C.red : p.type === 'Pharmacy' ? C.green : C.blue }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white/80 truncate" style={{ fontSize: 11 }}>{p.name}</p>
                        <p className="text-white/30" style={{ fontSize: 9 }}>{p.type} · {p.dist}</p>
                      </div>
                      <span className="text-xs" style={{ color: p.open ? C.teal : C.red, fontSize: 9 }}>
                        {p.open ? 'Open' : 'Closed'}
                      </span>
                    </div>
                  ))}
                </div>
                <Btn color={C.teal} className="mt-3 w-full justify-center">
                  <Map size={11} /> Open Full Map
                </Btn>
              </Card>

              {/* Specialist Navigator */}
              <Card glow={C.blue}>
                <div className="flex items-center gap-2 mb-3">
                  <Navigation size={16} style={{ color: C.blue }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Specialist Navigator</span>
                </div>
                <div className="relative mb-3">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                  <input
                    placeholder="Search specialist type…"
                    className="w-full py-2 pl-8 pr-3 rounded-lg text-white placeholder-white/25 outline-none"
                    style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', fontSize: 12 }}
                  />
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  {specialists.map((s, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      className="flex items-center gap-2 p-2.5 rounded-xl cursor-pointer"
                      style={{ background: `${s.color}10`, border: `1px solid ${s.color}25` }}
                    >
                      <s.icon size={14} style={{ color: s.color }} />
                      <div className="min-w-0">
                        <p className="text-white/80 truncate" style={{ fontSize: 10, fontWeight: 600 }}>{s.label}</p>
                        <p style={{ fontSize: 9, color: s.color }}>{s.count} available</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <Btn color={C.blue} className="w-full justify-center">Book Appointment</Btn>
              </Card>

              {/* Outbreak Alerts */}
              <Card glow={C.orange} style={{ background: 'linear-gradient(135deg, rgba(255,122,0,0.08), rgba(239,68,68,0.06))' }}>
                <div className="flex items-center gap-2 mb-3">
                  <Radio size={16} style={{ color: C.orange }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Outbreak Alerts</span>
                  <span className="ml-auto w-2 h-2 rounded-full animate-pulse" style={{ background: C.red }} />
                </div>
                <p className="text-white/40 mb-3" style={{ fontSize: 11 }}>Health alerts in your area — stay informed and protected.</p>
                <div className="space-y-2.5">
                  {outbreaks.map((o, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ x: 2 }}
                      className="flex items-center gap-3 p-3 rounded-xl cursor-pointer"
                      style={{ background: `${o.color}10`, border: `1px solid ${o.color}25` }}
                    >
                      <AlertTriangle size={16} style={{ color: o.color }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-white/80" style={{ fontSize: 12, fontWeight: 600 }}>{o.disease}</p>
                          <span className="px-1.5 py-0.5 rounded text-xs" style={{ background: `${o.color}20`, color: o.color, fontSize: 9 }}>
                            {o.level}
                          </span>
                        </div>
                        <p className="text-white/40" style={{ fontSize: 10 }}>
                          Within {o.area} · {o.cases} cases reported
                        </p>
                      </div>
                      <ChevronRight size={13} className="text-white/30" />
                    </motion.div>
                  ))}
                </div>
                <div className="flex gap-2 mt-3">
                  <Btn color={C.orange} className="flex-1 justify-center">View All Alerts</Btn>
                  <Btn color={C.teal} className="flex-1 justify-center">Get Vaccinated</Btn>
                </div>
              </Card>
            </div>

            {/* ══════════════════════════════════════════════════
                SECTION 7 — Lifestyle
            ══════════════════════════════════════════════════ */}
            <SectionTitle title="Lifestyle & Finance" subtitle="Track your health-related spending" action="View Details" />
            <div className="grid grid-cols-3 gap-4 mb-8">

              {/* Expense Tracker */}
              <Card glow={C.yellow} className="col-span-2">
                <div className="flex items-center gap-2 mb-4">
                  <Wallet size={16} style={{ color: C.yellow }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Health Expense Tracker</span>
                  <span className="ml-auto text-white/80" style={{ fontSize: 16, fontWeight: 800 }}>
                    ₹1,460 <span className="text-white/30" style={{ fontSize: 12, fontWeight: 400 }}>this month</span>
                  </span>
                </div>
                <div className="flex gap-4">
                  <div style={{ flex: 1, height: 150 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={expenseData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="month" tick={{ fill: '#ffffff40', fontSize: 10 }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fill: '#ffffff40', fontSize: 10 }} axisLine={false} tickLine={false} />
                        <Tooltip
                          contentStyle={{ background: '#0D1B2A', border: 'none', borderRadius: 8, fontSize: 11, color: '#fff' }}
                          formatter={(v: number) => [`₹${v}`, 'Spent']}
                        />
                        <Bar dataKey="amount" fill={C.yellow} radius={[4, 4, 0, 0]} opacity={0.8} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex flex-col justify-center gap-2" style={{ width: 150 }}>
                    {pieData.map((d, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full" style={{ background: d.color }} />
                          <span className="text-white/60" style={{ fontSize: 11 }}>{d.name}</span>
                        </div>
                        <span className="text-white/80" style={{ fontSize: 11, fontWeight: 600 }}>₹{d.value}</span>
                      </div>
                    ))}
                    <div className="mt-2 pt-2" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
                      <div className="flex justify-between">
                        <span className="text-white/50" style={{ fontSize: 11 }}>Total</span>
                        <span style={{ color: C.yellow, fontSize: 12, fontWeight: 700 }}>₹460</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Wellness Score summary */}
              <Card glow={C.teal} style={{ background: 'linear-gradient(145deg, rgba(0,200,151,0.1), rgba(74,158,255,0.06))' }}>
                <div className="flex items-center gap-2 mb-4">
                  <Award size={16} style={{ color: C.teal }} />
                  <span className="text-white/80" style={{ fontSize: 13, fontWeight: 600 }}>Wellness Summary</span>
                </div>
                <div className="flex items-center justify-center mb-4">
                  <div className="relative" style={{ width: 120, height: 120 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <RadialBarChart cx="50%" cy="50%" innerRadius="60%" outerRadius="90%" data={[{ value: 87 }]} startAngle={90} endAngle={-270}>
                        <RadialBar dataKey="value" cornerRadius={10} fill={C.teal} background={{ fill: 'rgba(255,255,255,0.05)' }} />
                      </RadialBarChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <p className="text-white" style={{ fontSize: 28, fontWeight: 900, lineHeight: 1 }}>87</p>
                      <p style={{ fontSize: 10, color: C.teal }}>/ 100</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  {[
                    { label: 'Physical', score: 90, color: C.teal },
                    { label: 'Mental', score: 78, color: C.purple },
                    { label: 'Nutrition', score: 85, color: C.orange },
                    { label: 'Sleep', score: 72, color: C.blue },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-white/50 w-16 flex-shrink-0" style={{ fontSize: 10 }}>{item.label}</span>
                      <div className="flex-1 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                        <motion.div
                          initial={{ width: '0%' }}
                          animate={{ width: `${item.score}%` }}
                          transition={{ duration: 1, delay: i * 0.15 }}
                          className="h-full rounded-full"
                          style={{ background: item.color }}
                        />
                      </div>
                      <span style={{ fontSize: 10, color: item.color, width: 24, textAlign: 'right' }}>{item.score}</span>
                    </div>
                  ))}
                </div>
                <Btn color={C.teal} className="mt-4 w-full justify-center">
                  View Insights <ArrowRight size={11} />
                </Btn>
              </Card>
            </div>

            {/* Bottom padding */}
            <div style={{ height: 32 }} />
          </div>
        </main>
      </div>
    </div>
  );
}
